from datetime import datetime

import SetupDjangoORM
from airflow import DAG
from custom.hooks.slack.slack import SlackFailureNotifiier

with DAG(
    dag_id="w2w_kcredit_macro_to_it_efas",
    description="[미정] 신정원에서 요청한 테이블 형태로 적재하는 DAG입니다.",
    schedule=None,
    start_date=datetime(2024, 3, 6),
    tags=["kcredit_macro", "stats", "warehouse"],
    catchup=False,
    on_failure_callback=SlackFailureNotifiier(),
) as dag:
    from airflow.operators.python import PythonOperator
    from airflow.providers.postgres.operators.postgres import PostgresOperator
    from table.models.warehouse.kcredit_macro import (
        KcreditMacroEfasInduCommon,
        KcreditMacroEfasRaw,
    )
    from tasks.warehouse.kcredit_macro.d9_total_kbank_na import kcredit_raw_to_kbank_na
    from tasks.warehouse.kcredit_macro.econ import kcredit_raw_to_econ
    from tasks.warehouse.kcredit_macro.efas_map import kcredit_macro_map_table_update
    from tasks.warehouse.kcredit_macro.indu_speclal import kcredit_raw_to_indu_speclal
    from tasks.warehouse.kcredit_macro.ppi_index import kcredit_raw_to_ppi_index

    # MAP
    prod_kcredit_macro_map_table_update = PythonOperator(
        task_id="prod_kcredit_macro_map_table_update",
        python_callable=kcredit_macro_map_table_update,
        op_kwargs={
            "db": "hugraph-prod",
            "request_day": "{{data_interval_end | ds_nodash}}",
        },
    )

    # RAW
    prod_it_efas_macro_raw = PostgresOperator(
        task_id="prod_it_efas_macro_raw",
        postgres_conn_id="hugraph-prod",
        sql=KcreditMacroEfasRaw._create_sql(),
    )

    # ECON
    prod_kcredit_raw_econ = PythonOperator(
        task_id="prod_kcredit_raw_econ",
        python_callable=kcredit_raw_to_econ,
        op_kwargs={
            "db": "hugraph-prod",
            "request_day": "{{data_interval_end | ds_nodash}}",
        },
    )
    # PPI INDEX
    prod_kcredit_raw_ppi_index = PythonOperator(
        task_id="prod_kcredit_raw_ppi_index",
        python_callable=kcredit_raw_to_ppi_index,
        op_kwargs={
            "db": "hugraph-prod",
            "request_day": "{{data_interval_end | ds_nodash}}",
        },
    )

    # INDU SPECIAL
    prod_kcredit_raw_indu_speclal = PythonOperator(
        task_id="prod_kcredit_raw_indu_speclal",
        python_callable=kcredit_raw_to_indu_speclal,
        op_kwargs={
            "db": "hugraph-prod",
        },
    )

    # KBANK NA
    prod_kcredit_raw_kbank_na = PythonOperator(
        task_id="prod_kcredit_raw_kbank_na",
        python_callable=kcredit_raw_to_kbank_na,
        op_kwargs={
            "db": "hugraph-prod",
            "request_day": "{{data_interval_end | ds_nodash}}",
        },
    )

    # COMMON
    prod_it_efas_indu_common_db = PostgresOperator(
        task_id="prod_it_efas_indu_common_db",
        postgres_conn_id="hugraph-prod",
        sql=KcreditMacroEfasInduCommon._create_sql(),
    )

    prod_kcredit_macro_map_table_update >> (
        prod_it_efas_macro_raw,
        prod_kcredit_raw_econ,
        prod_kcredit_raw_ppi_index,
        prod_kcredit_raw_indu_speclal,
        prod_kcredit_raw_kbank_na,
        prod_it_efas_indu_common_db,
    )
