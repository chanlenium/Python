import time
from datetime import datetime, timedelta

import pandas as pd
from loguru import logger
from table.models.warehouse.kcredit_macro import KcreditMacroCrawlerUniverse
from table.static.mapping.universe.kcredit import KCREDIT_UNIVERSE_MAP, MAPPING_DATA
from tasks.warehouse.core.utils import hcode_generator


def kcredit_universe_to_warehouse(db: str, request_day: str):
    """
    static/mapping/universe/kcredit.py의 KCREDIT_UNIVERSE_MAP을 universe테이블에 적재하는 함수입니다.
    :param request_day:
    :param db:
    :return:
    """
    start_time = time.time()
    logger.info(f"[WAREHOUSE][kcredit_macro_universe][DB:{db}] START")

    raw_df = pd.DataFrame(KCREDIT_UNIVERSE_MAP)

    # istans 는 직접 만들기가 힘들기에, 자동생성 로직 추가
    request_day_date = datetime.strptime(request_day, "%Y%m%d")
    name_list = [
        "PRODUC_INDEX",
        "PRODUC_INDEX_GAE",
        "SHIPMENT_INDEX",
        "SHIPMENT_INDEX_GAE",
        "INVENTORY_INDEX",
        "INVENTORY_INDEX_GAE",
        "OPER_RATE_INDEX",
        "OPER_RATE_INDEX_GAE",
        "EXPORT_MDOLLAR",
        "IMPORT_MDOLLAR",
    ]
    istans_df = pd.DataFrame(
        MAPPING_DATA, columns=["macro_code", "name_kor", "original_name_kor"]
    )
    istans_df.drop(columns="original_name_kor", inplace=True)
    # 단위추가
    istans_df["unit"] = "Index"
    # source 추가
    istans_df["source"] = "istans"
    tmp_df = pd.DataFrame()
    for name in name_list:
        # hcode 추가
        istans_df["hcode"] = istans_df.apply(
            lambda x: hcode_generator.istans_hcode_generator(
                classification=name, macro_code=x["macro_code"]
            ),
            axis=1,
        )
        tmp_df = pd.concat([tmp_df, istans_df])
    raw_df = pd.concat([raw_df, tmp_df])

    obj_list = []
    for raw in raw_df.to_dict(orient="records"):
        obj_list.append(KcreditMacroCrawlerUniverse(**raw))

    KcreditMacroCrawlerUniverse.objects.using(db).bulk_create(
        objs=obj_list,
        batch_size=1000,
        update_conflicts=True,
        update_fields=["name_kor", "unit", "source"],
        unique_fields=["hcode", "macro_code"],
    )
    end_time = time.time()

    logger.info(
        f"[WAREHOUSE][kcredit_macro_universe][DB:{db}] END {len(obj_list)} success. {timedelta(seconds=end_time - start_time)}, {request_day}"
    )
