import pandas as pd
from custom.hooks.google.cloud import GoogleCloudHook
from table.models.warehouse.kcredit_macro import KcreditMacroEfasMap


def kcredit_macro_map_table_update(db: str):
    """
    google sheet에 있는 kcredit_macro_map 데이터를 업데이트 하는 함수입니다.
    url : https://docs.google.com/spreadsheets/d/1RTh3z6JXv8srrZWq5dKFwufYWIbfCEXAhbADuACZeVg/edit#gid=0
    :return:
    """
    google_obj = GoogleCloudHook()

    sheet_obj = google_obj.get_sheet_data(
        spreadsheet_id="1RTh3z6JXv8srrZWq5dKFwufYWIbfCEXAhbADuACZeVg"
    )
    raw_df = pd.DataFrame(
        columns=sheet_obj["valueRanges"][0]["values"][0],
        data=sheet_obj["valueRanges"][0]["values"][1:],
    )
    raw_df.drop(columns=["OTHER"], inplace=True)

    # IT_EFAS_MACRO_ECON_DB 등 컬럼들 boolean으로 변경
    raw_df["COLUMN"] = raw_df.apply(
        lambda x: "" if x["COLUMN"] in [None, ""] else x["COLUMN"], axis=1
    )
    raw_df["CALC"] = raw_df.apply(
        lambda x: None if x["CALC"] in [None, ""] else x["CALC"], axis=1
    )
    raw_df["IT_EFAS_MACRO_ECON"] = raw_df.apply(
        lambda x: True if x["IT_EFAS_MACRO_ECON"] == "O" else False, axis=1
    )
    raw_df["IT_EFAS_PPI_INDEX"] = raw_df.apply(
        lambda x: True if x["IT_EFAS_PPI_INDEX"] == "O" else False, axis=1
    )
    raw_df["IT_EFAS_INDU_SPECIAL"] = raw_df.apply(
        lambda x: True if x["IT_EFAS_INDU_SPECIAL"] == "O" else False, axis=1
    )
    raw_df["IT_D9_TOTAL_KBANK_NA"] = raw_df.apply(
        lambda x: True if x["IT_D9_TOTAL_KBANK_NA"] == "O" else False, axis=1
    )
    raw_df.rename(
        columns={
            "HCODE": "hcode",
            "MACRO_GBN": "macro_gbn",
            "MACRO_CODE": "macro_code",
            "FULL_NAME_KOR": "full_name_kor",
            "PERIOD": "period",
            "UNIT": "unit",
            "SOURCE": "source",
            "CALC": "calc",
            "COLUMN": "column",
            "IT_EFAS_MACRO_ECON": "it_efas_macro_econ",
            "IT_EFAS_PPI_INDEX": "it_efas_ppi_index",
            "IT_EFAS_INDU_SPECIAL": "it_efas_indu_special",
            "IT_D9_TOTAL_KBANK_NA": "it_d9_total_kbank_na",
        },
        inplace=True,
    )

    # 임시 코드(hcode null값에 따른 임시값 삽입)
    raw_df["hcode"] = raw_df.apply(
        lambda x: "None" if x["hcode"] in [None, ""] else x["hcode"], axis=1
    )
    ## 임시코드
    obj_list = []

    for save in raw_df.to_dict(orient="records"):
        obj_list.append(KcreditMacroEfasMap(**save))

    KcreditMacroEfasMap.objects.using(db).bulk_create(
        objs=obj_list,
        update_conflicts=True,
        unique_fields=[
            "hcode",
            "macro_gbn",
            "macro_code",
            "it_efas_macro_econ",
            "it_efas_ppi_index",
            "it_efas_indu_special",
            "it_d9_total_kbank_na",
        ],
        update_fields=[
            "full_name_kor",
            "period",
            "unit",
            "source",
            "calc",
            "column",
        ],
        batch_size=200,
    )
