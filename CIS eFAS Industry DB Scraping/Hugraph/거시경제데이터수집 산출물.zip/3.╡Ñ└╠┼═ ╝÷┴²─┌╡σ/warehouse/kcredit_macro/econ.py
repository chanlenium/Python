from datetime import datetime

import pandas as pd
from dateutil.relativedelta import relativedelta
from loguru import logger
from table.models.warehouse.kcredit_macro import (
    KcreditMacroEfasEcon,
    KcreditMacroEfasMap,
)
from tasks.warehouse.core.kcredit_macro import kcredit_macro_cleansing
from tasks.warehouse.core.kcredit_macro.utils_io import kcredit_macro_io


def kcredit_raw_to_econ(db: str, request_day: str, **context):
    """
    kcredit_macro_efas_raw 테이블에서 econ데이터만 삽입하는 함수입니다.
    전체적으로 Month 데이터 입니다.
    :return:
    """
    # =================================================== 1. 데이터 로드 ==================================================

    if "year" in context["dag_run"].conf:
        year = context["dag_run"].conf["year"] + "0101"
    else:
        year = (
            str(datetime.strptime(request_day, "%Y%m%d") - relativedelta(years=2))[:4]
            + "0101"
        )

    map_df = pd.DataFrame(
        KcreditMacroEfasMap.objects.using(db)
        .filter(it_efas_macro_econ=True)
        .values("source", "macro_gbn", "macro_code", "period", "calc", "column")
    )  # 데이터맵이 적재되어 있는 프레임
    map_df.rename(
        columns={"macro_gbn": "MACRO_GBN", "macro_code": "MACRO_CODE"}, inplace=True
    )

    # econ 데이터 로드 및 컬럼 설정
    value_df = kcredit_macro_io(
        db=db, filter_df=map_df[["MACRO_GBN", "MACRO_CODE"]], year=year
    )  # 계산전 데이터가 적재되어있는 프레임

    # 데이터에 column 추가
    value_df = value_df.merge(
        map_df[["MACRO_GBN", "MACRO_CODE", "column", "period", "calc"]],
        on=["MACRO_GBN", "MACRO_CODE"],
        how="left",
    )

    # month데이터 이므로 STD_YM 컬럼은 앞 6자리만 남기고 제거
    value_df["STD_YMD"] = value_df.apply(lambda x: x["STD_YMD"][:6], axis=1)

    # =================================================== 2. 데이터 계산 ==================================================
    # 계산해야 하는 데이터 프레임
    calc_list_df = value_df[~value_df["calc"].isnull()]
    # 계산해야 하는 데이터 프레임 제거
    value_df = value_df[value_df["calc"].isnull()]

    for macro_group, tmp_df in calc_list_df.groupby(["column"]):
        if macro_group[0] == "GDP_US":
            value_df = pd.concat(
                [value_df, kcredit_macro_cleansing.kcredit_gdp_ymd_cleansing(tmp_df)]
            )
        # W -> M
        elif tmp_df.iloc[0]["period"] == "W" and tmp_df.iloc[0]["calc"] == "M":
            value_df = pd.concat(
                [value_df, kcredit_macro_cleansing.kcredit_day_average_to_month(tmp_df)]
            )
        # D -> M
        elif tmp_df.iloc[0]["period"] == "D" and tmp_df.iloc[0]["calc"] == "M":
            value_df = pd.concat(
                [value_df, kcredit_macro_cleansing.kcredit_day_average_to_month(tmp_df)]
            )
        # Q -> M
        elif tmp_df.iloc[0]["period"] == "Q" and tmp_df.iloc[0]["calc"] == "M":
            value_df = pd.concat([value_df, tmp_df])

    raw_df = value_df.pivot_table(
        index="STD_YMD",
        columns="column",
        values="MACRO_VALUE",
    ).reset_index()
    raw_df = raw_df[raw_df["STD_YMD"] >= year]
    raw_df = raw_df.where(pd.notna(raw_df), None)
    raw_df.rename(columns={"STD_YMD": "STD_YM"}, inplace=True)
    obj_list = []

    for save in raw_df.to_dict(orient="records"):
        obj_list.append(KcreditMacroEfasEcon(**save))

    KcreditMacroEfasEcon.objects.using(db).bulk_create(
        objs=obj_list,
        update_conflicts=True,
        unique_fields=["STD_YM"],
        update_fields=[
            "GDP_WON_SIL",
            "GDP_WON_MYUNG",
            "GDP_GAE_SIL",
            "GDP_GAE_MYUNG",
            "INDU_GDP_WON",
            "INDU_GDP_GAE",
            "INDU_CPERATING_WON",
            "INDU_CPERATING_GAE",
            "INDU_MANU_OPER_WON",
            "INDU_MANU_OPER_GAE",
            "INDU_SERV_OPER_GYUNG",
            "INDU_SERV_OPER_BUL",
            "INDU_SERV_OPER_GAE",
            "INDU_CONSALE_DEPARTMENT_GYUNG",
            "INDU_CONSALE_DEPARTMENT_BUL",
            "INDU_CONSALE_DEPARTMENT_GAE",
            "INDU_CONSALE_SUPER_GYUNG",
            "INDU_CONSALE_SUPER_BUL",
            "INDU_CONSALE_SUPER_GAE",
            "EXCHANGE_WON_DOL",
            "INTERATE_RATE_KORIBOR3",
            "MANU_PRICE",
            "OIL_PRICE_DUBAI",
            "EMPLOYMENT_NUM",
            "UNEMPLOYMENT_NUM",
            "CONST_DOME_ORDER_QUANTITY",
            "CONST_PERMIT_NUM",
            "CONST_COMMENCEMENT_NUM",
            "CONST_HOUSE_TOTAL_PRICE",
            "BUSINESS_SURVEY_INDEX_PER",
            "BUSINESS_SURVEY_INDEX_CON",
            "MOTOR_REGISTRATION_COUNT",
            "AMOUNT_DISHONORED_BILL",
            "AMOUNT_IE_IMPORT",
            "AMOUNT_IE_EXPORT",
            "TRADE_BALANCE",
            "CURRENT_ACCOUNT_BALANCE_GAE",
            "INDEX_CONSUMER_PRICE_TOTAL",
            "INDEX_PRODUCER_PRICE_TOTAL",
            "EXPORT_PRICE_INDEX",
            "IMPORT_PRICE_INDEX",
            "EXPORT_AMOUNT_INDEX",
            "IMPORT_AMOUNT_INDEX",
            "MONETARY_SUPPLY_M0",
            "MONETARY_SUPPLY_M1",
            "MONETARY_SUPPLY_M2",
            "FED_FUND_RATE",
            "INDU_PRODUCTION_INDEX_US",
            "BUSINESS_INVENTORY_US",
            "EMPLOY_NONAG_INDU_US",
            "NEW_UNEMPLOYMENT_AMOUNT_US",
            "RETAIL_SALES_US",
            "GDP_US",
            "PCE_US",
            "CSI_MICHIGAN_US",
            "DURABLE_GOODS_ORDERS_US",
            "MINING_INDU_PRODUCTION_INDEX_US",
            "CPI_US",
            "RATE_BOND_10Y_US",
            "RATE_BOND_2Y_US",
            "YIELD_CURVE_SPREAD_US",
            "DOLLAR_INDEX",
            "MONETARY_SUPPLY_M0_US",
            "MONETARY_SUPPLY_M1_US",
            "MONETARY_SUPPLY_M2_US",
            "FED_NATIONAL_ACTIVITY_INDEX",
        ],
        batch_size=100,
    )
    logger.info(f"{request_day} ECON 데이터 적재 완료")
