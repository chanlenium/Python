import os
from datetime import datetime

import pandas as pd
import paramiko
from airflow.models import Connection, Variable
from dateutil.relativedelta import relativedelta
from loguru import logger
from table.models.warehouse.kcredit_macro.efas.basic.d9_total_kbank_na import (  # 5번
    KcreditMacroEfasD9TotalKbankNa,
)
from table.models.warehouse.kcredit_macro.efas.basic.econ import (  # 2번
    KcreditMacroEfasEcon,
)
from table.models.warehouse.kcredit_macro.efas.basic.indu_common import (  # 6번
    KcreditMacroEfasInduCommon,
)
from table.models.warehouse.kcredit_macro.efas.basic.indu_special import (  # 4번
    KcreditMacroEfasInduSpecial,
)
from table.models.warehouse.kcredit_macro.efas.basic.ppi_index import (  # 3번
    KcreditMacroEfasPPIIndex,
)
from table.models.warehouse.kcredit_macro.efas.basic.raw import (  # 1번
    KcreditMacroEfasRaw,
)


def send_csv_file_sftp(request_day: str, db: str):
    """
    :return:
    """
    # 데이터 추출
    IT_EFAS_MACRO_RAW = pd.DataFrame(
        KcreditMacroEfasRaw.objects.using(db).order_by("-STD_YMD").values()
    ).to_csv(index=False)
    logger.info(f"IT_EFAS_MACRO_RAW 추출 완료")
    IT_EFAS_MACRO_ECON_DB = pd.DataFrame(
        KcreditMacroEfasEcon.objects.using(db).order_by("-STD_YM").values()
    ).to_csv(index=False)
    logger.info(f"IT_EFAS_MACRO_ECON_DB 추출 완료")
    IT_EFAS_PPI_INDEX = pd.DataFrame(
        KcreditMacroEfasPPIIndex.objects.using(db)
        .order_by("-STD_YM")
        .values("STD_YM", "GBN", "PPI")
    ).to_csv(index=False)
    logger.info(f"IT_EFAS_PPI_INDEX 추출 완료")
    IT_EFAS_INDU_SPECIAL_DB = pd.DataFrame(
        KcreditMacroEfasInduSpecial.objects.order_by("-STD_YM").using(db).values()
    ).to_csv(index=False)
    logger.info(f"IT_EFAS_INDU_SPECIAL_DB 추출 완료")
    IT_D9_TOTAL_KBANK_NA = pd.DataFrame(
        KcreditMacroEfasD9TotalKbankNa.objects.order_by("-STD_YY").using(db).values()
    ).to_csv(index=False)
    logger.info(f"IT_D9_TOTAL_KBANK_NA 추출 완료")
    IT_EFAS_INDU_COMMON_DB = pd.DataFrame(
        KcreditMacroEfasInduCommon.objects.order_by("-STD_YM").using(db).values()
    ).to_csv(index=False)
    logger.info(f"IT_EFAS_INDU_COMMON_DB 추출 완료")

    # csv_file 변수 생성
    csv_files = {
        "IT_EFAS_MACRO_RAW.csv": IT_EFAS_MACRO_RAW,
        "IT_EFAS_MACRO_ECON_DB.csv": IT_EFAS_MACRO_ECON_DB,
        "IT_EFAS_PPI_INDEX.csv": IT_EFAS_PPI_INDEX,
        "IT_EFAS_INDU_SPECIAL_DB.csv": IT_EFAS_INDU_SPECIAL_DB,
        "IT_D9_TOTAL_KBANK_API.csv": IT_D9_TOTAL_KBANK_NA,
        "IT_EFAS_INDU_COMMON_DB.csv": IT_EFAS_INDU_COMMON_DB,
    }

    # SFTP 연결
    sftp_connection = Connection.get_connection_from_secrets(
        conn_id="kcredit-hugraph-sftp"
    )
    logger.info(
        f"\n[host: {sftp_connection.host}]\n[port: {sftp_connection.port}]\n[user: {sftp_connection.login}]\nSFTP 연결 시작"
    )
    transport = paramiko.Transport((sftp_connection.host, sftp_connection.port))
    transport.connect(username=sftp_connection.login, password=sftp_connection.password)
    sftp = paramiko.SFTPClient.from_transport(transport)

    # 해당 일자 폴더 생성
    try:
        sftp.mkdir(f"/kcredit/{request_day}/")
    except OSError:
        logger.info(f"[{request_day}] 폴더가 이미 존재합니다.")

    # # 10일전 폴더 제거
    # # 10일전 date 구하기
    # ten_day_ago = datetime.strftime(
    #     datetime.strptime(request_day, "%Y%m%d") - relativedelta(days=10), "%Y%m%d"
    # )
    # try:
    #     remove_pash = f"/kcredit/{ten_day_ago}/"
    #     file_list = sftp.listdir(remove_pash)
    #     for file_name in file_list:
    #         file_path = remove_pash + file_name
    #         sftp.remove(file_path)
    #         logger.info(f"{file_path} removed successfully")
    #     sftp.rmdir(remove_pash)
    # except FileNotFoundError:
    #     logger.info(f"[{ten_day_ago}] 폴더가 존재하지 않습니다.")

    # 파일 전송
    for file_name, file_content in csv_files.items():
        remote_path = f"/kcredit/{request_day}/{file_name}"  # 하위 디렉토리 경로와 파일명 조합
        with sftp.file(remote_path, "w") as file:
            file.write(file_content)
            logger.info(f"[Table: {file_name}] 파일 전송 완료")

    # 연결 종료
    sftp.close()
    transport.close()
    logger.info("SFTP 연결 종료")
