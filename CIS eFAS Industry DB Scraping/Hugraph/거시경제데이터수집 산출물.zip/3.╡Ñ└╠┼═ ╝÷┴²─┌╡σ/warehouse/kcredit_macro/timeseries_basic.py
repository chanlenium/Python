import json
import pickle
import time
from datetime import datetime, timedelta, timezone
from io import StringIO

import SetupDjangoORM
import pandas as pd
from dateutil.relativedelta import relativedelta
from loguru import logger
from table.models.lake import DataLake
from table.models.warehouse.kcredit_macro import (
    KcreditMacroCrawlerTimeseriesBasic,
    KcreditMacroCrawlerUniverse,
)
from table.static.mapping.universe.kcredit import MAPPING_DATA
from tasks.warehouse.core.utils import hcode_generator, hcode_mapper, utils_io


def kama_timeseries_cleansing(
    db: str, request_day: str, request_day_date: datetime.date, year: str
):
    """
    kama의 timeseries_month 데이터를 전처리하는 코드입니다.
    :return:
    """
    # 1. 데이터를 가져옵니다.
    obj = (
        DataLake.objects.using(db)
        .filter(
            source_param__year=year,
            source="kama",
            endpoint="kcredit_timeseries",
            date=request_day_date,
        )
        .order_by("source_param", "-created_at")
        .distinct("source_param")[0]
    )
    data = obj.rawdata[request_day]

    motorDataFrame = pd.read_html(data)[2]
    motorDataFrame.rename(columns=motorDataFrame.iloc[1], inplace=True)
    motorDataFrame = motorDataFrame.iloc[2:]
    motorDataFrame = motorDataFrame[~motorDataFrame["월별"].isnull()]  # NaN제거

    # 월의 자릿수에 따라 한자리인 경우 앞에 '0'을 붙임
    def assignMonth(row):
        if int(row) >= 10:
            result = row
        else:
            result = "0" + row
        return result

    motorDataFrame["STD_YM"] = motorDataFrame["년도"].str[
        0:-1:1
    ].copy() + motorDataFrame["월별"].str[0:-1:1].copy().apply(
        assignMonth
    )  # str[start:stop:step])
    motorDataFrame = motorDataFrame[
        motorDataFrame["STD_YM"]
        <= datetime.strftime(
            datetime.now(timezone.utc) - relativedelta(months=1), "%Y%m"
        )
    ]
    motorDataFrame = motorDataFrame[
        ~(
            (motorDataFrame[["생산", "내수", "수출(수량)", "수출(금액)"]] == "0").all(
                axis=1
            )
        )
    ]

    # empty Dataframe을 만들고(자동차 생산수량_월) 데이터 채움
    dfMOTOR_PROD_QUAN = pd.DataFrame(columns=["date", "value", "hcode"])
    dfMOTOR_PROD_QUAN[["date", "value"]] = motorDataFrame[["STD_YM", "생산"]]
    dfMOTOR_PROD_QUAN["hcode"] = "PrdStats-KCREDIT-KAMA-D-106-M"

    # empty Dataframe을 만들고(자동차 내수판매수량_월) 데이터 채움
    dfMOTOR_DOME_QUAN = pd.DataFrame(columns=["date", "value", "hcode"])
    dfMOTOR_DOME_QUAN[["date", "value"]] = motorDataFrame[["STD_YM", "내수"]]
    dfMOTOR_DOME_QUAN["hcode"] = "PrdStats-KCREDIT-KAMA-D-107-M"

    # empty Dataframe을 만들고(자동차 수출수량_월) 데이터 채움
    dfMOTOR_EXPORT_QUAN = pd.DataFrame(columns=["date", "value", "hcode"])
    dfMOTOR_EXPORT_QUAN[["date", "value"]] = motorDataFrame[["STD_YM", "수출(수량)"]]
    dfMOTOR_EXPORT_QUAN["hcode"] = "PrdStats-KCREDIT-KAMA-D-108-M"

    # empty Dataframe을 만들고(자동차 수출금액_월) 데이터 채움
    dfMOTOR_EXPORT_SALES = pd.DataFrame(columns=["date", "value", "hcode"])
    dfMOTOR_EXPORT_SALES[["date", "value"]] = motorDataFrame[["STD_YM", "수출(금액)"]]
    dfMOTOR_EXPORT_SALES["hcode"] = "PrdStats-KCREDIT-KAMA-D-109-M"

    motorIT_EFAS_MACRO_RAW = pd.concat(
        [
            dfMOTOR_PROD_QUAN,
            dfMOTOR_DOME_QUAN,
            dfMOTOR_EXPORT_QUAN,
            dfMOTOR_EXPORT_SALES,
        ]
    )
    motorIT_EFAS_MACRO_RAW["date"] = motorIT_EFAS_MACRO_RAW.apply(
        lambda x: x["date"] + "01", axis=1
    )
    motorIT_EFAS_MACRO_RAW.reset_index(drop=True)
    return motorIT_EFAS_MACRO_RAW


def tradlinx_timeseries_cleansing(
    db: str, request_day: str, request_day_date: datetime.date, year: str
):
    """
    tradlinx의 timeseries_month 데이터를 전처리하는 코드입니다.
    :param db:
    :param request_day:
    :param request_day_date:
    :return:
    """
    # 1. 데이터를 가져옵니다.
    obj = (
        DataLake.objects.using(db)
        .filter(
            source_param__year=year,
            source="tradlinx",
            endpoint="kcredit_timeseries",
            date=request_day_date,
        )
        .order_by("source_param", "-created_at")
        .distinct("source_param")[0]
    )
    data = pickle.loads(obj.rawdata_binary)[request_day][["STD_YMD", "MACRO_VALUE"]]
    # month데이터의 평균을 만듭니다.
    data.rename(columns={"STD_YMD": "date", "MACRO_VALUE": "value"}, inplace=True)
    data["date"] = data["date"].apply(lambda x: x[:6] + "01")
    data["hcode"] = "PrdStats-KCREDIT-TRADLINX-I-28-M"

    return data


def asiasis_timeseries_cleansing(
    db: str, request_day: str, request_day_date: datetime.date, year: str
):
    """
    asiasis의 timeseries_month 데이터를 전처리하는 코드입니다.
    :param db:
    :param request_day:
    :param request_day_date:
    :return:
    """
    # 1. 데이터를 가져옵니다.
    obj = (
        DataLake.objects.using(db)
        .filter(
            source_param__year=year,
            source="asiasis",
            endpoint="kcredit_timeseries",
            date=request_day_date,
        )
        .order_by("source_param", "-created_at")
        .distinct("source_param")[0]
    )
    res_df = pd.DataFrame(columns=["date", "value", "hcode"])
    data = obj.rawdata[request_day]
    df = pd.read_html(data)[0]
    df.rename(columns={0: "date", 1: "value", 2: "HR"}, inplace=True)
    df = df[["date", "value"]]
    df.drop(index=0, inplace=True)
    df.dropna(inplace=True)
    df.reset_index(drop=True, inplace=True)
    df["date"] = df.apply(lambda x: x["date"] + "01", axis=1)
    df["hcode"] = "PrdStats-KCREDIT-ASIASIS-I-27-M"
    res_df = pd.concat([res_df, df])

    res_df.drop_duplicates(subset=["date", "hcode"], keep=False, inplace=True)
    return res_df


def yahoo_timeseries_cleansing(
    db: str, request_day: str, request_day_date: datetime.date, year: str
):
    """
    yahoo의 timeseries_month 데이터를 전처리하는 코드입니다.
    :param db:
    :param request_day:
    :param request_day_date:
    :return:
    """
    # 1. 데이터를 가져옵니다.
    obj = (
        DataLake.objects.using(db)
        .filter(
            source_param__year=year,
            source="yahoo",
            endpoint="kcredit_timeseries",
            date=request_day_date,
        )
        .order_by("source_param", "-created_at")
        .distinct("source_param")[0]
    )
    data = obj.rawdata[request_day]
    df = pd.read_csv(StringIO(data))
    df = df[["Date", "Close"]]
    df.rename(columns={"Date": "date", "Close": "value"}, inplace=True)

    df["hcode"] = "PrdStats-KCREDIT-YAHOO-I-24-D"

    return df


value_list = [
    "PRODUC_INDEX",
    "PRODUC_INDEX_GAE",
    "SHIPMENT_INDEX",
    "SHIPMENT_INDEX_GAE",
    "INVENTORY_INDEX",
    "INVENTORY_INDEX_GAE",
    "OPER_RATE_INDEX",
    "OPER_RATE_INDEX_GAE",
    "EXPORT_MDOLLAR",
    "IMPORT_MDOLLAR",
]


def cal(series: pd.Series):
    series = series.astype(str)
    raw_list = []

    for value in value_list:
        raw_dict = {}
        raw_dict["date"] = series["STD_YM"] + "01"
        raw_dict["value"] = series[value]
        raw_dict["hcode"] = f"PrdStats-KCREDIT-ISTANS-{value}-{series['EFAS_CD']}"
        raw_list.append(raw_dict)
    raw_df = pd.DataFrame(raw_list)
    return raw_df


def istans_timeseries_cleansing(
    db: str, request_day: str, request_day_date: datetime.date, year: str
):
    """

    :param db:
    :param request_day:
    :param request_day_date:
    :return:
    """
    # Create the pandas DataFrame(empty frame)
    dfEFAStoISTANSMAP = pd.DataFrame(
        MAPPING_DATA, columns=["macro_code", "name_kor", "original_name_kor"]
    )
    # 1. 데이터를 가져옵니다.
    obj = (
        DataLake.objects.using(db)
        .filter(
            source_param__year=year,
            source="istans",
            endpoint="kcredit_timeseries",
            date=request_day_date,
        )
        .order_by("source_param", "-created_at")
        .distinct("source_param")[0]
    )
    df = pickle.loads(obj.rawdata_binary)[request_day]
    df.reset_index(inplace=True)
    raw_df = pd.DataFrame(columns=["date", "value", "hcode"])
    raw_list = []
    for i in range(len(df)):
        for value in value_list:
            raw_dict = {}
            raw_dict["date"] = df.iloc[i]["STD_YM"] + "01"
            raw_dict["value"] = df.iloc[i][value]
            raw_dict["hcode"] = (
                f"PrdStats-KCREDIT-ISTANS-{value}-{df.iloc[i]['EFAS_CD']}"
            )
            raw_list.append(raw_dict)
    raw_df = pd.concat([raw_df, pd.DataFrame(raw_list)])
    raw_df = raw_df.dropna(subset=["value"])

    return raw_df


def timeseries_basic_to_warehouse(db: str, request_day: str, **context):
    """
    신정원에서 요청한 kama의 month 데이터를 warehouse에 적재하는 코드입니다.
    :return:
    """
    start_time = time.time()
    logger.info(f"[WAREHOUSE][kcredit_macro_timeseries_basic][DB:{db}] START")
    request_day_date = datetime.strptime(request_day, "%Y%m%d").date()
    if "year" in context["dag_run"].conf:
        year = context["dag_run"].conf["year"]
    else:
        year = "daily"

    # 1. 각 소스별로 데이터 전처리
    cleansing_list = [
        kama_timeseries_cleansing(
            db=db, request_day=request_day, request_day_date=request_day_date, year=year
        ),
        tradlinx_timeseries_cleansing(
            db=db, request_day=request_day, request_day_date=request_day_date, year=year
        ),
        asiasis_timeseries_cleansing(
            db=db, request_day=request_day, request_day_date=request_day_date, year=year
        ),
        yahoo_timeseries_cleansing(
            db=db, request_day=request_day, request_day_date=request_day_date, year=year
        ),
        istans_timeseries_cleansing(
            db=db, request_day=request_day, request_day_date=request_day_date, year=year
        ),
    ]
    raw_df = pd.DataFrame(columns=["date", "value", "hcode"])
    for cleansing in cleansing_list:
        raw_df = pd.concat([raw_df, cleansing])

    # 2. 공통 데이터 전처리
    raw_df["date"] = raw_df["date"].replace("-", "", regex=True)
    raw_df["date"] = raw_df.apply(
        lambda x: datetime.strptime(x["date"], "%Y%m%d").date(), axis=1
    )

    # 3. hcode를 foreign key로 맵핑
    raw_df = hcode_mapper.hcode_foregin_key_bulk_mapper(
        db=db, django_model=KcreditMacroCrawlerUniverse, raw_df=raw_df
    )
    raw_df[raw_df.duplicated(subset=["hcode", "date"], keep=False)]

    # 4. 데이터 적재
    obj_list = []

    for raw in raw_df.to_dict(orient="records"):
        obj_list.append(KcreditMacroCrawlerTimeseriesBasic(**raw))

    KcreditMacroCrawlerTimeseriesBasic.objects.using(db).bulk_create(
        objs=obj_list,
        batch_size=1000,
        update_conflicts=True,
        update_fields=["value"],
        unique_fields=["hcode", "date"],
    )

    end_time = time.time()
    logger.info(
        f"[WAREHOUSE][kcredit_macro_timeseries_basic][DB:{db}] END {len(obj_list)} success. {timedelta(seconds=end_time - start_time)}, {request_day}"
    )


kama_timeseries_cleansing(
    "hugraph-prod", "20240412", datetime.date(2024, 4, 12), "2024"
)
