from datetime import datetime

import numpy as np
import pandas as pd
import SetupDjangoORM
from dateutil.relativedelta import relativedelta
from loguru import logger
from table.models.warehouse.kcredit_macro import (
    KcreditMacroEfasD9TotalKbankNa,
    KcreditMacroEfasMap,
)
from tasks.warehouse.core.kcredit_macro import kcredit_macro_cleansing, utils_io


def kcredit_raw_to_kbank_na(db: str, request_day: str, **context):
    """
    kcredit_macro_efas_raw 테이블에서 econ데이터만 삽입하는 함수입니다.
    전체적으로 Month 데이터 입니다.
    :return:
    """

    # if "year" in context["dag_run"].conf:
    # if request_day is None:
    #     year = context["dag_run"].conf["year"] + "0101"
    # else:
    #     year = (
    #         str(datetime.strptime(request_day, "%Y%m%d") - relativedelta(years=2))[:4]
    #         + "0101"
    #     )

    # =================================================== 1. 데이터 로드 ==================================================
    map_df = pd.DataFrame(
        KcreditMacroEfasMap.objects.using(db)
        .filter(it_d9_total_kbank_na=True)
        .values("source", "macro_gbn", "macro_code", "period", "calc", "column")
    )  # 데이터맵이 적재되어 있는 프레임
    map_df.rename(
        columns={"macro_gbn": "MACRO_GBN", "macro_code": "MACRO_CODE"}, inplace=True
    )

    # econ 데이터 로드 및 컬럼 설정
    value_df = pd.DataFrame()

    for year in range(2010, int(request_day[:4])):
        year_df = utils_io.kcredit_macro_io(
            db=db, filter_df=map_df[["MACRO_GBN", "MACRO_CODE"]], year=year
        )  # 계산전 데이터가 적재되어있는 프레임
        value_df = pd.concat([value_df, year_df])

    # 데이터에 column 추가
    value_df = value_df.merge(
        map_df[["MACRO_GBN", "MACRO_CODE", "column", "period", "calc"]],
        on=["MACRO_GBN", "MACRO_CODE"],
        how="left",
    )

    # Year 데이터 이므로 STD_YM 컬럼은 앞 4자리만 남기고 제거
    value_df["STD_YMD"] = value_df.apply(lambda x: x["STD_YMD"][:4], axis=1)

    # =================================================== 2. 데이터 계산 ==================================================
    result_df = value_df.groupby(by=["column", "STD_YMD"], as_index=False).apply(
        lambda x: x["MACRO_VALUE"].mean()
    )
    result_df.columns = ["column", "STD_YMD", "value"]
    result_df["value"] = result_df["value"].round(2)

    result_df = (
        result_df.pivot_table(
            index="STD_YMD",
            columns="column",
            values="value",
        )
        .reset_index()
        .rename(columns={"STD_YMD": "STD_YY"})
    )
    result_df = result_df[result_df["STD_YY"] < request_day[:4]]
    result_df.replace(np.nan, None, inplace=True)

    # 요구사항 반영
    # [요구사항1] 특정 데이터는 정수형으로만 제공
    result_df = result_df.astype(
        {
            "BUSINESS_LOAN": "int",
            "SMALL_MEDIUM_ENTERPRISES_LOAN": "int",
            "CURRENT_ACCOUNT": "int",
            "AMOUNT_IMPORTS": "int",
            "FOREIGN_EXCHANGE_RESERVE": "int",
        }
    )

    # [요구사항2] CHANGE_RATE_PRODUCER_PRICE 는 INDEX_PRODUCER_PRICE 데이터를 통해서 자체 계산
    calc_change_df = pd.concat(
        [pd.DataFrame([95.42]), result_df["INDEX_PRODUCER_PRICE"]]
    )
    result_df["CHANGE_RATE_PRODUCER_PRICE"] = (
        calc_change_df.pct_change()[1:].round(4) * 100
    )

    obj_list = []

    for save in result_df.to_dict(orient="records"):
        obj_list.append(KcreditMacroEfasD9TotalKbankNa(**save))

    KcreditMacroEfasD9TotalKbankNa.objects.using(db).bulk_create(
        objs=obj_list,
        update_conflicts=True,
        unique_fields=["STD_YY"],
        update_fields=[
            "EXCHANGE_RATE_WON_DOLLAR",
            "EXCHANGE_RATE_WON_YEN",
            "RATE_BENCHMARK",
            "BUSINESS_LOAN",
            "SMALL_MEDIUM_ENTERPRISES_LOAN",
            "RATE_ECONOMIC_GROWTH",
            "CHANGE_RATE_PRIVATE_CONSUMPTION",
            "CHANGE_RATE_CAPITAL_INVEST",
            "RATE_UNEMPLOY_RATE",
            "RATE_EMPLOY",
            "INDEX_KOSPI",
            "INDEX_KOSDAQ",
            "INFLATION_RATE",
            "INDEX_PRODUCER_PRICE",
            "INDEX_CONSUMER_PRICE",
            "INDEX_CCS",
            "CHANGE_RATE_PRODUCER_PRICE",
            "RATE_DISHONORED_BILL",
            "RATE_CD",
            "RATE_BOND",
            "RATE_MANUFACTURING_OPERATION",
            "RATE_MANUFACT_INVENTORY_SALES",
            "CHANGE_RATE_COMSUMER_PRICE",
            "CURRENT_ACCOUNT",
            "RATE_GROSS_DOM_INVEST",
            "AMOUNT_IMPORTS",
            "FOREIGN_EXCHANGE_RESERVE",
        ],
    )
    logger.info(f"{request_day} KBANK 데이터 적재 완료")
