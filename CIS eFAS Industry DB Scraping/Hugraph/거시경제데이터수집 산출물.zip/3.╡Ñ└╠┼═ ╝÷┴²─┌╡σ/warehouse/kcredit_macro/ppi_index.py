from datetime import datetime

import pandas as pd
from dateutil.relativedelta import relativedelta
from loguru import logger
from table.models.warehouse.kcredit_macro import (
    KcreditMacroEfasMap,
    KcreditMacroEfasPPIIndex,
)
from tasks.warehouse.core.kcredit_macro.utils_io import kcredit_macro_io


def kcredit_raw_to_ppi_index(db: str, request_day: str, **context):
    """
    kcredit_macro_efas_raw 테이블에서 econ데이터만 삽입하는 함수입니다.
    전체적으로 Month 데이터 입니다.
    :return:
    """
    if "year" in context["dag_run"].conf:
        year = context["dag_run"].conf["year"] + "0101"
    else:
        year = (
            str(datetime.strptime(request_day, "%Y%m%d") - relativedelta(years=2))[:4]
            + "0101"
        )
    # =================================================== 1. 데이터 로드 ==================================================

    map_df = pd.DataFrame(
        KcreditMacroEfasMap.objects.using(db)
        .filter(it_efas_ppi_index=True)
        .values("source", "macro_gbn", "macro_code", "period", "calc", "column")
    )  # 데이터맵이 적재되어 있는 프레임
    map_df.rename(
        columns={"macro_gbn": "MACRO_GBN", "macro_code": "MACRO_CODE"}, inplace=True
    )

    # ppi_index 데이터 로드 및 컬럼 설정
    value_df = kcredit_macro_io(
        db=db, filter_df=map_df[["MACRO_GBN", "MACRO_CODE"]], year=year
    )  # 계산전 데이터가 적재되어있는 프레임

    # 데이터에 column 추가
    value_df = value_df.merge(
        map_df[["MACRO_GBN", "MACRO_CODE", "column", "period", "calc"]],
        on=["MACRO_GBN", "MACRO_CODE"],
        how="left",
    )

    # month데이터 이므로 STD_YM 컬럼은 앞 6자리만 남기고 제거
    value_df["STD_YMD"] = value_df.apply(lambda x: x["STD_YMD"][:6], axis=1)

    # =================================================== 2. 데이터 계산 ==================================================
    # 계산해야 하는 데이터 프레임
    calc_list_df = value_df[~value_df["calc"].isnull()]
    # 계산해야 하는 데이터 프레임 제거
    value_df = value_df[value_df["calc"].isnull()]

    for macro_group, tmp_df in calc_list_df.groupby(["column"]):
        """
        계산로직 추가
        """
        pass
    raw_df = value_df.pivot_table(
        index=["STD_YMD", "period"],
        columns="column",
        values="MACRO_VALUE",
    ).reset_index()
    raw_df.rename(
        columns={"MACRO_VALUE": "value", "period": "GBN", "STD_YMD": "STD_YM"},
        inplace=True,
    )
    raw_df["GBN"] = raw_df["GBN"].apply(lambda x: "1" if x == "M" else "2")
    raw_df = raw_df.where(pd.notna(raw_df), None)
    obj_list = []

    for save in raw_df.to_dict(orient="records"):
        obj_list.append(KcreditMacroEfasPPIIndex(**save))

    KcreditMacroEfasPPIIndex.objects.using(db).bulk_create(
        objs=obj_list,
        update_conflicts=True,
        unique_fields=["STD_YM", "GBN"],
        update_fields=["PPI"],
    )
    logger.info(f"{request_day} PPI 데이터 적재 완료")
