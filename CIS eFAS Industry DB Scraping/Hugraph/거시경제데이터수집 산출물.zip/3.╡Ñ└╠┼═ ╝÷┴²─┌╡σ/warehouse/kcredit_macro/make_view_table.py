import pandas as pd
import paramiko
import psycopg2
from airflow.models import Connection
from loguru import logger


def remake_kcredit_macro_sftp_to_view_table(db: str, request_day: str):
    """
    SFTP에 적재되어 있는 데이터를 가져와서 view테이블을 생성하는 함수입니다.
    :param request_day:
    :return:
    """
    # 테이블 목록 변수
    csv_files = {
        "IT_EFAS_MACRO_RAW": pd.DataFrame(),
        "IT_EFAS_MACRO_ECON_DB": pd.DataFrame(),
        "IT_EFAS_PPI_INDEX": pd.DataFrame(),
        "IT_EFAS_INDU_SPECIAL_DB": pd.DataFrame(),
        "IT_D9_TOTAL_KBANK_NA": pd.DataFrame(),
        "IT_EFAS_INDU_COMMON_DB": pd.DataFrame(),
    }

    # SFTP 연결
    sftp_connection = Connection.get_connection_from_secrets(
        conn_id="kcredit-hugraph-sftp"
    )
    transport = paramiko.Transport((sftp_connection.host, sftp_connection.port))
    transport.connect(username=sftp_connection.login, password=sftp_connection.password)
    sftp = paramiko.SFTPClient.from_transport(transport)
    logger.info(
        f"\n[host: {sftp_connection.host}]\n[port: {sftp_connection.port}]\n[user: {sftp_connection.login}]\nSFTP 연결 시작"
    )

    # 파일저장
    for csv_file in csv_files:
        df = sftp.open(f"kcredit/{request_day}/{csv_file}.csv")
        csv_files[csv_file] = pd.read_csv(df)

    # 연결 종료
    sftp.close()
    transport.close()
    logger.info("SFTP 연결 종료")

    # 데이터베이스 연결
    db_connection = Connection.get_connection_from_secrets(conn_id=db)
    conn = psycopg2.connect(
        dbname=db_connection.schema,
        user=db_connection.login,
        password=db_connection.password,
        host=db_connection.host,
        port=db_connection.port,
    )
    cur = conn.cursor()

    for table_name, csv_df in csv_files.items():
        # 타입 변경
        for column in csv_df.columns:
            if column.startswith("STD_"):
                csv_df[column] = csv_df[column].astype(str)

        # 열이름 가져오기 및 데이터 타입 지정
        columns = csv_df.columns.tolist()
        columns_value = '", "'.join(columns)

        # 데이터프레임의 데이터를 튜플 형태로 변환
        data = [tuple(row) for row in csv_df.to_numpy()]
        # 튜플 데이터를 문자열로 변환
        values = ",".join(
            cur.mogrify("(%s)" % ",".join(["%s"] * len(columns)), row).decode("utf-8")
            for row in data
        ).replace("'NaN'", "null")

        # 뷰테이블 제거
        delete_view_query = f"DROP VIEW IF EXISTS {table_name}"
        cur.execute(delete_view_query)
        logger.info(f"{table_name} VIEW 테이블 제거 완료")
        conn.commit()
        create_view_query = f'CREATE OR REPLACE VIEW {table_name} AS SELECT * FROM (VALUES {values}) AS data("{columns_value}")'
        # 뷰테이블 생성
        cur.execute(create_view_query)

        # 커밋
        conn.commit()
        logger.info(f"{table_name} VIEW 테이블 생성 완료")
