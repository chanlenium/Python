import re
from datetime import datetime

import pandas as pd
from dateutil.relativedelta import relativedelta
from loguru import logger
from table.models.warehouse.kcredit_macro import KcreditMacroEfasInduCommon
from table.models.warehouse.kcredit_macro.crawler import KcreditMacroCrawlerUniverse
from table.models.warehouse.kcredit_macro.crawler.timeseries.timeseries_basic import (
    KcreditMacroCrawlerTimeseriesBasic,
)


def kcredit_raw_to_econ(db: str, request_day: str, **context):
    """
    kcredit_macro_efas_raw 테이블에서 econ데이터만 삽입하는 함수입니다.
    전체적으로 Month 데이터 입니다.
    :return:
    """
    # =================================================== 1. 데이터 로드 ==================================================

    # if "year" in context["dag_run"].conf:
    #     year = context["dag_run"].conf["year"] + "0101"
    # else:
    #     year = (
    #             str(datetime.strptime(request_day, "%Y%m%d") - relativedelta(years=1))[:4]
    #             + "0101"
    #     )
    year = "20100101"
    # ====================== 1. 필요한 데이터 로드 ======================
    df = pd.DataFrame(
        KcreditMacroCrawlerTimeseriesBasic.objects.using(db)
        .filter(
            hcode__hcode__contains="ISTANS",
            date__gte=year,
        )
        .values("hcode", "date", "value")
    )
    universe_df = pd.DataFrame(
        KcreditMacroCrawlerUniverse.objects.using(db)
        .filter(
            source="istans",
        )
        .values("hcode", "macro_code", "name_kor")
    )
    # =============================================== 2. 데이터 합병 및 전처리 ===============================================
    df["columns"] = df.apply(
        lambda x: re.search("ISTANS-(.*?)-", x["hcode"]).group(1), axis=1
    )
    raw_df = df.merge(universe_df, on="hcode", how="left")
    raw_df.drop(columns="hcode", inplace=True)
    raw_df.rename(
        columns={"date": "STD_YMD", "macro_code": "EFAS_CD", "name_kor": "EFAS_NM"},
        inplace=True,
    )

    pivot_df = raw_df.pivot_table(
        index=["STD_YMD", "EFAS_CD", "EFAS_NM"],
        columns="columns",
        values="value",
    ).reset_index()
    pivot_df["STD_YMD"] = pivot_df["STD_YMD"].apply(lambda x: x.strftime("%Y%m"))

    # =============================================== 3. 데이터 적재 =====================================================
    obj_list = []
    for save in raw_df.to_dict(orient="records"):
        obj_list.append(KcreditMacroEfasInduCommon(**save))

    KcreditMacroEfasInduCommon.objects.using(db).bulk_create(
        objs=obj_list,
        update_conflicts=True,
        unique_fields=["STD_YMD", "EFAS_CD"],
        update_fields=[
            "EFAS_NM",
            "PRODUC_INDEX",
            "PRODUC_INDEX_GAE",
            "SHIPMENT_INDEX",
            "SHIPMENT_INDEX_GAE",
            "INVENTORY_INDEX",
            "INVENTORY_INDEX_GAE",
            "OPER_RATE_INDEX",
            "OPER_RATE_INDEX_GAE",
            "EXPORT_MDOLLAR",
            "IMPORT_MDOLLAR",
        ],
        batch_size=100,
    )
    logger.info(f"{request_day} indu_common 데이터 적재 완료")
