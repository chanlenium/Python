from datetime import datetime, timezone

import pandas as pd
from dateutil.relativedelta import relativedelta
from loguru import logger
from table.models.warehouse.kcredit_macro import (
    KcreditMacroEfasInduSpecial,
    KcreditMacroEfasMap,
)
from tasks.warehouse.core.kcredit_macro import kcredit_macro_cleansing, utils_io


def kcredit_raw_to_indu_speclal(db: str, **context):
    """
    kcredit_macro_efas_raw 테이블에서 econ데이터만 삽입하는 함수입니다.
    전체적으로 Month 데이터 입니다.
    :return:
    """
    if "year" in context["dag_run"].conf:
        year = context["dag_run"].conf["year"] + "0101"
    else:
        year = str(datetime.now(timezone.utc) - relativedelta(years=2))[:4] + "0101"

    # =================================================== 1. 데이터 로드 ==================================================

    map_df = pd.DataFrame(
        KcreditMacroEfasMap.objects.using(db)
        .filter(it_efas_indu_special=True)
        .values("source", "macro_gbn", "macro_code", "period", "calc", "column")
    )  # 데이터맵이 적재되어 있는 프레임
    map_df.rename(
        columns={"macro_gbn": "MACRO_GBN", "macro_code": "MACRO_CODE"}, inplace=True
    )

    # ppi_index 데이터 로드 및 컬럼 설정
    value_df = utils_io.kcredit_macro_io(
        db=db, filter_df=map_df[["MACRO_GBN", "MACRO_CODE"]], year=year
    )  # 계산전 데이터가 적재되어있는 프레임

    # 데이터에 column 추가
    value_df = value_df.merge(
        map_df[["MACRO_GBN", "MACRO_CODE", "column", "period", "calc"]],
        on=["MACRO_GBN", "MACRO_CODE"],
        how="left",
    )

    # month데이터 이므로 STD_YM 컬럼은 앞 6자리만 남기고 제거
    value_df["STD_YMD"] = value_df.apply(lambda x: x["STD_YMD"][:6], axis=1)

    # =================================================== 2. 데이터 계산 ==================================================
    # 계산해야 하는 데이터 프레임
    calc_list_df = value_df[~value_df["calc"].isnull()]
    # 계산해야 하는 데이터 프레임 제거
    value_df = value_df[value_df["calc"].isnull()]

    for macro_group, tmp_df in calc_list_df.groupby(["column"]):
        # D -> M 평균
        if tmp_df.iloc[0]["period"] == "D" and tmp_df.iloc[0]["calc"] == "M":
            value_df = pd.concat(
                [
                    value_df,
                    kcredit_macro_cleansing.kcredit_day_average_to_month(df=tmp_df),
                ]
            )
        elif tmp_df.iloc[0]["period"] == "W" and tmp_df.iloc[0]["calc"] == "M":
            value_df = pd.concat([value_df, tmp_df])
    raw_df = value_df.pivot_table(
        index="STD_YMD",
        columns="column",
        values="MACRO_VALUE",
    ).reset_index()
    raw_df.rename(columns={"STD_YMD": "STD_YM"}, inplace=True)
    raw_df = raw_df.where(pd.notna(raw_df), None)

    # 필라델피아 지수는 월말 데이터가 적재되어야 평균을 계산하여 제공합니다.
    raw_df.at[len(raw_df) - 1, "SEMI_PHILADELPHIA"] = None

    obj_list = []

    for save in raw_df.to_dict(orient="records"):
        obj_list.append(KcreditMacroEfasInduSpecial(**save))

    KcreditMacroEfasInduSpecial.objects.using(db).bulk_create(
        objs=obj_list,
        update_conflicts=True,
        unique_fields=["STD_YM"],
        update_fields=[
            "MOTOR_PROD_QUAN",
            "MOTOR_DOME_QUAN",
            "MOTOR_EXPORT_QUAN",
            "MOTOR_EXPORT_SALES",
            "STEEL_PRICE",
            "STEEL_CRUDE_QUAN",  # 철강
            "SEMI_PHILADELPHIA",  # 필라
            "OIL_IMPORT_QUAN",
            "OIL_EXPORT_QUAN",
            "OIL_DOME_QUAN",
            "HAEWOON_BDI",
            "HAEWOON_SCFI",
            "HAEWOON_DUBAI",
            "CONST_DOME_ORDER_QUAN",
            "CONST_REAL_PRICE",
            "CONST_UNSOLD_URBAN",  # 서울, 경기로 나누어져 있음
            "CONST_UNSOlD_RURAL",
            "CONST_HOUSE_PRICE",
        ],
    )
    logger.info(f"{year} INDU_SPECIAL 데이터 적재 완료")
