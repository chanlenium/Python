import time
from datetime import datetime, timedelta

import SetupDjangoORM
from loguru import logger
from table.models.warehouse.stats_ecos import StatsEcosTimeSeriesDay, StatsEcosUniverse
from tasks.warehouse.core.ecos import ecos_cleansing, ecos_io
from tasks.warehouse.core.utils import hcode_generator, hcode_mapper, type_changer


def stats_ecos_timeseries_day_data_to_warehouse(db: str, request_day: str):
    """
    모든 데이터를 저장하는 함수입니다,.
    :param db:
    :param request_day:
    :return:
    """
    start_time = time.time()
    logger.info(f"[WAREHOUSE][stats_ecos_timeseries_day][DB:{db}] START")
    category = "D"

    # 데이터 로드
    logger.info(f"[WAREHOUSE][stats_ecos_timeseries_day] Data Loading..")

    load_data = ecos_io.ecos_datalake_data_fetch_only_is_use(
        db=db, request_day=request_day, universe_type="stats", quarter=category
    )
    if load_data.empty == True:
        end_time = time.time()
        logger.info(
            f"[WAREHOUSE][stats_ecos_timeseries_day][DB:{db}] no {category} data] END 0 success. {timedelta(seconds=end_time - start_time)}, {request_day}"
        )
        return 0

    # 데이터 선별
    raw_df = load_data[
        load_data["TIME"].apply(
            ecos_cleansing.ecos_period_logic_preprocessing, category=category
        )
    ].reset_index(drop=True)

    # 해당하는 주기(D, S, M, A 등등)에 데이터가 없을수도 있기에, 데이터가 없다면 다음으로 넘어가는코드입니다.
    if raw_df.empty == True:
        end_time = time.time()
        logger.info(
            f"[WAREHOUSE][stats_ecos_timeseries_day][DB:{db}] no {category} data] END 0 success. {timedelta(seconds=end_time - start_time)}, {request_day}"
        )
    else:
        # 선별된 데이터에 대해 날짜 수정
        raw_df["TIME"] = raw_df.apply(
            lambda x: ecos_cleansing.ecos_category_date_revise(
                one_date=x["TIME"], category=category
            ),
            axis=1,
        )

        # 사용할 컬럼만 설정 및 추가
        raw_df = raw_df[
            [
                "TIME",
                "DATA_VALUE",
                "ITEM_CODE1",
                "ITEM_CODE2",
                "ITEM_CODE3",
                "ITEM_CODE4",
                "STAT_CODE",
            ]
        ]

        raw_df.rename(columns={"STAT_CODE": "stats_code"}, inplace=True)

        # hcode작성을위해 벨류값을 비어있는 str로 바꿔줍니다.
        raw_df = raw_df.fillna(value="")

        # hcode 생성
        raw_df["hcode"] = raw_df.apply(
            lambda x: hcode_generator.stats_ecos_hcode_generator(
                series=x, category=category
            ),
            axis=1,
        )

        # hcode 매핑
        raw_df = hcode_mapper.hcode_foregin_key_bulk_mapper(
            db=db, django_model=StatsEcosUniverse, raw_df=raw_df
        )

        # 더미 칼럼 제거
        raw_df.drop(
            columns=[
                "ITEM_CODE1",
                "ITEM_CODE2",
                "ITEM_CODE3",
                "ITEM_CODE4",
                "stats_code",
            ],
            inplace=True,
        )

        # 칼럼 이름 변경
        raw_df.rename(columns={"TIME": "date", "DATA_VALUE": "value"}, inplace=True)

        # 타입변경
        raw_df["value"] = raw_df.apply(
            lambda x: type_changer.ecos_str_to_decimal(input_str=x["value"]), axis=1
        )

        obj_list = []

        for saving in raw_df.to_dict("records"):
            obj_list.append(StatsEcosTimeSeriesDay(**saving))

        StatsEcosTimeSeriesDay.objects.using(db).bulk_create(
            objs=obj_list,
            update_conflicts=True,
            batch_size=1000,
            unique_fields=["hcode", "date"],
            update_fields=["value"],
        )
        end_time = time.time()
        logger.info(
            f"[WAREHOUSE][stats_ecos_timeseries_day][DB:{db}] END {len(obj_list)} success. {timedelta(seconds=end_time - start_time)}, {request_day}"
        )
