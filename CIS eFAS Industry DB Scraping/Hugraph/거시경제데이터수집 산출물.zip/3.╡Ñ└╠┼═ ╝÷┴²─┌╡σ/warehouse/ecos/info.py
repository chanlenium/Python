import time
from datetime import datetime, timedelta

import SetupDjangoORM
from loguru import logger
from table.models.warehouse.stats_ecos import (
    StatsEcosGroupUniverse,
    StatsEcosInfo,
    StatsEcosUniverse,
)
from tasks.warehouse.core.ecos import ecos_io
from tasks.warehouse.core.utils import hcode_generator, hcode_mapper


def stats_ecos_info_to_warehouse(db: str, request_day: str):
    """
    Info정보를 채워넣는 함수입니다.
    WareHouseEcosMap 이 먼저 실행 되어야 합니다.
    WareHouseEcosUniverse 가 먼저 실행 되어야 합니다.
    :param db:
    :param request_day:
    :return:
    """
    start_time = time.time()

    logger.info(f"[WAREHOUSE][stats_ecos_info][DB:{db}] START")
    # 데이터 로드
    raw_df = ecos_io.ecos_datalake_data_fetch_only_is_use(
        db=db, request_day=request_day, universe_type="stats"
    )

    raw_df = raw_df[
        [
            "TIME",
            "STAT_CODE",
            "ITEM_CODE1",
            "ITEM_CODE2",
            "ITEM_CODE3",
            "ITEM_CODE4",
            "ITEM_NAME1",
            "ITEM_NAME2",
            "ITEM_NAME3",
            "ITEM_NAME4",
        ]
    ]

    # hcode 생성
    raw_df = raw_df.fillna(value="")
    raw_df.rename(columns={"STAT_CODE": "stats_code"}, inplace=True)
    raw_df["hcode"] = raw_df.apply(
        lambda x: hcode_generator.stats_ecos_hcode_generator(series=x), axis=1
    )

    # 중복제거
    raw_df.drop_duplicates(subset="hcode", inplace=True, ignore_index=True)

    # 컬럼명 변경
    raw_df.rename(
        columns={
            "ITEM_NAME1": "item1_name",
            "ITEM_NAME2": "item2_name",
            "ITEM_NAME3": "item3_name",
            "ITEM_NAME4": "item4_name",
            "ITEM_CODE1": "item1_code",
            "ITEM_CODE2": "item2_code",
            "ITEM_CODE3": "item3_code",
            "ITEM_CODE4": "item4_code",
        },
        inplace=True,
    )

    # hcode 매핑
    raw_df = hcode_mapper.hcode_foregin_key_bulk_mapper(
        db=db, django_model=StatsEcosUniverse, raw_df=raw_df
    )

    # stats_code 매핑
    raw_df = hcode_mapper.stats_code_foregin_key_bulk_mapper(
        db=db, django_model=StatsEcosGroupUniverse, raw_df=raw_df
    )

    obj_list = []

    raw_df.drop(columns="TIME", inplace=True)

    for saving in raw_df.to_dict("records"):
        obj_list.append(StatsEcosInfo(**saving))

    StatsEcosInfo.objects.using(db).bulk_create(
        objs=obj_list,
        batch_size=100,
        update_conflicts=True,
        unique_fields=["hcode", "stats_code"],
        update_fields=[
            "item1_name",
            "item2_name",
            "item3_name",
            "item4_name",
            "item1_code",
            "item2_code",
            "item3_code",
            "item4_code",
        ],
    )
    end_time = time.time()

    logger.info(
        f"[WAREHOUSE][stats_ecos_info][DB:{db}] END {len(obj_list)} success. {timedelta(seconds=end_time - start_time)}, {request_day}"
    )
