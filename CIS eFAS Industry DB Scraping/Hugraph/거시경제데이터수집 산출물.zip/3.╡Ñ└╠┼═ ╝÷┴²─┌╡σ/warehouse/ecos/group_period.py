import time
from datetime import datetime, timedelta

import pandas as pd
import SetupDjangoORM
from loguru import logger
from table.models.warehouse.stats_ecos import (
    StatsEcosGroupPeriod,
    StatsEcosGroupUniverse,
)
from tasks.warehouse.core.utils import hcode_mapper, type_changer, utils_io


def stats_ecos_group_period_to_warehouse(db: str, request_day: str):
    """
    WareHouseEcosMap 함수가 실행 되어야 합니다.
    LakeEcosListDetails 함수가 실행 되어야 합니다.
    :return:
    """
    start_time = time.time()

    logger.info(f"[WAREHOUSE][stats_ecos_group_period][DB:{db}] START")

    request_day_date = type_changer.date_format_changer(request_day)

    ### STEP 01. DataLake에서 데이터 가져와 DataFrame형태로 변경 =====================================
    obj = utils_io.datalake_data_fetcher_by_date(
        db=db, source="ecos", endpoint="group_detail", date=request_day_date
    )
    obj_df = pd.DataFrame(obj.rawdata[request_day])

    ### STEP 02. DataFrame과 저장될 Table간의 컬럼 동기화(rename, drop) =============================
    obj_df = obj_df[["CYCLE", "STAT_CODE", "START_TIME", "END_TIME"]]
    obj_df.rename(columns={"STAT_CODE": "stats_code"}, inplace=True)

    raw_df = pd.DataFrame()

    # 로컬코드로 그룹화시켜서 해당 로컬코드가 가지고 있는 데이터의 주기를 파악하는 함수입니다.
    stats_code_group = obj_df.groupby(["stats_code", "CYCLE"])

    for stats_info, stats_df in stats_code_group:
        # 중복제거를 통해 각 CYCLE(주기)별로 하나의 데이터만 남기는 코드입니다.
        # stats_df.drop_duplicates(subset=["CYCLE"], inplace=True)
        # stats_df.reset_index(drop=True, inplace=True)
        #
        one_df = pd.DataFrame(
            {
                "stats_code": stats_info[0],
                "period": stats_info[1],
                "start_date": stats_df.sort_values("START_TIME").iloc[0]["START_TIME"],
                "end_date": stats_df.sort_values("END_TIME").iloc[len(stats_df) - 1][
                    "END_TIME"
                ],
            },
            index=[0],
        )

        raw_df = pd.concat([one_df, raw_df])

    raw_df.reset_index(drop=True, inplace=True)

    # stats_code 매핑
    raw_df = hcode_mapper.stats_code_foregin_key_bulk_mapper(
        db=db, django_model=StatsEcosGroupUniverse, raw_df=raw_df
    )

    obj_list = []

    for stock in raw_df.to_dict("records"):
        obj_list.append(StatsEcosGroupPeriod(**stock))

    # warehouse에 적재
    StatsEcosGroupPeriod.objects.using(db).bulk_create(
        objs=obj_list,
        batch_size=100,
        update_conflicts=True,
        unique_fields=["stats_code", "period"],
        update_fields=[
            "start_date",
            "end_date",
        ],
    )
    end_time = time.time()
    logger.info(
        f"[WAREHOUSE][stats_ecos_group_period][DB:{db}] END {len(obj_list)} success. {timedelta(seconds=end_time - start_time)}, {request_day}"
    )
