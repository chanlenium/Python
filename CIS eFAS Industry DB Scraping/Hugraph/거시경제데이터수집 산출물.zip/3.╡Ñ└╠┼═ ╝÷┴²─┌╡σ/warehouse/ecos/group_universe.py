import re
import time
from datetime import datetime, timedelta

import pandas as pd
import SetupDjangoORM
from loguru import logger
from table.models.warehouse.stats_ecos import StatsEcosGroupUniverse
from table.static.columns.is_use import ecos as ecos_use
from table.static.columns.is_use import fx_ecos as fx_ecos_use
from table.static.columns.name_kor import ecos as ecos_name_kor
from table.static.columns.timeseries_category import ecos as ecos_category
from tasks.warehouse.core.utils import type_changer, utils_io


def stats_ecos_timeseries_category_preprocessing(stats_code: str) -> str:
    """
    timeseries_category를 넣어주는 함수입니다.
    * 참고사항
        - unit이 같다고 가정해도, 시간이 지나면 달라질 수 있습니다. 이에대한 해결 방안 등을 마련해야 합니다.
    :param raw_df:
    :return:
    """

    if stats_code in ecos_category.ECOS_TIMESERIES_CATEGORY_PERCENT:
        category = "Percent"
    elif stats_code in ecos_category.ECOS_TIMESERIES_CATEGORY_INDEX:
        category = "Index"
    elif stats_code in ecos_category.ECOS_TIMESERIES_CATEGORY_AMOUNT:
        category = "Amount"
    elif stats_code in ecos_category.ECOS_TIMESERIES_CATEGORY_TRADING:
        category = "Trading"
    elif stats_code in ecos_category.ECOS_TIMESERIES_CATEGORY_DELTA:
        category = "Delta"
    else:
        category = None

    return category


def stats_ecos_group_universe_to_warehouse(db: str, request_day: str):
    """
    map 테이블을 채우기 위한 함수입니다.
    LakeEcosList 함수가 먼저 실행되어야 합니다.
    LakeEcosListDetails 함수가 먼저 실행되어야 합니다.
    :param db:
    :param request_day:
    :return:
    """
    start_time = time.time()

    logger.info(f"[WAREHOUSE][stats_ecos_group_universe][DB:{db}] START")
    request_day_date = type_changer.date_format_changer(request_day)

    # 데이터 로드
    obj = utils_io.datalake_data_fetcher_by_date(
        db=db, source="ecos", endpoint="group_universe", date=request_day_date
    )

    raw_df = pd.DataFrame(obj.rawdata[request_day])

    # 필요한 컬럼만 사용
    raw_df = raw_df[["STAT_CODE", "STAT_NAME", "P_STAT_CODE", "SRCH_YN"]]

    # 컬럼명 변경
    raw_df.rename(
        columns={
            "STAT_CODE": "stats_code",
            "STAT_NAME": "full_name_kor",
            "P_STAT_CODE": "stats_p_code",
            "SRCH_YN": "has_data",
        },
        inplace=True,
    )

    # 이름 변경
    raw_df["name_kor"] = raw_df.apply(
        lambda x: re.sub("(.+?)\. ", "", x["full_name_kor"]), axis=1
    )

    # 카테고리 추가
    raw_df["timeseries_category"] = raw_df.apply(
        lambda x: stats_ecos_timeseries_category_preprocessing(
            stats_code=x["stats_code"]
        ),
        axis=1,
    )

    # has_data 추가
    raw_df["has_data"] = raw_df.apply(
        lambda x: False if x["has_data"] == "N" else True, axis=1
    )

    # =================================================================================================

    raw_df["is_use"] = raw_df["stats_code"].apply(
        lambda x: True if x in ecos_use.ECOS_USING_STATS_CODES else False
    )

    # ==================================================================================================
    # 이름 하드코딩된 이름으로 변경
    change_name_values = list(ecos_name_kor.ECOS_GROUP_UNIVERSE_NAME_KOR_MAP.values())
    change_name_keys = list(ecos_name_kor.ECOS_GROUP_UNIVERSE_NAME_KOR_MAP.keys())

    for i in range(len(change_name_values)):
        raw_df.loc[
            raw_df["name_kor"] == change_name_keys[i], "name_kor"
        ] = change_name_values[i]

    # ================================================================================================
    # universe_type 추가 [ stats ]
    raw_df["universe_type"] = raw_df.apply(
        lambda x: "fx"
        if x["stats_code"] in fx_ecos_use.FX_ECOS_USING_STATS_CODES
        else "stats",
        axis=1,
    )

    # ================================================================================================
    # 상폐여부만 DB에서 수정할뿐 아무것도 리턴하지 않습니다.
    # ecos_cleansing.data_delete_preprocessing(db=db, raw_df=raw_df)\
    # 테이블 적재
    obj_list = []
    for stats in raw_df.to_dict("records"):
        obj_list.append(StatsEcosGroupUniverse(**stats))

    StatsEcosGroupUniverse.objects.using(db).bulk_create(
        objs=obj_list,
        update_conflicts=True,
        unique_fields=["stats_code"],
        update_fields=[
            "full_name_kor",
            "name_kor",
            "stats_p_code",
            "is_use",
            "has_data",
            "timeseries_category",
            "unit",
            "universe_type",
        ],
    )

    end_time = time.time()
    logger.info(
        f"[WAREHOUSE][stats_ecos_group_universe][DB:{db}] END {len(obj_list)} success. {timedelta(seconds=end_time - start_time)}, {request_day}"
    )
