import time
from datetime import datetime, timedelta

import pandas as pd
import SetupDjangoORM
from loguru import logger

# 필요한 테이블
from table.models.warehouse.stats_ecos import StatsEcosGroupUniverse, StatsEcosUniverse
from table.static.columns.name_kor import ecos as ecos_name_kor
from tasks.warehouse.core.ecos import ecos_cleansing, ecos_io
from tasks.warehouse.core.utils import hcode_generator, hcode_mapper


def stats_ecos_universe_to_warehouse(db: str, request_day: str):
    """
    universe테이블에 적재하는 코드입니다.

    - WareHouseEcosMap이 먼저 실행 되어야 합니다.
    - LakeEcosData를 먼저 실행하셔야 합니다
    :param db:
    :param request_day:
    :return:
    """
    start_time = time.time()

    logger.info(f"[WAREHOUSE][stats_ecos_universe][DB:{db}] START")

    # 데이터 로드
    raw_df = ecos_io.ecos_datalake_data_fetch_only_is_use(
        db=db, request_day=request_day, universe_type="stats"
    )

    # 데이터 전처리
    # 필요한 컬럼만 사용

    raw_df = raw_df[
        [
            "TIME",
            "STAT_CODE",
            "STAT_NAME",
            "ITEM_CODE1",
            "ITEM_CODE2",
            "ITEM_CODE3",
            "ITEM_CODE4",
            "UNIT_NAME",
            "ITEM_NAME1",
            "ITEM_NAME2",
            "ITEM_NAME3",
            "ITEM_NAME4",
        ]
    ]
    # 컬럼명 변경
    raw_df.rename(
        columns={
            "STAT_CODE": "stats_code",
            "P_STAT_CODE": "group",
            "UNIT_NAME": "unit",
            "ITEM_NAME1": "NM1",
            "ITEM_NAME2": "NM2",
            "ITEM_NAME3": "NM3",
            "ITEM_NAME4": "NM4",
        },
        inplace=True,
    )
    # name을 넣기 위한 Data Load
    group_df = pd.DataFrame(
        StatsEcosGroupUniverse.objects.using(db).values("stats_code", "name_kor")
    )
    group_df.rename(columns={"name_kor": "full_name_kor"}, inplace=True)

    raw_df = pd.merge(group_df, raw_df, on="stats_code")

    # hcode 생성
    raw_df = raw_df.fillna(value="")
    raw_df["hcode"] = raw_df.apply(
        lambda x: hcode_generator.stats_ecos_hcode_generator(series=x), axis=1
    )

    # 이름변경 +
    raw_df["full_name_kor"] = raw_df.apply(
        lambda x: ecos_cleansing.ecos_stats_item_name_concat(series=x), axis=1
    )

    # 이름에 사용된 컬럼 제거
    raw_df.drop(columns=["NM1", "NM2", "NM3", "NM4"], inplace=True)

    # 컬럼 추가
    raw_df["category"] = "Statistics"
    raw_df["market"] = "ECOS"

    # loacl_code 생성
    raw_df["local_code"] = raw_df.apply(
        lambda x: ecos_cleansing.stats_ecos_local_code_generator(series=x), axis=1
    )

    # hcode관련 컬럼 드랍 및 중복제거
    raw_df.drop(
        columns=[
            "ITEM_CODE1",
            "ITEM_CODE2",
            "ITEM_CODE3",
            "ITEM_CODE4",
            "STAT_NAME",
            "TIME",
        ],
        inplace=True,
    )
    raw_df.drop_duplicates(subset=["hcode"], ignore_index=True, inplace=True)

    # 먼저 맵에서 상폐 되었는지 확인하기위해 맵데이터를 가져오는 함수입니다.
    map_df = pd.DataFrame(
        StatsEcosGroupUniverse.objects.using(db)
        .filter(is_delisted=False)
        .values("stats_code", "is_delisted")
    )

    # 머지를 통해 상폐되었다면
    raw_df = pd.merge(raw_df, map_df, on="stats_code", how="left").replace("", None)

    # stats_code 매핑
    raw_df = hcode_mapper.stats_code_foregin_key_bulk_mapper(
        db=db, django_model=StatsEcosGroupUniverse, raw_df=raw_df
    )

    # 하드코딩 이름 변경
    change_name_values = list(ecos_name_kor.ECOS_UNIVERSE_NAME_KOR_MAP.values())
    change_name_keys = list(ecos_name_kor.ECOS_UNIVERSE_NAME_KOR_MAP.keys())

    for i in range(len(change_name_values)):
        raw_df.loc[
            raw_df["hcode"] == change_name_keys[i], "full_name_kor"
        ] = change_name_values[i]

    # 테이블 적재
    obj_list = []

    for stats in raw_df.to_dict("records"):
        obj_list.append(StatsEcosUniverse(**stats))

    StatsEcosUniverse.objects.using(db).bulk_create(
        objs=obj_list,
        update_conflicts=True,
        unique_fields=["hcode", "stats_code"],
        batch_size=100,
        update_fields=[
            "full_name_kor",
            "category",
            "market",
            "local_code",
            "is_delisted",
            "unit",
        ],
    )

    end_time = time.time()
    logger.info(
        f"[WAREHOUSE][stats_ecos_universe][DB:{db}] END {len(obj_list)} success. {timedelta(seconds=end_time - start_time)}, {request_day}"
    )
