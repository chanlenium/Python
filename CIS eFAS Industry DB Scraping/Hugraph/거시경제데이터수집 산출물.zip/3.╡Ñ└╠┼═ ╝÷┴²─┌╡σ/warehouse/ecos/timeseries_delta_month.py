import time
from datetime import datetime, timedelta

from loguru import logger
from numpy import nan
from table.models.warehouse.stats_ecos import (
    StatsEcosGroupPeriod,
    StatsEcosTimeSeriesDay,
    StatsEcosTimeSeriesDeltaMonth,
    StatsEcosTimeSeriesMonth,
    StatsEcosUniverse,
)
from tasks.warehouse.core.ecos import ecos_calc
from tasks.warehouse.core.utils import hcode_mapper


def stats_ecos_timeseries_delta_month_to_warehouse(db: str, request_day: str):
    # 사용하는 모델 정의
    models_list = {
        "[D]Month(Day)": [StatsEcosTimeSeriesDeltaMonth, StatsEcosTimeSeriesDay],
        "[M]Month": [StatsEcosTimeSeriesDeltaMonth, StatsEcosTimeSeriesMonth],
    }

    # 로그
    start_time = time.time()
    logger.info(
        f"[WAREHOUSE][stats_ecos_delta_month][{request_day}][DB:{db}][RequestDay : {request_day}] Warehouse"
    )
    save_len = 0
    # 모델 별로 반복
    for model_name, model in models_list.items():
        # 데이터를 가져올 날짜 구하기
        day_list = ecos_calc.stats_ecos_timeseries_delta_date_preprocessing(
            request_day=request_day, model_name=model_name
        )
        logger.info(f"[WAREHOUSE][stats_ecos_delta_month][{model_name}][{day_list}]")
        # 데이터 로드
        raw_df = ecos_calc.stats_timeseries_delta_load_data(
            db=db,
            day_list=day_list,
            model_name=model_name,
            model=model,
        )

        # 데이터 프레임이 비어있으면 패스
        if raw_df.empty:
            continue

        # hcode별로 동일한 날짜에 대해 적재되어 있으면 제거
        raw_df = raw_df.drop_duplicates(subset=["hcode", "date"])

        # 데이터 프레임이 하나면 패스
        if len(raw_df) == 1:
            continue

        # previous_value 채우기
        raw_df["previous_value"] = (
            raw_df.groupby("hcode")["value"].shift(-1).replace(nan, None)
        )

        # previous_value가 None인 즉 이전 데이터가 없는 필요없는 데이터 제거
        raw_df = raw_df[raw_df["previous_value"].notna()]

        if raw_df.empty is True:
            continue

        # 계산
        raw_df["after_value"] = raw_df.apply(
            lambda x: ecos_calc.calc_ecos_timeseries_delta(x), axis=1
        )

        # 컬럼 정리
        raw_df.drop(columns=["value", "previous_value"], inplace=True)
        raw_df.rename(columns={"after_value": "value"}, inplace=True)

        # hcode 매핑
        raw_df = hcode_mapper.hcode_foregin_key_bulk_mapper(
            db=db, raw_df=raw_df, django_model=StatsEcosUniverse
        )
        obj_list = []
        for save in raw_df.to_dict("records"):
            obj_list.append(model[0](**save))

        model[0].objects.using(db).bulk_create(
            objs=obj_list,
            update_conflicts=True,
            unique_fields=["hcode", "date"],
            batch_size=100,
            update_fields=[
                "value",
            ],
        )

        save_len += len(raw_df)
        end_time = time.time()
        logger.info(
            f"[WAREHOUSE][stats_ecos_delta_{model_name}][DB:{db}] WareHouse {len(raw_df)} END. {timedelta(seconds=end_time - start_time)}"
        )


def stats_ecos_timeseries_delta_month_one_datato_warehouse(
    db: str, request_day: str, **context
):
    # 사용하는 모델 정의
    models_list = {
        "[D]Month(Day)": [StatsEcosTimeSeriesDeltaMonth, StatsEcosTimeSeriesDay],
        "[M]Month": [StatsEcosTimeSeriesDeltaMonth, StatsEcosTimeSeriesMonth],
    }
    stats_code = context["dag_run"].conf["stats_code"]
    # 로그
    start_time = time.time()
    logger.info(
        f"[WAREHOUSE][stats_ecos_delta_month][{request_day}][DB:{db}][stats_code: {stats_code}][RequestDay : {request_day}] Warehouse"
    )
    save_len = 0
    # 모델 별로 반복
    for model_name, model in models_list.items():
        # date 설정
        stats_day_obj = (
            StatsEcosGroupPeriod.objects.using(db)
            .filter(stats_code=stats_code, period="M")
            .values("start_date", "end_date", "period")
        )
        if len(stats_day_obj) == 0:
            logger.info(
                f"[WAREHOUSE][stats_ecos_delta_{model_name}][DB:{db}][stats_code: {stats_code}][request_day: {request_day}] WareHouse 0 END."
            )
            continue
        stats_day_dict = ecos_calc.ecos_period_date_change(
            stats_day_dict=stats_day_obj[0]
        )

        request_day_list = ecos_calc.get_dates_between(
            start_day=stats_day_dict["start_date"],
            end_day=stats_day_dict["end_date"],
            delta="month",
        )

        # 데이터를 가져올 날짜 구하기
        day_list = [
            datetime.strptime(request_day_list[0], "%Y%m%d"),
            datetime.strptime(request_day_list[-1], "%Y%m%d"),
        ]

        # 데이터 로드
        raw_df = ecos_calc.stats_timeseries_delta_stats_code_filter_load_data(
            db=db,
            day_list=day_list,
            model_name=model_name,
            model=model,
            stats_code=stats_code,
            universe_model=StatsEcosUniverse,
        )

        # 데이터 프레임이 비어있으면 패스
        if raw_df.empty:
            logger.info(
                f"[WAREHOUSE][stats_ecos_delta_{model_name}][DB:{db}][stats_code: {stats_code}][request_day: {request_day}] WareHouse {len(raw_df)} END."
            )
            continue

        # hcode별로 동일한 날짜에 대해 적재되어 있으면 제거
        raw_df = raw_df.drop_duplicates(subset=["hcode", "date"])

        # previous_value 채우기
        raw_df["previous_value"] = (
            raw_df.groupby("hcode")["value"].shift(-1).replace(nan, None)
        )

        # previous_value가 None인 즉 이전 데이터가 없는 필요없는 데이터 제거
        raw_df = raw_df[raw_df["previous_value"].notna()]

        if raw_df.empty is True:
            logger.info(
                f"[WAREHOUSE][stats_ecos_delta_{model_name}][DB:{db}][stats_code: {stats_code}][request_day: {request_day}] WareHouse {len(raw_df)} END."
            )
            continue

        # 계산
        raw_df["after_value"] = raw_df.apply(
            lambda x: ecos_calc.calc_ecos_timeseries_delta(x), axis=1
        )

        # 컬럼 정리
        raw_df.drop(columns=["value", "previous_value"], inplace=True)
        raw_df.rename(columns={"after_value": "value"}, inplace=True)

        # hcode 매핑
        raw_df = hcode_mapper.hcode_foregin_key_bulk_mapper(
            db=db, raw_df=raw_df, django_model=StatsEcosUniverse
        )
        obj_list = []
        for save in raw_df.to_dict("records"):
            obj_list.append(model[0](**save))

        model[0].objects.using(db).bulk_create(
            objs=obj_list,
            update_conflicts=True,
            unique_fields=["hcode", "date"],
            batch_size=100,
            update_fields=[
                "value",
            ],
        )
        end_time = time.time()
        logger.info(
            f"[WAREHOUSE][stats_ecos_delta_{model_name}][DB:{db}][stats_code: {stats_code}] WareHouse {len(raw_df)}END. {timedelta(seconds=end_time - start_time)}"
        )
