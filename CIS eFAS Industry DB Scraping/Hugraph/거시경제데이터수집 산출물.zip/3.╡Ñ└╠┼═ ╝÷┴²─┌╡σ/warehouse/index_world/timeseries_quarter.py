import json
import time
from datetime import timedelta

import pandas as pd
from loguru import logger
from numpy import nan
from table.models.warehouse.stats_index_world.basic import StatsIndexWorldUniverse
from table.models.warehouse.stats_index_world.timeseries import (
    StatsIndexWorldTimeSeriesQuarter,
)
from tasks.warehouse.core.index_world.index_world_io import (
    get_index_world_universe_data,
)
from tasks.warehouse.core.kosis.kosis_cleansing import kosis_category_date_revise
from tasks.warehouse.core.utils.hcode_generator import index_world_hcode_generator
from tasks.warehouse.core.utils.hcode_mapper import hcode_foregin_key_bulk_mapper
from tasks.warehouse.core.utils.local_code_generator import (
    index_world_local_code_generator,
)


def index_world_timeseries_quarter_to_warehouse(db: str, request_day: str, **context):
    """
    date가 1995, 1996, 1997 이런식으로 찍히는데, 이를 0101을 붙여줘서 적재한다
    ex) 1995 -> 19950101
    :param db:
    :param request_day:
    :return:
    """
    logger.info(f"[WAREHOUSE][stats_index_world_timeseries_quarter][DB:{db}] START")
    start_time = time.time()
    # 1. DATA LOAD
    if "stats_code" in context["dag_run"].conf:
        stats_code = context["dag_run"].conf["stats_code"]
        datalake_obj = get_index_world_universe_data(
            request_day=request_day, db=db, stats_code=stats_code
        )
    else:
        datalake_obj = get_index_world_universe_data(request_day=request_day, db=db)

    # 2. MAKE DATAFRAME
    raw_df = pd.DataFrame()
    for obj in datalake_obj:
        tmp = pd.DataFrame(
            pd.DataFrame(
                json.loads(obj.rawdata[request_day].replace("\n", "").replace("\r", ""))
            )
        )
        raw_df = pd.concat([raw_df, tmp])

    # 3. DATA CLEANSING
    raw_df = raw_df.replace(nan, "")
    raw_df = raw_df[raw_df["주기코드"] == "Q"]
    raw_df["local_code"] = raw_df.apply(
        lambda x: index_world_local_code_generator(x), axis=1
    )
    raw_df["hcode"] = raw_df.apply(
        lambda x: index_world_hcode_generator(x["통계표코드"], x["local_code"]), axis=1
    )
    raw_df = hcode_foregin_key_bulk_mapper(
        db=db, raw_df=raw_df, django_model=StatsIndexWorldUniverse
    )
    raw_df.rename(columns={"시점": "date", "값": "value"}, inplace=True)
    raw_df["date"] = raw_df.apply(
        lambda x: kosis_category_date_revise(one_date=x["date"], category=x["주기코드"]),
        axis=1,
    )
    raw_df = raw_df[["hcode", "date", "value"]]

    # 4. BULK CREATE
    obj_list = []
    for raw in raw_df.to_dict(orient="records"):
        obj_list.append(StatsIndexWorldTimeSeriesQuarter(**raw))

    StatsIndexWorldTimeSeriesQuarter.objects.using(db).bulk_create(
        obj_list,
        batch_size=1000,
        update_fields=["value"],
        update_conflicts=True,
        unique_fields=["hcode", "date"],
    )
    end_time = time.time()
    logger.info(
        f"[WAREHOUSE][stats_index_world_timeseries_quarter][DB:{db}] END {len(obj_list)} success. {timedelta(seconds=end_time - start_time)}, {request_day}"
    )
    return len(obj_list)
