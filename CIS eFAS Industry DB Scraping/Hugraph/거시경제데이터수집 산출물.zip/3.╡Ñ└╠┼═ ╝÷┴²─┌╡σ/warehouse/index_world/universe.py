import json
import time
from datetime import datetime, timedelta

import pandas as pd
from loguru import logger
from numpy import nan
from table.models.lake.datalake import DataLake
from table.models.warehouse.stats_index_world.basic import StatsIndexWorldUniverse
from table.models.warehouse.stats_index_world.group import StatsIndexWorldGroupUniverse
from tasks.warehouse.core.index_world.index_world_io import (
    get_index_world_universe_data,
)
from tasks.warehouse.core.utils.hcode_generator import index_world_hcode_generator
from tasks.warehouse.core.utils.hcode_mapper import stats_code_foregin_key_bulk_mapper
from tasks.warehouse.core.utils.local_code_generator import (
    index_world_local_code_generator,
)


def index_world_universe_to_warehouse(db: str, request_day: str, **context):
    """
    :param db:
    :param request_day:
    :return:
    """
    start_time = time.time()
    logger.info(f"[WAREHOUSE][stats_index_world_universe][DB:{db}] START")

    # 1. DATA LOAD
    if "stats_code" in context["dag_run"].conf:
        stats_code = context["dag_run"].conf["stats_code"]
        datalake_obj = get_index_world_universe_data(
            request_day=request_day, db=db, stats_code=stats_code
        )
    else:
        datalake_obj = get_index_world_universe_data(request_day=request_day, db=db)

    # 2. MAKE DATAFRAME
    raw_df = pd.DataFrame()
    for obj in datalake_obj:
        tmp = pd.DataFrame(
            json.loads(obj.rawdata[request_day].replace("\n", "").replace("\r", ""))
        )

        raw_df = pd.concat([raw_df, tmp])

    # 3. DATA CLEANSING
    raw_df = raw_df.replace(nan, "")
    raw_df["local_code"] = raw_df.apply(
        lambda x: index_world_local_code_generator(x), axis=1
    )
    raw_df = raw_df.drop_duplicates(subset=["local_code"], keep="first")
    raw_df["hcode"] = raw_df.apply(
        lambda x: index_world_hcode_generator(x["통계표코드"], x["local_code"]), axis=1
    )
    raw_df["full_name_kor"] = raw_df.apply(
        lambda x: f"{x['통계표명']} {x['항목이름']} {x['분류1이름']}", axis=1
    )
    raw_df.rename(columns={"단위": "unit", "통계표코드": "stats_code"}, inplace=True)
    raw_df = raw_df[["full_name_kor", "hcode", "stats_code", "unit", "local_code"]]
    raw_df = stats_code_foregin_key_bulk_mapper(
        db=db, raw_df=raw_df, django_model=StatsIndexWorldGroupUniverse
    )

    obj_list = []
    for raw in raw_df.to_dict(orient="records"):
        obj_list.append(StatsIndexWorldUniverse(**raw))

    StatsIndexWorldUniverse.objects.using(db).bulk_create(
        obj_list,
        batch_size=1000,
        unique_fields=["hcode", "stats_code"],
        update_conflicts=True,
        update_fields=["full_name_kor", "unit", "local_code"],
    )
    end_time = time.time()
    logger.info(
        f"[WAREHOUSE][stats_index_world_universe][DB:{db}] END {len(obj_list)} success. {timedelta(seconds=end_time - start_time)}, {request_day}"
    )
    return len(obj_list)
