import time
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta

import pandas as pd
from loguru import logger
from table.models.warehouse.stats_index_world.group.group_universe import (
    StatsIndexWorldGroupUniverse,
)
from tasks.warehouse.core.utils import utils_io


def make_index_world_dataframe_from_xml(xml_str: str) -> pd.DataFrame:
    """
    xml 데이터를 데이터프레임으로 만들어주는 함수입니다.
    :return:
    """
    root = ET.fromstring(xml_str)

    data_dict = {
        "지표체계": [],
        "지표코드": [],
        "지표명": [],
        "수치수정일": [],
        "의미분석수정일": [],
        "지표조회수": [],
        "통계표코드": [],
        "통계표명": [],
        "통계표구분": [],
    }

    # XML에서 데이터를 추출하여 딕셔너리에 저장합니다.
    for indicator in root.findall(".//지표"):
        data_dict["지표체계"].append(indicator.find("지표체계").text)
        data_dict["지표코드"].append(indicator.find("지표코드").text)
        data_dict["지표명"].append(indicator.find("지표명").text)
        data_dict["수치수정일"].append(indicator.find("수치수정일").text)
        data_dict["의미분석수정일"].append(indicator.find("의미분석수정일").text)
        data_dict["지표조회수"].append(indicator.find("지표조회수").text)
        data_dict["통계표코드"].append(indicator.find(".//통계표코드").text)
        data_dict["통계표명"].append(indicator.find(".//통계표명").text)
        data_dict["통계표구분"].append(indicator.find(".//통계표구분").text)

    # 딕셔너리를 사용하여 데이터프레임을 생성합니다.
    df = pd.DataFrame(data_dict)

    return df


def index_world_group_universe_to_warehouse(db: str, request_day: str):
    """
    :return:
    """
    logger.info(f"[WAREHOUSE][fred_group_universe][DB:{db}][{request_day}] START")
    start_time = time.time()
    # 1. 데이터 로드
    request_day_date = datetime.strptime(request_day, "%Y%m%d").date()
    obj = utils_io.datalake_data_fetcher_by_date(
        db=db,
        source="index_world",
        endpoint="index_world_group_universe",
        date=request_day_date,
    )
    # 2. 데이터 프레임 제작
    raw_df = make_index_world_dataframe_from_xml(obj.rawdata[request_day])
    raw_df.rename(
        columns={
            "통계표코드": "stats_code",
            "지표코드": "ix_code",
            "지표명": "full_name_kor",
            "수치수정일": "modify_date",
        },
        inplace=True,
    )
    raw_df["modify_date"] = pd.to_datetime(raw_df["modify_date"], format="%Y%m%d")
    raw_df = raw_df[["stats_code", "ix_code", "full_name_kor", "modify_date"]]
    obj_list = []
    for raw in raw_df.to_dict("records"):
        obj_list.append(StatsIndexWorldGroupUniverse(**raw))

    StatsIndexWorldGroupUniverse.objects.using(db).bulk_create(
        objs=obj_list,
        unique_fields=["stats_code", "ix_code"],
        update_conflicts=True,
        update_fields=["modify_date", "full_name_kor"],
        batch_size=100,
    )
    end_time = time.time()
    logger.info(
        f"[WAREHOUSE][stats_ecos_group_period][DB:{db}] END {len(obj_list)} success. {timedelta(seconds=end_time - start_time)}, {request_day}"
    )
    return len(obj_list)
