import pandas as pd
import SetupDjangoORM
from loguru import logger
from table.models.warehouse.stats_kosis import (
    StatsKosisGroupPeriod,
    StatsKosisGroupUniverse,
)
from tasks.warehouse.core.utils import hcode_mapper, utils_io


def stats_kosis_itm_id_preprocessing(url_data_ist: dict) -> dict:
    """
    itm_id를 설정하는 함수입니다.
    :param url_data_ist:
    :return:
    """
    itm_id = ""
    for i in range(len(url_data_ist)):
        try:
            url_data_ist[i]["OBJ_ID_SN"]
        except KeyError:
            itm_id = url_data_ist[i]["ITM_ID"] + "+" + itm_id

    return itm_id


def stats_kosis_change_to_period_eng(period: str) -> str:
    """
    period 값을 ecos와 같이 eng로 맞추는 코드입니다.
    :param period:
    :return:
    """
    # date 타입 구하기
    if period == "일":
        date = "D"
    if period == "월":
        date = "M"
    if period == "분기":
        date = "Q"
    if period == "반기":
        date = "H"
    if period in ["년", "2년", "3년", "4년", "5년", "10년"]:
        date = "A"
    if period == "부정기":
        date = "IR"
    return date


def stats_kosis_group_period_to_warehouse(db: str, request_day: str):
    """
    period를 채워넣는 함수입니다.
    :param request_day:
    :param db:
    :return:
    """
    logger.info(
        f"[WAREHOUSE][COMMAND][DB:{db}] <STATS KOSIS Group Period> 추가 작업 START 🐳"
    )
    datalake_obj = utils_io.datalake_data_fetcher_by_date(
        db=db, source="kosis", endpoint="kosis_meta_data", date=request_day
    )
    obj_df = pd.DataFrame(datalake_obj.rawdata[request_day])

    # 데이터 리스트 생성
    data_list = []
    # 값 집어넣기
    for i in range(len(obj_df)):
        for j in range(len(obj_df.loc[i, 2])):
            data_list.append(
                {
                    "stats_code": obj_df.loc[i, 0][0]["TBL_ID"],
                    "period": obj_df.loc[i, 2][j]["PRD_SE"],
                    "start_date": obj_df.loc[i, 2][j]["STRT_PRD_DE"],
                    "end_date": obj_df.loc[i, 2][j]["END_PRD_DE"],
                    "org_code": obj_df.loc[i, 0][0]["ORG_ID"],
                    "obj_id_code": obj_df.loc[i, 1][len(obj_df.loc[i, 1]) - 1][
                        "OBJ_ID_SN"
                    ],
                    "itm_id": stats_kosis_itm_id_preprocessing(
                        url_data_ist=obj_df.loc[i, 1]
                    ),
                }
            )

    # 판다스 생성
    raw_df = pd.DataFrame(data_list)
    raw_df = hcode_mapper.stats_code_foregin_key_bulk_mapper(
        db=db, raw_df=raw_df, django_model=StatsKosisGroupUniverse
    )
    # period 컬럼 ecos처럼 통일하기
    raw_df["period"] = raw_df.apply(
        lambda x: stats_kosis_change_to_period_eng(period=x["period"]), axis=1
    )

    # 벌크저장
    obj_list = []

    for saving in raw_df.to_dict("records"):
        obj_list.append(StatsKosisGroupPeriod(**saving))

    StatsKosisGroupPeriod.objects.using(db).bulk_create(
        objs=obj_list,
        update_conflicts=True,
        unique_fields=["stats_code", "period"],
        update_fields=["start_date", "end_date", "org_code", "obj_id_code", "itm_id"],
        batch_size=100,
    )

    logger.info(f"[WAREHOUSE][COMMAND][DB:{db}] <STATS KOSIS Group Period> 추가 작업 END 🦊")
    utils_io.datalake_processed_at_update(datalake_obj=datalake_obj, db=db)
