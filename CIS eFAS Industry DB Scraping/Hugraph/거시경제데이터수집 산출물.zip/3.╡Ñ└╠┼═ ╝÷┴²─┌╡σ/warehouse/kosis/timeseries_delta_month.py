import time
from datetime import datetime, timedelta

import pandas as pd
import SetupDjangoORM
from dateutil.relativedelta import relativedelta
from loguru import logger
from numpy import nan
from table.models.warehouse.stats_kosis import (
    StatsKosisGroupPeriod,
    StatsKosisTimeSeriesDay,
    StatsKosisTimeSeriesDeltaMonth,
    StatsKosisTimeSeriesMonth,
    StatsKosisUniverse,
)
from tasks.warehouse.core.ecos import ecos_calc
from tasks.warehouse.core.utils import hcode_mapper


def make_stats_kosis_timeseries_delta_month_date(request_day: str) -> list:
    """
    한달치 date를 리스트로 만들어주는 함수입니다.
    :param request_day:
    :return:
    """
    stan_date = datetime.strptime(request_day, "%Y%m%d")
    date_list = [
        request_day,
        datetime.strftime(stan_date - relativedelta(months=1), "%Y%m%d"),
        datetime.strftime(stan_date - relativedelta(months=2), "%Y%m%d"),
        datetime.strftime(stan_date - relativedelta(months=3), "%Y%m%d"),
        datetime.strftime(stan_date - relativedelta(months=4), "%Y%m%d"),
    ]
    return date_list


def make_stats_kosis_timeseires_delta_month_date_list_by_stats_code(
    start_day: str = None, end_day: str = None
) -> list:
    """
    start_day와 end_day를 이용해 그 사이 month date를 list로 만들어 반환하는 함수입니다.
    ['20231111', '20231110', '20231109', '20231108' ...]
    :param start_day:
    :param end_day:
    :return:
    """
    start_date = datetime.strptime(
        start_day[:4] + start_day[5] + start_day[6] + "01", "%Y%m%d"
    ).date()
    end_date = datetime.strptime(
        end_day[:4] + end_day[5] + end_day[6] + "01", "%Y%m%d"
    ).date()

    delta = relativedelta(months=1)
    current_date = end_date
    date_list = []

    while current_date >= start_date:
        date_list.append(datetime.strftime(current_date, "%Y%m%d"))
        current_date -= delta

    return date_list


def stats_kosis_timeseries_delta_month_to_warehouse(
    db: str, request_day: str, **context
):
    if "stats_code" in context["dag_run"].conf:
        stats_code = context["dag_run"].conf["stats_code"]
        obj_df = pd.DataFrame(
            StatsKosisGroupPeriod.objects.using(db)
            .values(
                "start_date",
                "end_date",
            )
            .filter(period="M", stats_code=stats_code)
            .order_by("-stats_code_id")
        )
        if obj_df.empty:
            logger.info(
                f"[WAREHOUSE][stats_kosis_delta_Month][DB:{db}] WareHouse 0 END."
            )
            return 0
        date_list = make_stats_kosis_timeseires_delta_month_date_list_by_stats_code(
            start_day=obj_df.iloc[0]["start_date"], end_day=obj_df.iloc[0]["end_date"]
        )
    else:
        date_list = make_stats_kosis_timeseries_delta_month_date(
            request_day=request_day
        )
    for request_day in date_list:
        # 사용하는 모델 정의
        models_list = {
            "[D]Month(Day)": [StatsKosisTimeSeriesDeltaMonth, StatsKosisTimeSeriesDay],
            "[M]Month": [StatsKosisTimeSeriesDeltaMonth, StatsKosisTimeSeriesMonth],
        }

        # 로그
        start_time = time.time()
        logger.info(
            f"[WAREHOUSE][stats_kosis_delta_month][DB:{db}][{request_day[:6]}] Warehouse Start"
        )
        save_len = 0

        # 모델 별로 반복
        for model_name, model in models_list.items():
            # 데이터를 가져올 날짜 구하기
            day_list = ecos_calc.stats_ecos_timeseries_delta_date_preprocessing(
                request_day=request_day, model_name=model_name
            )
            if "stats_code" in context["dag_run"].conf:
                stats_code = context["dag_run"].conf["stats_code"]
                # 데이터 로드
                raw_df = ecos_calc.stats_timeseries_delta_stats_code_filter_load_data(
                    db=db,
                    day_list=day_list,
                    model_name=model_name,
                    model=model,
                    stats_code=stats_code,
                    universe_model=StatsKosisUniverse,
                )
            else:
                # 데이터 로드
                raw_df = ecos_calc.stats_timeseries_delta_load_data(
                    db=db,
                    day_list=day_list,
                    model_name=model_name,
                    model=model,
                )
            # 데이터 프레임이 비어있으면 패스
            if raw_df.empty:
                continue

            # hcode별로 동일한 날짜에 대해 적재되어 있으면 제거
            raw_df = raw_df.drop_duplicates(subset=["hcode", "date"])

            # 데이터 프레임이 하나면 패스
            if len(raw_df) == 1:
                continue

            # previous_value 채우기
            raw_df["previous_value"] = (
                raw_df.groupby("hcode")["value"].shift(-1).replace(nan, None)
            )

            # previous_value가 None인 즉 이전 데이터가 없는 필요없는 데이터 제거
            raw_df = raw_df[raw_df["previous_value"].notna()]

            if raw_df.empty is True:
                continue

            # 계산
            raw_df["after_value"] = raw_df.apply(
                lambda x: ecos_calc.calc_ecos_timeseries_delta(x), axis=1
            )

            # 컬럼 정리
            raw_df.drop(columns=["value", "previous_value"], inplace=True)
            raw_df.rename(columns={"after_value": "value"}, inplace=True)

            # hcode 매핑
            raw_df = hcode_mapper.hcode_foregin_key_bulk_mapper(
                db=db, raw_df=raw_df, django_model=StatsKosisUniverse
            )
            obj_list = []
            for save in raw_df.to_dict("records"):
                obj_list.append(model[0](**save))

            model[0].objects.using(db).bulk_create(
                objs=obj_list,
                update_conflicts=True,
                unique_fields=["hcode", "date"],
                batch_size=100,
                update_fields=[
                    "value",
                ],
            )
            save_len += len(raw_df)
        end_time = time.time()
        logger.info(
            f"[WAREHOUSE][stats_kosis_delta_Month][DB:{db}] WareHouse {save_len} END. {timedelta(seconds=end_time - start_time)}"
        )
