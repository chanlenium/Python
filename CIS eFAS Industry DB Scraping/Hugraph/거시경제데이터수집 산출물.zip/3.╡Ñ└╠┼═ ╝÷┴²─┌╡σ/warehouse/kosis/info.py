import pandas as pd
import SetupDjangoORM
from loguru import logger
from numpy import nan

# 테이블
from table.models.warehouse.stats_kosis import StatsKosisInfo, StatsKosisUniverse
from tasks.warehouse.core.kosis import kosis_io
from tasks.warehouse.core.utils import hcode_generator, hcode_mapper


def stats_kosis_info_to_warehouse(request_day: str, db: str):
    # 데이터 로드
    obj_df = kosis_io.kosis_datalake_data_fetch_only_is_use(
        db=db, request_day=request_day
    ).replace(nan, None)

    logger.info(f" {len(obj_df)} raw preprocessing")

    # raw_df 생성
    raw_df = pd.DataFrame()

    # hcode 설정을 위한 공백
    obj_df = obj_df.replace(nan, None)

    # hcode 설정
    raw_df["hcode"] = obj_df.apply(
        lambda x: hcode_generator.kosis_hcode_generator(series=x), axis=1
    )
    # 중복제거
    raw_df = raw_df.drop_duplicates(subset=["hcode"])
    logger.info(f"drop_duplicates remainder row : {len(raw_df)}")

    # item_base_code 생성
    raw_df["item_base_code"] = obj_df.apply(lambda x: x["ITM_ID"], axis=1)

    # item_base_name 생성
    raw_df["item_base_name"] = obj_df.apply(lambda x: x["ITM_NM"], axis=1)
    # item 코드의 종단점을 확인하기 위한 리스트
    code_list = ["C1", "C2", "C3", "C4", "C5", "C6", "C7", "C8"]
    name_list = ["C1_NM", "C2_NM", "C3_NM", "C4_NM", "C5_NM", "C6_NM", "C7_NM", "C8_NM"]
    item_name_list = [
        "item1_name",
        "item2_name",
        "item3_name",
        "item4_name",
        "item5_name",
        "item6_name",
        "item7_name",
        "item8_name",
    ]
    item_code_list = [
        "item1_code",
        "item2_code",
        "item3_code",
        "item4_code",
        "item5_code",
        "item6_code",
        "item7_code",
        "item8_code",
    ]
    # code는 C8까지 존재하며 향후 추가될 경우를 대비해 하드코딩 해놓음
    for i in range(len(code_list)):
        try:
            # item_code 생성
            raw_df[item_code_list[i]] = obj_df.apply(lambda x: x[code_list[i]], axis=1)
            # item_name 생성
            raw_df[item_name_list[i]] = obj_df.apply(lambda x: x[name_list[i]], axis=1)
        except KeyError:
            # item_code 널값으로 설정
            raw_df[item_code_list[i]] = None
            # item_name 널값으로 설정
            raw_df[item_name_list[i]] = None

    # hcode 매핑
    raw_df = hcode_mapper.hcode_foregin_key_bulk_mapper(
        db=db, raw_df=raw_df, django_model=StatsKosisUniverse
    )

    # 저장
    obj_list = []

    for save in raw_df.to_dict("records"):
        obj_list.append(StatsKosisInfo(**save))

    logger.info("insert to StatsKosisInfo...")

    StatsKosisInfo.objects.using(db).bulk_create(
        objs=obj_list,
        update_conflicts=True,
        unique_fields=["hcode"],
        update_fields=[
            "item_base_code",
            "item_base_name",
            "item1_code",
            "item2_code",
            "item3_code",
            "item4_code",
            "item5_code",
            "item6_code",
            "item7_code",
            "item8_code",
            "item1_name",
            "item2_name",
            "item3_name",
            "item4_name",
            "item5_name",
            "item6_name",
            "item7_name",
            "item8_name",
        ],
    )
    # for save in raw_df.
