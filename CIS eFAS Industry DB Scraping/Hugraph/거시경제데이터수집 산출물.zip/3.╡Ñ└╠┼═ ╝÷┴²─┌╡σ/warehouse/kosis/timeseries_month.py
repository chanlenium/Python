import time
from datetime import timedelta

import pandas as pd
import SetupDjangoORM
from loguru import logger
from numpy import nan

# 테이블 로드
from table.models.warehouse.stats_kosis import (
    StatsKosisTimeSeriesMonth,
    StatsKosisUniverse,
)
from tasks.warehouse.core.kosis import kosis_cleansing, kosis_io
from tasks.warehouse.core.utils import hcode_generator, hcode_mapper, type_changer


def stats_kosis_timeseries_month_to_warehouse(db: str, request_day: str):
    start_time = time.time()
    logger.info(f"[WAREHOUSE][KOSIS][TIMESERIES][MONTH][DB:{db}] START")
    # 데이터 로드
    obj_df = kosis_io.kosis_datalake_data_fetch_only_is_use(
        db=db, request_day=request_day, period="M"
    ).replace(nan, None)

    # obj_df가 비어있으면
    if obj_df.empty:
        end_time = time.time()
        logger.info(
            f"[WAREHOUSE][KOSIS][TIMESERIES][MONTH][DB:{db}] END 0 success. {timedelta(seconds=end_time - start_time)}, {request_day}"
        )
    else:
        raw_df = pd.DataFrame()

        # hcode 설정
        raw_df["hcode"] = obj_df.apply(
            lambda x: hcode_generator.kosis_hcode_generator(series=x), axis=1
        )

        # 값 설정
        raw_df["value"] = obj_df.apply(lambda x: x["DT"], axis=1)
        # 날짜 설정
        raw_df["date"] = obj_df.apply(lambda x: x["PRD_DE"], axis=1)
        # 데이터 분리 저장을 위한 주기 데이터 삽입
        raw_df["category"] = obj_df.apply(lambda x: x["PRD_SE"], axis=1)

        # 벨류값 타입변경
        raw_df["value"] = raw_df.apply(
            lambda x: type_changer.ecos_str_to_decimal(x["value"]), axis=1
        )

        # Date 타입 변경
        raw_df["date"] = raw_df.apply(
            lambda x: kosis_cleansing.kosis_category_date_revise(
                one_date=x["date"], category=x["category"]
            ),
            axis=1,
        )

        # hcode 매핑
        raw_df = hcode_mapper.hcode_foregin_key_bulk_mapper(
            db=db, django_model=StatsKosisUniverse, raw_df=raw_df
        )

        # 필요없는 컬럼 최종드랍
        raw_df.drop(columns="category", inplace=True)

        # 저장
        obj_list = []
        for saving in raw_df.to_dict("records"):
            obj_list.append(StatsKosisTimeSeriesMonth(**saving))
        try:
            StatsKosisTimeSeriesMonth.objects.using(db).bulk_create(
                objs=obj_list,
                update_conflicts=True,
                unique_fields=["hcode", "date"],
                update_fields=["value"],
            )

            end_time = time.time()
            logger.info(
                f"[WAREHOUSE][KOSIS][TIMESERIES][MONTH][DB:{db}] END {len(obj_list)} success. {timedelta(seconds=end_time - start_time)}, {request_day}"
            )
        except Exception as e:
            logger.error(
                f"[WAREHOUSE][KOSIS][TIMESERIES][MONTH][DB:{db}] save failed {e}"
            )
