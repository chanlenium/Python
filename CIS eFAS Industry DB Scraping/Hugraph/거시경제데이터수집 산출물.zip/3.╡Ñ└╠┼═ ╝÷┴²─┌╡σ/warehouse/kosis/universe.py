import re

import pandas as pd
import SetupDjangoORM
from loguru import logger
from numpy import nan

# 테이블
from table.models.warehouse.stats_kosis import (
    StatsKosisGroupUniverse,
    StatsKosisUniverse,
)

# STATIC
from table.static.columns.name_kor.kosis import KOSIS_NAME_KOR
from tasks.warehouse.core.kosis import kosis_cleansing, kosis_io
from tasks.warehouse.core.utils import hcode_generator, hcode_mapper


def stats_kosis_universe_name_kor_preprocessing(raw_df: pd.DataFrame) -> pd.DataFrame:
    """
    name_kor을 지정해주기 위한 코드입니다.
    :param raw_df:
    :return:
    """
    # 문자열 변경을 위해 저장해둔 데이터프레임
    raw_df["tmp_name_kor"] = raw_df["full_name_kor"]
    # stats code 별로 반복
    for static_stats_code in list(KOSIS_NAME_KOR.keys()):
        # 딕셔너리 내부 반복
        for i in range(len(KOSIS_NAME_KOR[static_stats_code])):
            # 계산하기 위한 임시 프레임 생성
            tmp_df = raw_df[raw_df["stats_code"] == static_stats_code][
                ["name_kor", "tmp_name_kor"]
            ].copy()
            if tmp_df.empty:
                continue
            # 변경
            tmp_df["name_kor"] = tmp_df.apply(
                lambda x: re.sub(
                    list(KOSIS_NAME_KOR[static_stats_code][i].keys())[0],
                    "",
                    x["tmp_name_kor"]
                    + list(KOSIS_NAME_KOR[static_stats_code][i].values())[0],
                )
                if re.search(
                    list(KOSIS_NAME_KOR[static_stats_code][i].keys())[0],
                    x["tmp_name_kor"],
                )
                else None,
                axis=1,
            )
            # 변경되지 않은 컬럼 제거
            tmp_df = tmp_df[tmp_df["name_kor"].notna()]

            raw_df["name_kor"].update(tmp_df["name_kor"])
            raw_df["tmp_name_kor"].update(tmp_df["name_kor"])
    return raw_df


def stats_kosis_universe_full_name_kor_preprocessing(
    raw_df: pd.DataFrame,
) -> pd.DataFrame:
    """
    full_name_kor을 지정해주기 위한 코드입니다.
    :param raw_df:
    :return:
    """
    tmp_df = pd.DataFrame()
    concat_df = pd.DataFrame()

    stats_code_list = list(set(raw_df["stats_code"]))
    for i in range(len(stats_code_list)):
        # 1. 해당하는 stats code에서만 선별해서 데이터프레임으로 만든다
        raw_df_stats_code = raw_df[
            raw_df["stats_code"] == stats_code_list[i]
        ].reset_index(drop=True)

        # 2. stats cde에서 존재하는 len list를 만든다
        length_list = sorted(
            set(len(item) for item in raw_df_stats_code["last_item"]), reverse=True
        )

        # # full_name_kor 수정
        tmp_df = raw_df_stats_code
        tmp_df["full_name_kor"] = raw_df_stats_code.apply(
            lambda x: kosis_cleansing.stats_kosis_name_fix(
                raw=x,
                raw_df_stats_code=raw_df_stats_code,
                length_list=length_list,
            ),
            axis=1,
        )
        concat_df = pd.concat([tmp_df, concat_df])
    raw_df = concat_df.reset_index(drop=True)
    return raw_df


def stats_kosis_universe_to_warehouse(db: str, request_day: str):
    # 데이터 로드
    obj_df = kosis_io.kosis_datalake_data_fetch_only_is_use(
        db=db, request_day=request_day
    ).replace(nan, None)

    # obj_df = pd.DataFrame(obj_list)
    raw_df = pd.DataFrame()

    logger.info(f" {len(obj_df)} raw preprocessing")

    # full_name 설정을 위한 rename
    obj_df.rename(
        columns={
            "TBL_NM": "full_name_kor",
            "ITM_NM": "NM1",
            "C1_NM": "NM2",
            "C2_NM": "NM3",
            "C3_NM": "NM4",
            "C4_NM": "NM5",
            "C5_NM": "NM6",
            "C6_NM": "NM7",
            "C7_NM": "NM8",
            "C8_NM": "NM9",
        },
        inplace=True,
    )
    # hcode 설정
    raw_df["hcode"] = obj_df.apply(
        lambda x: hcode_generator.kosis_hcode_generator(series=x), axis=1
    )
    # loacl_code 생성
    raw_df["local_code"] = raw_df.apply(
        lambda x: kosis_cleansing.stats_kosis_local_code_generator(series=x), axis=1
    )
    # full_name 설정
    raw_df["full_name_kor"] = obj_df.apply(
        lambda x: kosis_cleansing.stats_kosis_name_add(series=x), axis=1
    )
    pd.set_option("display.max_rows", None)

    # satas 설정
    raw_df["stats_code"] = obj_df.apply(lambda x: x["TBL_ID"], axis=1)

    # unit 설정
    raw_df["unit"] = obj_df.apply(lambda x: x["UNIT_NM"], axis=1)

    # last_item 삽입
    raw_df["last_item"] = raw_df.apply(
        lambda x: re.findall("-(.+?)-", x["hcode"])[-1:][0], axis=1
    )

    # name_kor default 값 추가
    raw_df["name_kor"] = raw_df.apply(lambda x: x["full_name_kor"], axis=1)

    # full_name_kor 추가 전처리
    raw_df = stats_kosis_universe_full_name_kor_preprocessing(raw_df=raw_df)

    # name_kor 설정(제거 방식)
    raw_df = stats_kosis_universe_name_kor_preprocessing(raw_df=raw_df)
    pd.set_option("display.max_rows", None)

    # category 설정
    raw_df["category"] = "Statistics"

    # local_code, isin, market 은 Null

    # country 설정
    raw_df["country"] = "KR"

    # is_delisted설정
    raw_df["is_delisted"] = False

    # 필요없는 컬럼 지우기
    raw_df.drop(columns=["last_item", "tmp_name_kor"], inplace=True)

    # stats_code 매핑
    raw_df = hcode_mapper.stats_code_foregin_key_bulk_mapper(
        db=db, django_model=StatsKosisGroupUniverse, raw_df=raw_df
    )

    # 중복제거
    raw_df.drop_duplicates(subset=["hcode"], inplace=True)
    logger.info(f"drop_duplicates remainder row : {len(raw_df)}")
    obj_list = []

    for save in raw_df.to_dict("records"):
        obj_list.append(StatsKosisUniverse(**save))

    logger.info("insert to StatsKosisUniverse...")

    StatsKosisUniverse.objects.using(db).bulk_create(
        objs=obj_list,
        update_conflicts=True,
        unique_fields=["stats_code", "hcode"],
        update_fields=[
            "name_kor",
            "full_name_kor",
            "unit",
            "category",
            "country",
            "is_delisted",
            "local_code",
        ],
    )
    logger.info(f"DONE {len(obj_list)}")
