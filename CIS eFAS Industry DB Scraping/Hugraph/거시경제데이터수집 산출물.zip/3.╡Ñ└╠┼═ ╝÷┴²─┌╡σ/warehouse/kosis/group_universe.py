import pandas as pd
import SetupDjangoORM
from loguru import logger
from table.models.warehouse.stats_kosis import StatsKosisGroupUniverse
from table.static.columns.is_use.kosis import INITIAL_KOSIS_STATAS_CODE
from table.static.columns.timeseries_category import kosis as kosis_category


def stats_kosis_timeseries_category_preprocessing(stats_code: str) -> str:
    """
    timeseries_category를 넣어주는 함수입니다.
    * 참고사항
        - unit이 같다고 가정해도, 시간이 지나면 달라질 수 있습니다. 이에대한 해결 방안 등을 마련해야 합니다.
    :param raw_df:
    :return:
    """

    if stats_code in kosis_category.KOSIS_TIMESERIES_CATEGORY_INDEX:
        category = "Index"
    else:
        category = None

    return category


def stats_kosis_group_universe_to_warehouse(
    db: str, stats_code: list = list(INITIAL_KOSIS_STATAS_CODE)
):
    """
    stats_code를 받아서 업데이트하는 함수입니다.
    :param stats_code:
    :return:
    """
    logger.info(
        f"[WAREHOUSE][COMMAND][DB:{db}] <STATS KOSIS Group Universe> 추가 작업 START 🐳>"
    )

    raw_df = pd.DataFrame({"stats_code": stats_code})

    kosis_category.KOSIS_TIMESERIES_CATEGORY_INDEX

    # 카테고리 추가
    raw_df["timeseries_category"] = raw_df.apply(
        lambda x: stats_kosis_timeseries_category_preprocessing(
            stats_code=x["stats_code"]
        ),
        axis=1,
    )

    # 벌크저장
    obj_list = []

    for saving in raw_df.to_dict("records"):
        obj_list.append(StatsKosisGroupUniverse(**saving))

    StatsKosisGroupUniverse.objects.using(db).bulk_create(
        objs=obj_list,
        update_conflicts=True,
        unique_fields=["stats_code"],
        update_fields=["stats_code", "timeseries_category"],
        batch_size=100,
    )

    logger.info(
        f"[WAREHOUSE][COMMAND][DB:{db}] <STATS KOSIS Group Universe> 추가 작업 END 🦊>"
    )
