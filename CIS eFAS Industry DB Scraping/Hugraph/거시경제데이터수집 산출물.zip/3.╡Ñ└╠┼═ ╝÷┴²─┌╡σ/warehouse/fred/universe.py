import time
from datetime import datetime, timedelta

import pandas as pd
from loguru import logger
from table.models.lake.datalake import DataLake
from table.models.warehouse.stats_fred.basic.universe import StatsFredUniverse
from table.models.warehouse.stats_fred.group.universe import StatsFredGroupUniverse
from tasks.warehouse.core.utils import hcode_generator, hcode_mapper


def fred_universe_to_warehouse(db: str, request_day: str, **context):
    """
    :param db:
    :param request_day:
    :return:
    """
    if "stats_code" in context["dag_run"].conf:
        stats_code = context["dag_run"].conf["stats_code"]
        logger.info(
            f"[WAREHOUSE][stats_fred_universe][DB:{db}][STATS_CODE: {stats_code}] START"
        )
        start_time = time.time()
        # 1. DATA LOAD
        datalake_obj = (
            DataLake.objects.using(db)
            .filter(
                source="fred",
                endpoint="fred_universe",
                date=datetime.strptime(request_day, "%Y%m%d").date(),
                source_param__stats_code=stats_code,
            )
            .order_by("source_param", "-created_at")
            .distinct("source_param")
        )
    else:
        logger.info(f"[WAREHOUSE][stats_fred_universe][DB:{db}] START")
        start_time = time.time()
        # 1. DATA LOAD
        datalake_obj = (
            DataLake.objects.using(db)
            .filter(
                source="fred",
                endpoint="fred_universe",
                date=datetime.strptime(request_day, "%Y%m%d").date(),
                source_param__stats_code__in=list(
                    StatsFredGroupUniverse.objects.using(db)
                    .filter(is_use=True)
                    .values_list("stats_code", flat=True)
                ),
            )
            .order_by("source_param", "-created_at")
            .distinct("source_param")
        )

    # 2. MAKE DATAFRAME
    raw_df = pd.DataFrame()
    for obj in datalake_obj:
        for rawdata in obj.rawdata[request_day]:
            tmp_df = pd.DataFrame(rawdata["seriess"])
            tmp_df["stats_code"] = obj.source_param["stats_code"]
            raw_df = pd.concat([raw_df, tmp_df])
            tmp_df = pd.DataFrame()

    # 3. DATA CLEANSING
    raw_df.rename(
        columns={"id": "local_code", "units": "unit", "title": "full_name_eng"},
        inplace=True,
    )

    raw_df["hcode"] = raw_df.apply(
        lambda x: hcode_generator.fred_hcode_generator(
            x["stats_code"], x["local_code"], x["frequency_short"]
        ),
        axis=1,
    )
    raw_df["is_copyright"] = raw_df.apply(
        lambda x: True if str(x["notes"]).find("Copyright") != -1 else False, axis=1
    )

    raw_df = raw_df[
        ["hcode", "stats_code", "local_code", "unit", "full_name_eng", "is_copyright"]
    ]

    # 4. STATS_CODE FK
    raw_df = hcode_mapper.stats_code_foregin_key_bulk_mapper(
        db=db, django_model=StatsFredGroupUniverse, raw_df=raw_df
    )

    obj_list = []

    for raw in raw_df.to_dict(orient="records"):
        obj_list.append(StatsFredUniverse(**raw))

    StatsFredUniverse.objects.using(db).bulk_create(
        objs=obj_list,
        batch_size=1000,
        unique_fields=["hcode", "stats_code"],
        update_fields=["local_code", "unit", "full_name_eng", "is_copyright"],
        update_conflicts=True,
    )
    end_time = time.time()
    logger.info(
        f"[WAREHOUSE][stats_fred_universe][DB:{db}] END {len(obj_list)} success. {timedelta(seconds=end_time - start_time)}, {request_day}"
    )
    return len(obj_list)
