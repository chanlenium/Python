import time
from datetime import datetime, timedelta

import pandas as pd
from loguru import logger
from table.models.lake.datalake import DataLake
from table.models.warehouse.stats_fred import (
    StatsFredTimeSeriesQuarter,
    StatsFredUniverse,
)
from tasks.warehouse.core.utils import hcode_generator, hcode_mapper


def fred_timeseries_quarter_to_warehouse(db: str, request_day: str):
    """
    :return:
    """
    start_time = time.time()
    logger.info(
        f"[WAREHOUSE][stats_fred_timeseries_quarter][{request_day}][DB:{db}][RequestDay : {request_day}] Warehouse"
    )
    # 1. DATA LOAD
    datalake_obj = (
        DataLake.objects.using(db)
        .filter(
            source="fred",
            endpoint="fred_timeseries_quarter",
            date=datetime.strptime(request_day, "%Y%m%d").date(),
        )
        .order_by("source_param", "-created_at")
        .distinct("source_param")
    )

    # 2. DATA CLEANSING
    raw_df = pd.DataFrame()
    for i in range(len(datalake_obj)):
        tmp_df = pd.DataFrame(datalake_obj[i].rawdata[request_day][0]["observations"])
        tmp_df["local_code"] = datalake_obj[i].source_param["local_code"]
        tmp_df["period"] = datalake_obj[i].source_param["period"]
        tmp_df["stats_code"] = datalake_obj[i].source_param["stats_code"]
        tmp_df = tmp_df[tmp_df["period"] == "Q"]
        raw_df = pd.concat([raw_df, tmp_df])
    if raw_df.empty:
        end_time = time.time()
        logger.info(
            f"[WAREHOUSE][stats_fred_timeseries_quarter][DB:{db}] END 0 success. {timedelta(seconds=end_time - start_time)}, {request_day}"
        )
        return 0
    raw_df["hcode"] = raw_df.apply(
        lambda x: hcode_generator.fred_hcode_generator(
            x["stats_code"], x["local_code"], x["period"]
        ),
        axis=1,
    )
    raw_df = raw_df[["hcode", "date", "value"]]
    raw_df.replace(".", None, inplace=True)

    # 3. FK

    raw_df = hcode_mapper.hcode_foregin_key_bulk_mapper(
        db=db, django_model=StatsFredUniverse, raw_df=raw_df
    )

    obj_list = []

    for raw in raw_df.to_dict("records"):
        obj_list.append(StatsFredTimeSeriesQuarter(**raw))

    StatsFredTimeSeriesQuarter.objects.using(db).bulk_create(
        objs=obj_list,
        update_conflicts=True,
        batch_size=1000,
        unique_fields=["hcode", "date"],
        update_fields=["value"],
    )
    end_time = time.time()
    logger.info(
        f"[WAREHOUSE][stats_fred_timeseries_quarter][DB:{db}] END {len(obj_list)} success. {timedelta(seconds=end_time - start_time)}, {request_day}"
    )
    return len(obj_list)
