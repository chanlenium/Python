import time
from datetime import datetime, timedelta

import pandas as pd
from loguru import logger
from table.models.warehouse.stats_fred.group.universe import StatsFredGroupUniverse
from table.static.columns.is_use.fred import FRED_USING_STATS_CODES
from tasks.warehouse.core.utils import utils_io


def fred_group_universe_to_warehouse(db: str, request_day: str):
    """
    :param db:
    :param request_day:
    :return:
    """
    start_time = time.time()
    logger.info(f"[WAREHOUSE][fred_group_universe][DB:{db}][{request_day}] START")
    objs = utils_io.datalake_data_fetcher_by_date(
        db=db,
        source="fred",
        endpoint="fred_group_universe",
        date=datetime.strptime(request_day, "%Y%m%d").date(),
    )
    raw_df = pd.DataFrame()
    for obj in objs.rawdata[request_day]:
        raw_df = pd.concat([raw_df, pd.DataFrame(obj["releases"])])

    raw_df.rename(columns={"id": "stats_code"}, inplace=True)
    raw_df["stats_code"] = raw_df["stats_code"].astype(str)
    raw_df = raw_df[["stats_code", "name"]]
    raw_df["is_use"] = raw_df.apply(
        lambda x: True if x["stats_code"] in FRED_USING_STATS_CODES else False, axis=1
    )

    obj_list = []

    for raw in raw_df.to_dict(orient="records"):
        obj_list.append(StatsFredGroupUniverse(**raw))

    StatsFredGroupUniverse.objects.using(db).bulk_create(
        objs=obj_list,
        batch_size=1000,
        update_conflicts=True,
        unique_fields=["stats_code"],
        update_fields=["name", "is_use"],
    )
    end_time = time.time()
    logger.info(
        f"[WAREHOUSE][stats_ecos_group_period][DB:{db}] END {len(obj_list)} success. {timedelta(seconds=end_time - start_time)}, {request_day}"
    )
    return len(obj_list)
