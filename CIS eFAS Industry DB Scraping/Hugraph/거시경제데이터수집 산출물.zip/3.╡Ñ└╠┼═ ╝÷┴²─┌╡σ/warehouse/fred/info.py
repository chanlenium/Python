import time
from datetime import datetime, timedelta

import pandas as pd
from loguru import logger
from table.models.lake.datalake import DataLake
from table.models.warehouse.stats_fred.basic import StatsFredInfo, StatsFredUniverse
from table.models.warehouse.stats_fred.group.universe import StatsFredGroupUniverse
from table.static.columns.is_use.fred import FRED_USING_LOCAL_CODE
from tasks.warehouse.core.utils import hcode_generator, hcode_mapper


def fred_info_to_warehouse(db: str, request_day: str, **context):
    """
    :param db:
    :param request_day:
    :return:
    """
    if "stats_code" in context["dag_run"].conf:
        stats_code = context["dag_run"].conf["stats_code"]
        logger.info(
            f"[WAREHOUSE][fx_fred_info][DB:{db}][STATS_CODE: {stats_code}] START"
        )
        start_time = time.time()
        # 1. DATA LOAD
        datalake_obj = (
            DataLake.objects.using(db)
            .filter(
                source="fred",
                endpoint="fred_universe",
                date=datetime.strptime(request_day, "%Y%m%d").date(),
                source_param__stats_code=stats_code,
            )
            .order_by("source_param", "-created_at")
            .distinct("source_param")
        )
    else:
        logger.info(f"[WAREHOUSE][fx_fred_info][DB:{db}] START")
        start_time = time.time()
        # 1. DATA LOAD
        datalake_obj = (
            DataLake.objects.using(db)
            .filter(
                source="fred",
                endpoint="fred_universe",
                date=datetime.strptime(request_day, "%Y%m%d").date(),
                source_param__stats_code__in=list(
                    StatsFredGroupUniverse.objects.using(db)
                    .filter(is_use=True)
                    .values_list("stats_code", flat=True)
                ),
            )
            .order_by("source_param", "-created_at")
            .distinct("source_param")
        )

    # 2. MAKE DATAFRAME
    raw_df = pd.DataFrame()
    for obj in datalake_obj:
        for rawdata in obj.rawdata[request_day]:
            tmp_df = pd.DataFrame(rawdata["seriess"])
            tmp_df["stats_code"] = obj.source_param["stats_code"]
            raw_df = pd.concat([raw_df, tmp_df])
            tmp_df = pd.DataFrame()

    # 3. DATA CLEANSING
    raw_df.rename(
        columns={
            "id": "local_code",
            "observation_start": "start_date",
            "observation_end": "end_date",
            "frequency_short": "period",
            "notes": "description",
        },
        inplace=True,
    )
    raw_df["hcode"] = raw_df.apply(
        lambda x: hcode_generator.fred_hcode_generator(
            x["stats_code"], x["local_code"], x["period"]
        ),
        axis=1,
    )
    raw_df["is_use"] = raw_df.apply(
        lambda x: True if x["local_code"] in FRED_USING_LOCAL_CODE else False, axis=1
    )
    raw_df = raw_df[
        [
            "hcode",
            "stats_code",
            "start_date",
            "end_date",
            "period",
            "description",
            "is_use",
        ]
    ]

    # 4. STATS_CODE FK
    raw_df = hcode_mapper.stats_code_foregin_key_bulk_mapper(
        db=db, django_model=StatsFredGroupUniverse, raw_df=raw_df
    )
    raw_df = hcode_mapper.hcode_foregin_key_bulk_mapper(
        db=db, django_model=StatsFredUniverse, raw_df=raw_df
    )

    obj_list = []

    for raw in raw_df.to_dict(orient="records"):
        obj_list.append(StatsFredInfo(**raw))

    StatsFredInfo.objects.using(db).bulk_create(
        objs=obj_list,
        batch_size=1000,
        unique_fields=["hcode", "stats_code", "period"],
        update_fields=["start_date", "end_date", "period", "description", "is_use"],
        update_conflicts=True,
    )
    end_time = time.time()
    logger.info(
        f"[WAREHOUSE][stats_fred_info][DB:{db}] END {len(obj_list)} success. {timedelta(seconds=end_time - start_time)}, {request_day}"
    )
    return len(obj_list)
