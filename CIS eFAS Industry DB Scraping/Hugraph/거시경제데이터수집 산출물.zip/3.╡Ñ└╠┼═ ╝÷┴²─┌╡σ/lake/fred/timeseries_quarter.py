import re
import time
from datetime import datetime

import pandas as pd
from dateutil.relativedelta import relativedelta
from loguru import logger
from table.models.lake.datalake import DataLake
from table.models.warehouse.stats_fred.basic import StatsFredInfo, StatsFredUniverse
from tasks.lake.core.fred.fred_requests import FREDRequests


def fred_timeseries_quarter_to_datalake(dbs: list, request_day: str, **context):
    """
    :param dbs:
    :param request_day:
    :return:
    """
    request_day_date = datetime.strptime(request_day, "%Y%m%d").date()
    if "stats_code" in context["dag_run"].conf:
        local_code = context["dag_run"].conf["local_code"]
        use_df = pd.DataFrame(
            StatsFredInfo.objects.using(dbs[0])
            .filter(
                hcode=StatsFredUniverse.objects.using(dbs[0])
                .get(local_code=local_code)
                .hcode,
                is_use=True,
                period="Q",
            )
            .values("hcode", "period", "start_date", "end_date")
        )
        if use_df.empty:
            logger.info(
                f"[LAKE][FRED][FRED_TIMESERIES_QUARTER][db: {dbs[0]}] 0 FRED Date : {request_day} Success."
            )
            return 0
        local_code_df = pd.DataFrame(
            StatsFredUniverse.objects.using(dbs[0])
            .filter(hcode__in=list(use_df["hcode"]))
            .values("local_code", "hcode", "stats_code")
        )
    else:
        use_df = pd.DataFrame(
            StatsFredInfo.objects.using(dbs[0])
            .filter(is_use=True, period="Q")
            .values("hcode", "period", "start_date", "end_date")
        )
        if use_df.empty:
            logger.info(
                f"[LAKE][FRED][FRED_TIMESERIES_QUARTER][db: {dbs[0]}] 0 FRED Date : {request_day} Success."
            )
            return 0
        local_code_df = pd.DataFrame(
            StatsFredUniverse.objects.using(dbs[0])
            .filter(hcode__in=list(use_df["hcode"]))
            .values("local_code", "hcode", "stats_code")
        )
    use_df = pd.merge(use_df, local_code_df, on="hcode", how="left")

    for i in range(len(use_df)):
        if "stats_code" in context["dag_run"].conf:
            response_list = FREDRequests().get_series(
                series_id=use_df.iloc[i]["local_code"],
                start_date=str(use_df.iloc[i]["start_date"]),
            )
        else:
            response_list = FREDRequests().get_series(
                series_id=use_df.iloc[i]["local_code"],
                start_date=str(request_day_date - relativedelta(years=1)),
            )

        raw_data = []
        for response in response_list:
            raw_data.append(response)

        for db in dbs:
            try:
                DataLake(
                    source="fred",
                    endpoint="fred_timeseries_quarter",
                    source_param={
                        "local_code": use_df.iloc[i]["local_code"],
                        "stats_code": use_df.iloc[i]["stats_code"],
                        "period": use_df.iloc[i]["period"],
                    },
                    rawdata={f"{request_day}": raw_data},
                    date=request_day_date,
                ).save(using=db)
            except Exception as e:
                logger.error(
                    f"[LAKE][FRED][FRED_TIMESERIES_QUARTER][db: {db}][local_code: {use_df.iloc[i]['local_code']}] FRED Date : {request_day}, {len(raw_data)} Failed. {e}"
                )
            logger.info(
                f"[LAKE][FRED][FRED_TIMESERIES_QUARTER][db: {db}][local_code: {use_df.iloc[i]['local_code']}] FRED Date : {request_day} Success."
            )
        time.sleep(5)
