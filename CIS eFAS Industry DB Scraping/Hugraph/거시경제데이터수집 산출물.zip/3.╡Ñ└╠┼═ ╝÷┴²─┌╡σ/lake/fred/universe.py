import time
from datetime import timedelta

from loguru import logger
from table.models.lake.datalake import DataLake
from table.models.warehouse.stats_fred.group.universe import StatsFredGroupUniverse
from tasks.lake.core.fred.fred_requests import FREDRequests


def stats_fred_universe_to_datalake(dbs: list, request_day: str, **context):
    """
    FRED 에서 제공하는 모든 최상위(그룹) release를 가져옵니다
    :return:
    """
    if "stats_code" in context["dag_run"].conf:
        stats_code = context["dag_run"].conf["stats_code"]
        start_time = time.time()
        logger.info(
            f"[LAKE][FRED][FRED_UNIVERSE][DB:{dbs}][STATS_CODE: {stats_code}] Start"
        )
        stats_code_list = [stats_code]
    else:
        start_time = time.time()
        logger.info(f"[LAKE][FRED][FRED_UNIVERSE][DB:{dbs}] Start")
        stats_code_list = (
            StatsFredGroupUniverse.objects.using(dbs[0])
            .filter(is_use=True)
            .values_list("stats_code", flat=True)
        )
    if len(stats_code_list) == 0:
        logger.warning(
            f"[LAKE][FRED][FRED_UNIVERSE][DB:{dbs}] fred_group_universe 테이블에 is_use가 True인 데이터가 존재하지 않습니다."
        )
        return 0

    for stats_code in stats_code_list:
        raw_data = []
        responses = FREDRequests().get_release_series(release_id=stats_code)

        for response in responses["response_list"]:
            raw_data.append(response)

        for db in dbs:
            try:
                DataLake(
                    source="fred",
                    endpoint=f"fred_universe",
                    date=request_day,
                    source_param={
                        "type": "statistics_fred",
                        "stats_code": responses["stats_code"],
                    },
                    rawdata={f"{request_day}": raw_data},
                ).save(using=db)

            except Exception as e:
                logger.error(
                    f"[LAKE][FRED][FRED_UNIVERSE][DB:{db}][STATS_CODE: {stats_code}] save Failed. {e}"
                )
                raise

            end_time = time.time()

            logger.info(
                f"[LAKE][FRED][FRED_UNIVERSE][DB:{db}][STATS_CODE: {stats_code}] {len(raw_data)} END {timedelta(seconds=end_time-start_time)}, {request_day}"
            )
            time.sleep(1)
