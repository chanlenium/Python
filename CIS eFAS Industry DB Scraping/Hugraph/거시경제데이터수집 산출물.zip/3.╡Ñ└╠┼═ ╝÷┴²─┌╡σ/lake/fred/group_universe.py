import time
from datetime import timedelta

from loguru import logger
from table.models.lake.datalake import DataLake
from tasks.lake.core.fred.fred_requests import FREDRequests


def stats_fred_group_universe_to_datalake(dbs: list, request_day: str):
    """
    FRED 에서 제공하는 모든 최상위(그룹) release를 가져옵니다
    :return:
    """
    start_time = time.time()
    logger.info(f"[LAKE][FRED][FRED_GROUP_UNIVERSE][DB:{dbs}] Start")
    response_list = FREDRequests().get_releases()
    raw_data = []
    for response in response_list:
        raw_data.append(response.json())

    for db in dbs:
        try:
            DataLake(
                source="fred",
                endpoint=f"fred_group_universe",
                date=request_day,
                source_param={"type": "statistics_fred"},
                rawdata={f"{request_day}": raw_data},
            ).save(using=db)

        except Exception as e:
            logger.error(f"[LAKE][FRED][FRED_GROUP_UNIVERSE][DB:{db}] save Failed. {e}")
            raise

        end_time = time.time()

        logger.info(
            f"[LAKE][FRED][FRED_UNIVERSE][DB:{dbs}] {len(raw_data)} END {timedelta(seconds=end_time-start_time)}, {request_day}"
        )
