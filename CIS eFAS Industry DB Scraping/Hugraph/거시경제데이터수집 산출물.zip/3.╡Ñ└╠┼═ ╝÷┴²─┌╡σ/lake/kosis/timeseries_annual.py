import pickle
import time
from datetime import datetime, timedelta

import django
import pandas as pd
import SetupDjangoORM
from dateutil.relativedelta import relativedelta
from loguru import logger
from table.models.lake.datalake import DataLake
from table.models.warehouse.stats_kosis import StatsKosisGroupPeriod
from tasks.lake.core.kosis import kosis


def stats_kosis_timeseries_annual_data_fetch(
    date_list: list, obj_df: pd.DataFrame
) -> list:
    # 2. 변수 초기화
    raw_data = []
    for obj_dict in obj_df.to_dict("records"):
        logger.info(f"[{obj_dict['stats_code_id']}][{obj_dict['period']}] run...")

        # 3. url에서 필요한 objL1 ~ objL8 에 들어갈 값 구하기
        objL_set = ["", "", "", "", "", "", "", ""]
        for i in range(int(obj_dict["obj_id_code"])):
            objL_set.insert(i, "ALL")

        # 요청데이터 일자가 해당 데이터의 최대 일자보다 클 경우 date_list를 최대값부터 다시구함
        date_lists = date_list
        if int(obj_dict["end_date"][:4]) < int(date_lists[0]):
            date_lists = make_stats_kosis_timeseires_annual_date_list(
                request_day=obj_dict["end_date"] + "0101"
            )
            logger.warning(
                f"요청 일자 변경 {date_list[len(date_list)-1][:4]}~{date_list[0][:4]} -> {date_lists[len(date_lists)-1][:4]}~{date_lists[0][:4]}"
            )

        # 4. 데이터 수집
        for date in date_lists:
            data = kosis.stats_kosis_get_data(
                stats_code=obj_dict["stats_code_id"],
                org_id=obj_dict["org_code"],
                objL_set=objL_set,
                itm_id=obj_dict["itm_id"],
                date_type=obj_dict["period"],
                date=date,
            )
            try:
                raw_data = raw_data + data
                logger.info(
                    f"[{obj_dict['stats_code_id']}][{obj_dict['period']}][{date[:6]}] 데이터 불러오기 완료."
                )
            except Exception as e:
                # 간~~혹 월별데이터인데 일부 월에 데이터가 없는 경우가 존재함 (ex: DT_MLTM_2082)
                if data["err"] == "30":
                    logger.warning(
                        f"[{obj_dict['stats_code_id']}][{obj_dict['period']}][{date[:6]}] 데이터가 존재하지 않습니다."
                    )
                else:
                    logger.error(f"치명적인 오류 !! {e}")
                    raise
    return raw_data


def make_stats_kosis_timeseires_annual_date_list(
    request_day: str, start_day: str = None, end_day: str = None
) -> list:
    """
    request_day를 이용해 해당 request_day의 - 10일 까지의 date를 list로 만들어 반환하는 함수입니다.
    ex) request_day = 20231111 일 경우
    ['20231111', '20231110', '20231109', '20231108' ...]
    :param end_day:
    :param start_day:
    :param request_day:
    :return:
    """
    if end_day is None:
        start_date = datetime.strptime(request_day, "%Y%m%d").date() - relativedelta(
            years=3
        )
        end_date = datetime.strptime(request_day, "%Y%m%d").date()
    else:
        start_date = datetime.strptime(start_day + "0101", "%Y%m%d").date()
        end_date = datetime.strptime(end_day + "0101", "%Y%m%d").date()

    delta = relativedelta(years=1)
    current_date = end_date
    date_list = []

    while current_date >= start_date:
        date = datetime.strftime(current_date, "%Y%m%d")
        date = date[:4]
        date_list.append(date)
        current_date -= delta

    return date_list


def stats_kosis_timeseries_annual_to_datalake(dbs: list, request_day: str, **context):
    """
    kosis timeseries의 DAY 주기 데이터에 대해 가져오는 함수입니다.
    :param dbs:
    :param request_day:
    :param date_list: ['20230101', '20230102', '20230103' ..]
    :return:
    """
    start_time = time.time()
    if "stats_code" in context["dag_run"].conf:
        stats_code = context["dag_run"].conf["stats_code"]
        logger.info(f"[LAKE][KOSIS][TIMESERIES][A][stats_code: {stats_code}] Start")
        # 1. 데이터 로드
        obj_df = pd.DataFrame(
            StatsKosisGroupPeriod.objects.using(dbs[0])
            .values(
                "stats_code_id",
                "period",
                "org_code",
                "obj_id_code",
                "start_date",
                "end_date",
                "itm_id",
            )
            .filter(period="A", stats_code=stats_code)
            .order_by("-stats_code_id")
        )
        if obj_df.empty:
            end_time = time.time()
            logger.info(
                f"[LAKE][KOSIS][TIMESERIES][A][DB:{dbs[0]}] END {timedelta(seconds=end_time-start_time)}, {request_day}"
            )
            return 0

        # 1. date list 구하기
        date_list = make_stats_kosis_timeseires_annual_date_list(
            request_day=request_day,
            end_day=obj_df.iloc[0]["end_date"],
            start_day=obj_df.iloc[0]["start_date"],
        )
    else:
        logger.info(f"[LAKE][KOSIS][TIMESERIES][A] Start")
        # 1. 데이터 로드
        obj_df = pd.DataFrame(
            StatsKosisGroupPeriod.objects.using(dbs[0])
            .values(
                "stats_code_id",
                "period",
                "org_code",
                "obj_id_code",
                "start_date",
                "end_date",
                "itm_id",
            )
            .filter(period="A")
            .order_by("-stats_code_id")
        )
        # 1. date list 구하기
        date_list = make_stats_kosis_timeseires_annual_date_list(
            request_day=request_day
        )

    # 2. raw_data 구하기
    raw_data = stats_kosis_timeseries_annual_data_fetch(
        date_list=date_list, obj_df=obj_df
    )
    # 데이터 슬라이스 반복
    for db in dbs:
        try:
            DataLake(
                source="kosis",
                endpoint=f"timeseries_A",
                source_param={"type": "statistics_kosis"},
                rawdata={f"{request_day}": raw_data},
                date=datetime.strptime(request_day, "%Y%m%d").date(),
            ).save(using=db)
        except django.db.utils.OperationalError:
            DataLake(
                source="kosis",
                endpoint=f"timeseries_D",
                source_param={"type": "statistics_kosis"},
                rawdata_binary=pickle.dumps({f"{request_day}": raw_data}),
                date=datetime.strptime(request_day, "%Y%m%d").date(),
            ).save(using=db)
        except Exception as e:
            logger.error(f"[LAKE][KOSIS][TIMESERIES][A][DB:{db}] save Failed. {e}")
            raise
        end_time = time.time()

        logger.info(
            f"[LAKE][KOSIS][TIMESERIES][A][DB:{db}] END {timedelta(seconds=end_time-start_time)}, {request_day}"
        )
