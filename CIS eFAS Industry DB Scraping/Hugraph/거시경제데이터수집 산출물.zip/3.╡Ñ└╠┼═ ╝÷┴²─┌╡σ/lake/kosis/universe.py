import json
import re
import time
from datetime import timedelta

import pandas as pd
import requests
import SetupDjangoORM
from airflow.models import Variable
from loguru import logger
from table.models.lake.datalake import DataLake

# 필요 테이블
from table.models.warehouse.stats_kosis import StatsKosisGroupUniverse


def get_stats_kosis_total_serch(stats_code: str) -> pd.DataFrame:
    url = f"https://kosis.kr/openapi/statisticsSearch.do?method=getList&apiKey={Variable.get('KOSIS_API_KEY')}&format=json&jsonVD=Y&searchNm={stats_code}&orgId=&startCount=1&resultCount=20&sort=RANK"
    try:
        response = requests.get(url).json()
    except requests.exceptions.ConnectionError:
        logger.warning(f"{url} 연결오류 재시도중..")
        response = requests.get(url).json()
    # 만약 결과가 하나 이상이라면 정확히 맞는 결과를 선택한다
    for i in range(len(response)):
        try:
            if stats_code == response[i]["TBL_ID"]:
                response = [response[i]]
                break
            else:
                if i == len(response) - 1:
                    logger.error(f"{stats_code}의 통합검색 결과가 존재하지 않습니다.")
                    raise
        except Exception as e:
            logger.debug(response)
            logger.error(f"{e}")
            raise

    return response


def get_stats_kosis_category_list(total_serch: list) -> list:
    url = f"https://kosis.kr/openapi/statisticsData.do?method=getMeta&apiKey={Variable.get('KOSIS_API_KEY')}&format=json&type=ITM&orgId={total_serch['ORG_ID']}&tblId={total_serch['TBL_ID']}"
    response = requests.get(url).text
    json_data = re.sub(r"(\w+):", r'"\1":', response)
    json_data = json.loads(json_data)

    return json_data


def get_stats_kosis_universe_info(total_serch: list) -> list:
    url = f"https://kosis.kr/openapi/statisticsData.do?method=getMeta&apiKey={Variable.get('KOSIS_API_KEY')}&format=json&type=PRD&orgId={total_serch['ORG_ID']}&tblId={total_serch['TBL_ID']}"
    response = requests.get(url).text
    json_data = re.sub(r"(\w+):", r'"\1":', response)
    json_data = json.loads(json_data)

    return json_data


def stats_kosis_universe_all_run(db: str, stats_code):
    """
    statscode가 None이 아니면 해당 statscode에 대해서만 데이터를 가져옵니다.
    :return:
    """

    raw_data = []
    if stats_code is None:
        # is_use 인 map 데이터를 불러옵니다.
        map_list = list(
            StatsKosisGroupUniverse.objects.using(db)
            .filter(is_use=True)
            .values_list("stats_code", flat=True)
        )
    else:
        map_list = [stats_code]

    # map을 반복합니다.
    for maps in map_list:
        # 0 = 통합검색, 1 = 분류/항목, 2 = 수록정보
        data_list = []
        # 불러온 맵 데이터를 반복하며 분류항목과 수록정보를 가져옵니다.
        data_list.append(get_stats_kosis_total_serch(stats_code=maps))
        data_list.append(get_stats_kosis_category_list(total_serch=data_list[0][0]))
        data_list.append(get_stats_kosis_universe_info(total_serch=data_list[0][0]))
        logger.info(f"{maps} Done")
        raw_data.append(data_list)
        # 너무 빠르게 요청하면 간혈적으로 API가 불안정해지는 현상이 발생해 타임렉을 조금 두었습니다
        time.sleep(0.5)

    return raw_data


def stats_kosis_universe_to_datalake(request_day: str, dbs: list, **context):
    """
    통합검색 데이터 , 수록정보 데이터 ,분류/항목 데이터를 lake에 적재하는 코드입니다.
    각 stats_code별로 endpoint가 달라집니다.
    [sample data]
    [0], 개발가이드 -> KOSIS통합검색 : [{'QUERY': 'DT_40803_N0003', 'VW_CD': 'MT_ZTITLE', 'ITEM03': '', 'ORG_ID': '408', 'ORG_NM': '한국부동산원', 'TBL_ID': 'DT_40803_N0003', 'TBL_NM': '규모별 매매가격지수', 'STAT_ID': '1985011', 'STAT_NM': '전국주택가격동향조사', 'CONTENTS': '지역별 주택규모별 주택유형별 매매가격 강북권역 서북권 서해안권 광주 세종 전북 서울 도심권 동북권 중부산권 전국 서남권 동부산권 서부산권 강남권역 동부1권 인천 부산 수도권 대전 강원 전남 지방 6대광역시 8개도 동남권 경기 경의권 울산 충남 제주 9개도 경부1권 경부2권 경원권 대구 충북 경북 경남 5대광역시 동부2권 규모6 규모2 규모1 규모3 규모4 규모5 아파트 연립다세대 단독주택', 'LINK_URL': 'http://kosis.kr/statHtml/statHtml.do?orgId=408&tblId=DT_40803_N0003', 'MT_ATITLE': '주거 > 전국주택가격동향조사 > 전국주택가격동향(기준월 : 2021.06)', 'END_PRD_DE': '2023', 'REC_TBL_SE': 'N', 'STAT_DB_CNT': '1', 'STRT_PRD_DE': '2012', 'FULL_PATH_ID': 'I1 > I1_7 > C14_001', 'TBL_VIEW_URL': 'https://kosis.kr/statisticsList/statisticsListIndex.do?menuId=M_01_01&vwcd=MT_ZTITLE&parmTabId=M_01_01&parentId=I1.1;I1_7.2;C14_001.3;'}]
    [1], 개발가이드 -> 통계표설명 -> 분류/항목  : [{'ITM_ID': 'sales', 'ITM_NM': '매매가격', 'OBJ_ID': 'ITEM', 'OBJ_NM': '항목', 'ORG_ID': '408', 'TBL_ID': 'DT_40803_N0003', 'ITM_NM_ENG': 'Sales Price Index', 'OBJ_NM_ENG': 'Item code list'}, {'ITM_ID': '01', 'ITM_NM': '아파트', 'OBJ_ID': 'type', 'OBJ_NM': '주택유형별', 'ORG_ID': '408', 'TBL_ID': 'DT_40803_N0003', 'OBJ_ID_SN': '1', 'ITM_NM_ENG': 'Apartments', 'OBJ_NM_ENG': 'Type'}, {'ITM_ID': '02', 'ITM_NM': '연립다세대', 'OBJ_ID': 'type', 'OBJ_NM': '주택유형별', 'ORG_ID': '408', 'TBL_ID': 'DT_40803_N0003', 'OBJ_ID_SN': '1', 'ITM_NM_ENG': 'Row Houses', 'OBJ_NM_ENG': 'Type'}, {'ITM_ID': '03', 'ITM_NM': '단독주택', 'OBJ_ID': 'type', 'OBJ_NM': '주택유형별', 'ORG_ID': '408', 'TBL_ID': 'DT_40803_N0003', 'OBJ_ID_SN': '1', 'ITM_NM_ENG': 'Detached Houses', 'OBJ_NM_ENG': 'Type'}, {'ITM_ID': 'a0', 'ITM_NM': '전국', 'OBJ_ID': 'region_2', 'OBJ_NM': '지역별', 'ORG_ID': '408', 'TBL_ID': 'DT_40803_N0003', 'OBJ_ID_SN': '2', 'ITM_NM_ENG': 'TheWholeCountry', 'OBJ_NM_ENG': 'Region'}, {'ITM_ID': 'a1', 'ITM_NM': '수도권', 'OBJ_ID': 'region_2', 'OBJ_NM': '지역별', 'ORG_ID': '408', 'TBL_ID': 'DT_40803_N0003', 'OBJ_ID_SN': '2', 'ITM_NM_ENG': 'SeoulMetropolitanArea', 'OBJ_NM_ENG': 'Region'}, {'ITM_ID': 'a2', 'ITM_NM': '지방', 'OBJ_ID': 'region_2', 'OBJ_NM': '지역별', 'ORG_ID': '408', 'TBL_ID': 'DT_40803_N0003', 'OBJ_ID_SN': '2', 'ITM_NM_ENG': 'Non-SeoulMetropolitanArea', 'OBJ_NM_ENG': 'Region'}, {'ITM_ID': 'a22', 'ITM_NM': '6대광역시', 'OBJ_ID': 'region_2', 'OBJ_NM': '지역별', 'ORG_ID': '408', 'TBL_ID': 'DT_40803_N0003', 'OBJ_ID_SN': '2', 'ITM_NM_ENG': '6LargeCities', 'OBJ_NM_ENG': 'Region'}, {'ITM_ID': 'a3', 'ITM_NM': '5대광역시', 'OBJ_ID': 'region_2', 'OBJ_NM': '지역별', 'ORG_ID': '408', 'TBL_ID': 'DT_40803_N0003', 'OBJ_ID_SN': '2', 'ITM_NM_ENG': '5LargeCities', 'OBJ_NM_ENG': 'Region'}, {'ITM_ID': 'a23', 'ITM_NM': '9개도', 'OBJ_ID': 'region_2', 'OBJ_NM': '지역별', 'ORG_ID': '408', 'TBL_ID': 'DT_40803_N0003', 'OBJ_ID_SN': '2', 'ITM_NM_ENG': '9Provinces', 'OBJ_NM_ENG': 'Region'}, {'ITM_ID': 'a4', 'ITM_NM': '8개도', 'OBJ_ID': 'region_2', 'OBJ_NM': '지역별', 'ORG_ID': '408', 'TBL_ID': 'DT_40803_N0003', 'OBJ_ID_SN': '2', 'ITM_NM_ENG': '8Provinces', 'OBJ_NM_ENG': 'Region'}, {'ITM_ID': 'a5', 'ITM_NM': '서울', 'OBJ_ID': 'region_2', 'OBJ_NM': '지역별', 'ORG_ID': '408', 'TBL_ID': 'DT_40803_N0003', 'OBJ_ID_SN': '2', 'ITM_NM_ENG': 'Seoul', 'OBJ_NM_ENG': 'Region'}, {'ITM_ID': 'a501', 'ITM_NM': '강북권역', 'OBJ_ID': 'region_2', 'OBJ_NM': '지역별', 'ORG_ID': '408', 'TBL_ID': 'DT_40803_N0003', 'OBJ_ID_SN': '2', 'UP_ITM_ID': 'a5', 'ITM_NM_ENG': 'NorthernSeoul', 'OBJ_NM_ENG': 'Region'}, {'ITM_ID': 'a502', 'ITM_NM': '도심권', 'OBJ_ID': 'region_2', 'OBJ_NM': '지역별', 'ORG_ID': '408', 'TBL_ID': 'DT_40803_N0003', 'OBJ_ID_SN': '2', 'UP_ITM_ID': 'a501', 'ITM_NM_ENG': 'Dosim-kwon', 'OBJ_NM_ENG': 'Region'}, {'ITM_ID': 'a503', 'ITM_NM': '동북권', 'OBJ_ID': 'region_2', 'OBJ_NM': '지역별', 'ORG_ID': '408', 'TBL_ID': 'DT_40803_N0003', 'OBJ_ID_SN': '2', 'UP_ITM_ID': 'a501', 'ITM_NM_ENG': 'Dongbuk-kwon', 'OBJ_NM_ENG': 'Region'}, {'ITM_ID': 'a504', 'ITM_NM': '서북권', 'OBJ_ID': 'region_2', 'OBJ_NM': '지역별', 'ORG_ID': '408', 'TBL_ID': 'DT_40803_N0003', 'OBJ_ID_SN': '2', 'UP_ITM_ID': 'a501', 'ITM_NM_ENG': 'Seobuk-kwon', 'OBJ_NM_ENG': 'Region'}, {'ITM_ID': 'a505', 'ITM_NM': '강남권역', 'OBJ_ID': 'region_2', 'OBJ_NM': '지역별', 'ORG_ID': '408', 'TBL_ID': 'DT_40803_N0003', 'OBJ_ID_SN': '2', 'UP_ITM_ID': 'a5', 'ITM_NM_ENG': 'SouthernSeoul', 'OBJ_NM_ENG': 'Region'}, {'ITM_ID': 'a506', 'ITM_NM': '서남권', 'OBJ_ID': 'region_2', 'OBJ_NM': '지역별', 'ORG_ID': '408', 'TBL_ID': 'DT_40803_N0003', 'OBJ_ID_SN': '2', 'UP_ITM_ID': 'a505', 'ITM_NM_ENG': 'Seonam-kwon', 'OBJ_NM_ENG': 'Region'}, {'ITM_ID': 'a507', 'ITM_NM': '동남권', 'OBJ_ID': 'region_2', 'OBJ_NM': '지역별', 'ORG_ID': '408', 'TBL_ID': 'DT_40803_N0003', 'OBJ_ID_SN': '2', 'UP_ITM_ID': 'a505', 'ITM_NM_ENG': 'Dongnam-kwon', 'OBJ_NM_ENG': 'Region'}, {'ITM_ID': 'a6', 'ITM_NM': '경기', 'OBJ_ID': 'region_2', 'OBJ_NM': '지역별', 'ORG_ID': '408', 'TBL_ID': 'DT_40803_N0003', 'OBJ_ID_SN': '2', 'ITM_NM_ENG': 'Gyeonggi', 'OBJ_NM_ENG': 'Region'}, {'ITM_ID': 'a601', 'ITM_NM': '경부1권', 'OBJ_ID': 'region_2', 'OBJ_NM': '지역별', 'ORG_ID': '408', 'TBL_ID': 'DT_40803_N0003', 'OBJ_ID_SN': '2', 'UP_ITM_ID': 'a6', 'ITM_NM_ENG': 'Gyeongbu1-kwon', 'OBJ_NM_ENG': 'Region'}, {'ITM_ID': 'a602', 'ITM_NM': '경부2권', 'OBJ_ID': 'region_2', 'OBJ_NM': '지역별', 'ORG_ID': '408', 'TBL_ID': 'DT_40803_N0003', 'OBJ_ID_SN': '2', 'UP_ITM_ID': 'a6', 'ITM_NM_ENG': 'Gyeongbu2-kwon', 'OBJ_NM_ENG': 'Region'}, {'ITM_ID': 'a603', 'ITM_NM': '서해안권', 'OBJ_ID': 'region_2', 'OBJ_NM': '지역별', 'ORG_ID': '408', 'TBL_ID': 'DT_40803_N0003', 'OBJ_ID_SN': '2', 'UP_ITM_ID': 'a6', 'ITM_NM_ENG': 'Seohaean-kwon', 'OBJ_NM_ENG': 'Region'}, {'ITM_ID': 'a604', 'ITM_NM': '동부1권', 'OBJ_ID': 'region_2', 'OBJ_NM': '지역별', 'ORG_ID': '408', 'TBL_ID': 'DT_40803_N0003', 'OBJ_ID_SN': '2', 'UP_ITM_ID': 'a6', 'ITM_NM_ENG': 'Dongbu1-kwon', 'OBJ_NM_ENG': 'Region'}, {'ITM_ID': 'a605', 'ITM_NM': '동부2권', 'OBJ_ID': 'region_2', 'OBJ_NM': '지역별', 'ORG_ID': '408', 'TBL_ID': 'DT_40803_N0003', 'OBJ_ID_SN': '2', 'UP_ITM_ID': 'a6', 'ITM_NM_ENG': 'Dongbu2-kwon', 'OBJ_NM_ENG': 'Region'}, {'ITM_ID': 'a606', 'ITM_NM': '경의권', 'OBJ_ID': 'region_2', 'OBJ_NM': '지역별', 'ORG_ID': '408', 'TBL_ID': 'DT_40803_N0003', 'OBJ_ID_SN': '2', 'UP_ITM_ID': 'a6', 'ITM_NM_ENG': 'Gyeongui-kwon', 'OBJ_NM_ENG': 'Region'}, {'ITM_ID': 'a607', 'ITM_NM': '경원권', 'OBJ_ID': 'region_2', 'OBJ_NM': '지역별', 'ORG_ID': '408', 'TBL_ID': 'DT_40803_N0003', 'OBJ_ID_SN': '2', 'UP_ITM_ID': 'a6', 'ITM_NM_ENG': 'Gyeongwon-kwon', 'OBJ_NM_ENG': 'Region'}, {'ITM_ID': 'a7', 'ITM_NM': '인천', 'OBJ_ID': 'region_2', 'OBJ_NM': '지역별', 'ORG_ID': '408', 'TBL_ID': 'DT_40803_N0003', 'OBJ_ID_SN': '2', 'ITM_NM_ENG': 'Incheon', 'OBJ_NM_ENG': 'Region'}, {'ITM_ID': 'a8', 'ITM_NM': '부산', 'OBJ_ID': 'region_2', 'OBJ_NM': '지역별', 'ORG_ID': '408', 'TBL_ID': 'DT_40803_N0003', 'OBJ_ID_SN': '2', 'ITM_NM_ENG': 'Busan', 'OBJ_NM_ENG': 'Region'}, {'ITM_ID': 'a801', 'ITM_NM': '중부산권', 'OBJ_ID': 'region_2', 'OBJ_NM': '지역별', 'ORG_ID': '408', 'TBL_ID': 'DT_40803_N0003', 'OBJ_ID_SN': '2', 'UP_ITM_ID': 'a8', 'ITM_NM_ENG': 'Jungbusan-kwon', 'OBJ_NM_ENG': 'Region'}, {'ITM_ID': 'a802', 'ITM_NM': '동부산권', 'OBJ_ID': 'region_2', 'OBJ_NM': '지역별', 'ORG_ID': '408', 'TBL_ID': 'DT_40803_N0003', 'OBJ_ID_SN': '2', 'UP_ITM_ID': 'a8', 'ITM_NM_ENG': 'Dongbusan-kwon', 'OBJ_NM_ENG': 'Region'}, {'ITM_ID': 'a803', 'ITM_NM': '서부산권', 'OBJ_ID': 'region_2', 'OBJ_NM': '지역별', 'ORG_ID': '408', 'TBL_ID': 'DT_40803_N0003', 'OBJ_ID_SN': '2', 'UP_ITM_ID': 'a8', 'ITM_NM_ENG': 'Seobusan-kwon', 'OBJ_NM_ENG': 'Region'}, {'ITM_ID': 'a9', 'ITM_NM': '대구', 'OBJ_ID': 'region_2', 'OBJ_NM': '지역별', 'ORG_ID': '408', 'TBL_ID': 'DT_40803_N0003', 'OBJ_ID_SN': '2', 'ITM_NM_ENG': 'Daegu', 'OBJ_NM_ENG': 'Region'}, {'ITM_ID': 'a10', 'ITM_NM': '광주', 'OBJ_ID': 'region_2', 'OBJ_NM': '지역별', 'ORG_ID': '408', 'TBL_ID': 'DT_40803_N0003', 'OBJ_ID_SN': '2', 'ITM_NM_ENG': 'Gwangju', 'OBJ_NM_ENG': 'Region'}, {'ITM_ID': 'a11', 'ITM_NM': '대전', 'OBJ_ID': 'region_2', 'OBJ_NM': '지역별', 'ORG_ID': '408', 'TBL_ID': 'DT_40803_N0003', 'OBJ_ID_SN': '2', 'ITM_NM_ENG': 'Daejeon', 'OBJ_NM_ENG': 'Region'}, {'ITM_ID': 'a12', 'ITM_NM': '울산', 'OBJ_ID': 'region_2', 'OBJ_NM': '지역별', 'ORG_ID': '408', 'TBL_ID': 'DT_40803_N0003', 'OBJ_ID_SN': '2', 'ITM_NM_ENG': 'Ulsan', 'OBJ_NM_ENG': 'Region'}, {'ITM_ID': 'a13', 'ITM_NM': '세종', 'OBJ_ID': 'region_2', 'OBJ_NM': '지역별', 'ORG_ID': '408', 'TBL_ID': 'DT_40803_N0003', 'OBJ_ID_SN': '2', 'ITM_NM_ENG': 'Sejong', 'OBJ_NM_ENG': 'Region'}, {'ITM_ID': 'a14', 'ITM_NM': '강원', 'OBJ_ID': 'region_2', 'OBJ_NM': '지역별', 'ORG_ID': '408', 'TBL_ID': 'DT_40803_N0003', 'OBJ_ID_SN': '2', 'ITM_NM_ENG': 'Gangwon', 'OBJ_NM_ENG': 'Region'}, {'ITM_ID': 'a15', 'ITM_NM': '충북', 'OBJ_ID': 'region_2', 'OBJ_NM': '지역별', 'ORG_ID': '408', 'TBL_ID': 'DT_40803_N0003', 'OBJ_ID_SN': '2', 'ITM_NM_ENG': 'Chungbuk', 'OBJ_NM_ENG': 'Region'}, {'ITM_ID': 'a16', 'ITM_NM': '충남', 'OBJ_ID': 'region_2', 'OBJ_NM': '지역별', 'ORG_ID': '408', 'TBL_ID': 'DT_40803_N0003', 'OBJ_ID_SN': '2', 'ITM_NM_ENG': 'Chungnam', 'OBJ_NM_ENG': 'Region'}, {'ITM_ID': 'a17', 'ITM_NM': '전북', 'OBJ_ID': 'region_2', 'OBJ_NM': '지역별', 'ORG_ID': '408', 'TBL_ID': 'DT_40803_N0003', 'OBJ_ID_SN': '2', 'ITM_NM_ENG': 'Jeonbuk', 'OBJ_NM_ENG': 'Region'}, {'ITM_ID': 'a18', 'ITM_NM': '전남', 'OBJ_ID': 'region_2', 'OBJ_NM': '지역별', 'ORG_ID': '408', 'TBL_ID': 'DT_40803_N0003', 'OBJ_ID_SN': '2', 'ITM_NM_ENG': 'Jeonnam', 'OBJ_NM_ENG': 'Region'}, {'ITM_ID': 'a19', 'ITM_NM': '경북', 'OBJ_ID': 'region_2', 'OBJ_NM': '지역별', 'ORG_ID': '408', 'TBL_ID': 'DT_40803_N0003', 'OBJ_ID_SN': '2', 'ITM_NM_ENG': 'Gyeongbuk', 'OBJ_NM_ENG': 'Region'}, {'ITM_ID': 'a20', 'ITM_NM': '경남', 'OBJ_ID': 'region_2', 'OBJ_NM': '지역별', 'ORG_ID': '408', 'TBL_ID': 'DT_40803_N0003', 'OBJ_ID_SN': '2', 'ITM_NM_ENG': 'Gyeongnam', 'OBJ_NM_ENG': 'Region'}, {'ITM_ID': 'a21', 'ITM_NM': '제주', 'OBJ_ID': 'region_2', 'OBJ_NM': '지역별', 'ORG_ID': '408', 'TBL_ID': 'DT_40803_N0003', 'OBJ_ID_SN': '2', 'ITM_NM_ENG': 'Jeju', 'OBJ_NM_ENG': 'Region'}, {'ITM_ID': '01', 'ITM_NM': '규모1', 'OBJ_ID': 'scale', 'OBJ_NM': '주택규모별', 'ORG_ID': '408', 'TBL_ID': 'DT_40803_N0003', 'OBJ_ID_SN': '3', 'ITM_NM_ENG': 'Scale1', 'OBJ_NM_ENG': 'Scale'}, {'ITM_ID': '02', 'ITM_NM': '규모2', 'OBJ_ID': 'scale', 'OBJ_NM': '주택규모별', 'ORG_ID': '408', 'TBL_ID': 'DT_40803_N0003', 'OBJ_ID_SN': '3', 'ITM_NM_ENG': 'Scale2', 'OBJ_NM_ENG': 'Scale'}, {'ITM_ID': '03', 'ITM_NM': '규모3', 'OBJ_ID': 'scale', 'OBJ_NM': '주택규모별', 'ORG_ID': '408', 'TBL_ID': 'DT_40803_N0003', 'OBJ_ID_SN': '3', 'ITM_NM_ENG': 'Scale3', 'OBJ_NM_ENG': 'Scale'}, {'ITM_ID': '04', 'ITM_NM': '규모4', 'OBJ_ID': 'scale', 'OBJ_NM': '주택규모별', 'ORG_ID': '408', 'TBL_ID': 'DT_40803_N0003', 'OBJ_ID_SN': '3', 'ITM_NM_ENG': 'Scale4', 'OBJ_NM_ENG': 'Scale'}, {'ITM_ID': '05', 'ITM_NM': '규모5', 'OBJ_ID': 'scale', 'OBJ_NM': '주택규모별', 'ORG_ID': '408', 'TBL_ID': 'DT_40803_N0003', 'OBJ_ID_SN': '3', 'ITM_NM_ENG': 'Scale5', 'OBJ_NM_ENG': 'Scale'}, {'ITM_ID': '06', 'ITM_NM': '규모6', 'OBJ_ID': 'scale', 'OBJ_NM': '주택규모별', 'ORG_ID': '408', 'TBL_ID': 'DT_40803_N0003', 'OBJ_ID_SN': '3', 'ITM_NM_ENG': 'Scale6', 'OBJ_NM_ENG': 'Scale'}]
    [2], 개발가이드 -> 통계표설명 -> 수록정보 : [{'PRD_SE': '월', 'END_PRD_DE': '2023.05', 'STRT_PRD_DE': '2012.01'}]
    :param request_day:
    :param dbs:
    :return:
    """

    start_time = time.time()
    if "stats_code" in context["dag_run"].conf:
        stats_code = context["dag_run"].conf["stats_code"]
        logger.info(
            f"[LAKE][KOSIS][KOSIS_UNIVERSE][DB:{dbs}][STATS_CODE: {stats_code}] START"
        )
        map_list = [stats_code]
    else:
        logger.info(f"[LAKE][KOSIS][KOSIS_UNIVERSE][DB:{dbs}] START")
        # is_use가 True인 stats_code를 가져옵니다.
        map_list = list(
            StatsKosisGroupUniverse.objects.using(dbs[0])
            .filter(is_use=True)
            .values_list("stats_code", flat=True)
        )

    raw_data = []
    # map을 반복합니다.
    for maps in map_list:
        # 0 = 통합검색, 1 = 분류/항목, 2 = 수록정보
        data_list = []
        # 불러온 맵 데이터를 반복하며 분류항목과 수록정보를 가져옵니다.
        data_list.append(get_stats_kosis_total_serch(stats_code=maps))
        data_list.append(get_stats_kosis_category_list(total_serch=data_list[0][0]))
        data_list.append(get_stats_kosis_universe_info(total_serch=data_list[0][0]))
        logger.info(f"{maps} Done")
        raw_data.append(data_list)
        # 너무 빠르게 요청하면 간혈적으로 API가 불안정해지는 현상이 발생해 타임렉을 조금 두었습니다
        time.sleep(0.5)

    for db in dbs:
        try:
            DataLake(
                source="kosis",
                endpoint=f"kosis_meta_data",
                date=request_day,
                source_param={"type": "statistics_kosis"},
                rawdata={f"{request_day}": raw_data},
            ).save(using=db)

        except Exception as e:
            logger.error(f"[LAKE][KOSIS][KOSIS_UNIVERSE][DB:{db}] save Failed. {e}")
            raise

        end_time = time.time()

        logger.info(
            f"[LAKE][KOSIS][KOSIS_UNIVERSE][DB:{dbs}] {len(raw_data)} END {timedelta(seconds=end_time-start_time)}, {request_day}"
        )
