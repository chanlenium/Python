# import math
# import time
# from datetime import datetime
#
# import pandas as pd
# import requests
# import SetupDjangoORM
# from airflow.models.variable import Variable
# from decouple import config
# from loguru import logger
# from table.models.lake.datalake import DataLake
# from table.models.warehouse.stats_ecos import StatsEcosGroupUniverse
#
#
# def get_ecos_map_data(stats_code_df: pd.DataFrame, idle: int = 1) -> pd.DataFrame:
#     """
#     stats_code가 들어있는 데이터프레임을 받으면 검색에 필요한 데이터프레임을 만들어 반환합니다.
#     :param map_df:
#     :param idle:
#     :return:
#     """
#
#     map_list = []
#
#     for i in range(len(stats_code_df)):
#         time.sleep(idle)
#         url = f"https://ecos.bok.or.kr/api/StatisticItemList/{Variable.get('ECOS_API_KEY')}/json/kr/1/100000/{stats_code_df['stats_code'][i]}"
#         # 데이터가 존재하지 않을경우 다음과 같은 에러를 표기합니다.
#         try:
#             response = requests.get(url).json()["StatisticItemList"]["row"]
#         except KeyError:
#             response = []
#             logger.error(f"{stats_code_df['stats_code'][i]} 데이터가 존재하지 않습니다.")
#             raise
#
#         map_list = map_list + response
#         logger.info(f"데이터 맵 수집중 .. {i+1}/{len(stats_code_df)}")
#
#     response = pd.DataFrame(map_list)[
#         ["STAT_CODE", "START_TIME", "END_TIME", "CYCLE", "DATA_CNT"]
#     ]
#
#     response.rename(
#         columns={
#             "STAT_CODE": "stats_code",
#             "DATA_CNT": "max_count",
#             "CYCLE": "quarters",
#         },
#         inplace=True,
#     )
#
#     # 위의 map은 여러가지 카테고리 (예를들면 환율데이터라고 친다면 원/달러, 원/위안 등등 여러가지로 분리되어있다)로 나누어져 있는 데이터를 한번에 조회하기 위해 최종적으로 합쳐주는 코드입니다.
#     # 시작일은 최초날짜가 되어야 하므로 최소값, 마지막일은 최대 날짜가 되어야 하므로 맥스값을 설정했습니다.
#     response = (
#         response.groupby(["stats_code", "quarters"])
#         .agg({"START_TIME": "min", "max_count": "sum", "END_TIME": "max"})
#         .reset_index()
#     )
#     return response
#
#
# def stats_ecos_change_date(start_day: str, end_day: str, quarters: str) -> list:
#     """
#     날짜 구조를 ECOS에 맞게 변경하는 함수입니다.
#     :param start_day:
#     :param end_day:
#     :param quarters:
#     :return:
#     """
#     if quarters == "A":
#         start = start_day[:4]
#         end = end_day[:4]
#
#     if quarters == "D":
#         start = start_day
#         end = end_day
#
#     if quarters == "S":
#         # start
#         if int(start_day[4:6]) > 6:
#             start = start_day[:4] + "S2"
#         else:
#             start = start_day[:4] + "S1"
#         # end
#         if int(end_day[4:6]) > 6:
#             end = end_day[:4] + "S3"
#         else:
#             end = end_day[:4] + "S1"
#
#     if quarters == "Q":
#         # start
#         if int(start_day[4:6]) > 9:
#             start = start_day[:4] + "Q4"
#         elif int(start_day[4:6]) > 6:
#             start = start_day[:4] + "Q3"
#         elif int(start_day[4:6]) > 3:
#             start = start_day[:4] + "Q2"
#         else:
#             start = start_day[:4] + "Q1"
#         # end
#         if int(end_day[4:6]) > 9:
#             end = end_day[:4] + "Q4"
#         elif int(end_day[4:6]) > 6:
#             end = end_day[:4] + "Q3"
#         elif int(end_day[4:6]) > 3:
#             end = end_day[:4] + "Q2"
#         else:
#             end = end_day[:4] + "Q1"
#
#     if quarters == "M":
#         start = start_day[:6]
#         end = end_day[:6]
#
#     if quarters == "SM":
#         logger.warning("SM을 설정해 주어야 합니다.")
#         raise
#
#     return [start, end]
#
#
# def stats_ecos_request_timeseries_data(
#     map_df: pd.DataFrame,
#     idle: int = 1,
# ) -> list:
#     """
#     stats_code에 있는 모든 데이터를 가져오는 함수입니다.
#     :param map_df:
#     :param bulk:
#     :param request_day:
#     :param idle:
#     :param start_day:
#     :param end_day:
#     :return:
#     """
#
#     data_list = []
#     # 맵 데이터 수만큼 반복합니다.
#     for i in range(len(map_df)):
#         base_url = f"https://ecos.bok.or.kr/api/StatisticSearch/{Variable.get('ECOS_API_KEY')}/json/kr/1/100000/{map_df['stats_code'][i]}/{map_df['quarters'][i]}/"
#         # 벌크가 False일 경우 최근 데이터를 가져온다.
#         url = base_url + f"{map_df['END_TIME'][i]}/{map_df['END_TIME'][i]}"
#         logger.info(
#             f"[STATS_CODE : {map_df['stats_code'][i]}][QUARTERS : {map_df['quarters'][i]}][DATE: {map_df['END_TIME'][i]}]"
#         )
#
#         response = requests.get(url)
#         response = response.json()["StatisticSearch"]["row"]
#         data_list = data_list + response
#         time.sleep(idle)
#     return data_list
#
#
# def ecos_timeseries_to_datalake(
#     dbs: list,
#     logical_date: datetime,
#     idle: int = 2,
# ):
#     """
#     한국은행에서 api로 제공하는 데이터를 datalake에 적재하는 함수입니다.
#     적재하는 목록은 stats_map 테이블에서 그룹으로 가져옵니다.
#     WareHouseEcosMap 함수를 먼저 실행하셔야 합니다.
#     :param logical_date:
#     :param idle:
#     :param dbs:
#     :return:
#     """
#     request_day = datetime.strftime(logical_date, "%Y%m%d")
#     logger.info(f"[LAKE][ECOS][ECOS_TIMESERIES][DB:{dbs}] START")
#
#     # step 1 : GroupUniverse에서 is_use=True,  stats_code만을 요청하는 부분입니다.
#     stats_code_df = pd.DataFrame(
#         StatsEcosGroupUniverse.objects.using(dbs[0])
#         .filter(is_use=True, universe_type="stats")
#         .values("stats_code")
#     ).reset_index(drop=True)
#
#     # step 2 :데이터를 추출하기 위한 맵을 가져오는 함수입니다.
#     map_df = get_ecos_map_data(stats_code_df=stats_code_df, idle=idle)
#
#     raw_data_list = []
#     tmp_groups = map_df.groupby("stats_code")
#
#     # step 3 :맵 데이터 프레임을 가지고 실제 데이터를 추출
#     for k, v in tmp_groups:
#         raw_data = stats_ecos_request_timeseries_data(
#             map_df=v.reset_index(drop=True),
#             idle=idle,
#         )
#         logger.info(f"{k} END")
#         # step 6 : 각 stats_code별로 리스트에 저장
#         raw_data_list.append([k, raw_data])
#
#     # step 7 : 저장
#     for db in dbs:
#         for raw_data in raw_data_list:
#             try:
#                 DataLake(
#                     source="ecos",
#                     endpoint=f"ecos_timeseries_{raw_data[0]}",
#                     source_param={"type": "ecos_data"},
#                     rawdata={f"{request_day}": raw_data[1]},
#                     date=logical_date.date(),
#                 ).save(using=db)
#             except Exception as e:
#                 logger.error(
#                     f"[LAKE][ECOS][ECOS_TIMESERIES_{raw_data[0]}][db: {db}] ECOS Date : {request_day}, {len(raw_data[1])} Failed. {e}"
#                 )
#             logger.info(
#                 f"[LAKE][ECOS][ECOS_TIMESERIES_{raw_data[0]}][db: {db}] ECOS Date : {request_day}, {len(raw_data[1])} Success."
#             )
