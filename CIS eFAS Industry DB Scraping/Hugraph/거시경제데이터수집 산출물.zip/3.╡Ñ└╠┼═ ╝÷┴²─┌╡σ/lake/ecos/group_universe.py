import time
from datetime import datetime, timedelta

import requests
import SetupDjangoORM
from airflow.models.variable import Variable
from loguru import logger
from table.models.lake.datalake import DataLake


def request_ecos_group_universe() -> list:
    """
    ecos 통계 정보를 가져오는 코드입니다.
    :return:
    """
    url = f'https://ecos.bok.or.kr/api/StatisticTableList/{Variable.get("ECOS_API_KEY")}/json/kr/1/100000'
    response = requests.get(url).json()["StatisticTableList"]["row"]

    return response


def ecos_group_universe_to_datalake(request_day: str, dbs: list):
    """
    ecos 통계 정보를 저장하는 코드입니다.
    :param request_day:
    :param dbs:
    :return:
    """
    start_time = time.time()

    logger.info(f"[LAKE][ECOS][ECOS_GROUP_UNIVERSE][DB:{dbs}] START")

    raw_data = request_ecos_group_universe()

    for db in dbs:
        try:
            DataLake(
                source="ecos",
                endpoint="group_universe",
                source_param={"type": "statistics"},
                rawdata={f"{request_day}": raw_data},
                date=datetime.strptime(request_day, "%Y%m%d").date(),
            ).save(using=db)
        except Exception as e:
            logger.error(f"[LAKE][ECOS][ECOS_GROUP_UNIVERSE][DB:{db}] save Failed. {e}")
            raise

        end_time = time.time()

        logger.info(
            f"[LAKE][ECOS][ECOS_GROUP_UNIVERSE][DB:{db}] END {timedelta(seconds=end_time-start_time)}, {request_day}"
        )
