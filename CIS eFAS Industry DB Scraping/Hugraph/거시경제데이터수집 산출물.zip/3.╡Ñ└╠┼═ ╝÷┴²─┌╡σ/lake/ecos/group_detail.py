import time
from datetime import datetime, timedelta

import pandas as pd
import requests
import SetupDjangoORM
from airflow.models.variable import Variable
from loguru import logger
from table.models.lake.datalake import DataLake
from table.models.warehouse.stats_ecos import StatsEcosGroupUniverse


def request_ecos_group_detail_data(
    db: str, idle: int = 1, stats_code: list = None
) -> list:
    """
    디테일 데이터를 가져오는 코드입니다.
    :param db:
    :param request_day:
    :param idle:
    :return:
    """
    if stats_code is not None:
        obj_df = pd.DataFrame(
            StatsEcosGroupUniverse.objects.using(db)
            .filter(stats_code__in=stats_code)
            .values("stats_code")
        )
    else:
        obj_df = pd.DataFrame(
            StatsEcosGroupUniverse.objects.using(db)
            .filter(is_use=True, has_data=True, universe_type="stats")
            .values("stats_code")
        )

    # 디테일 데이터를 호출하는 코드
    raw_data = []

    for i in range(len(obj_df)):
        time.sleep(idle)

        url = f"https://ecos.bok.or.kr/api/StatisticItemList/{Variable.get('ECOS_API_KEY')}/json/kr/1/100000/{obj_df['stats_code'][i]}"

        try:
            response = requests.get(url).json()["StatisticItemList"]["row"]
        except KeyError:
            # 제공 하지 않는 데이터 무시
            logger.warning(f"{obj_df['stats_code'][i]} 데이터가 존재하지 않습니다.")
            continue

        raw_data = raw_data + response

        # 로그
        if i % 10 == 0:
            logger.info(f"{i+1}/{len(obj_df)}")

    return raw_data


def ecos_group_detail_to_datalake(request_day: str, dbs: list, **context):
    """
    ecos_statistics_list로 구한 lake를 이용하여 세부사항 데이터를 lake에 저장하는 함수입니다.
    즉 ecos_statistics_list함수를 미리 실행해야합니다.
    :return:
    """
    start_time = time.time()
    if "stats_code" in context["dag_run"].conf:
        logger.info(
            f"[LAKE][ECOS][GROUP_DETAIL][DB:{dbs}][STATS_CODE : {context['dag_run'].conf['stats_code']}] START"
        )
        raw_data = request_ecos_group_detail_data(
            db=dbs[0], stats_code=[context["dag_run"].conf["stats_code"]]
        )
    else:
        logger.info(f"[LAKE][ECOS][GROUP_DETAIL][DB:{dbs}] START")
        raw_data = request_ecos_group_detail_data(db=dbs[0])

    for db in dbs:
        try:
            DataLake(
                source="ecos",
                endpoint="group_detail",
                source_param={"type": "statistics"},
                rawdata={f"{request_day}": raw_data},
                date=datetime.strptime(request_day, "%Y%m%d").date(),
            ).save(using=db)
        except Exception as e:
            logger.error(
                f"[LAKE][ECOS][GROUP_DETAIL][db: {db}] Date : {request_day} Failed. {e}"
            )

        end_time = time.time()
        logger.info(
            f"[LAKE][ECOS][GROUP_DETAIL][db: {db}] Date : {request_day} Success. {timedelta(seconds=end_time-start_time)}"
        )
