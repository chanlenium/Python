from datetime import datetime

import pandas as pd
import SetupDjangoORM
from dateutil.relativedelta import relativedelta
from loguru import logger
from table.models.lake.datalake import DataLake
from table.models.warehouse.stats_ecos import StatsEcosGroupUniverse
from tasks.lake.core.ecos import ecos


def get_ecos_timeseries_half_month_date(request_day: str) -> tuple[str, str]:
    """
    더미 데이터
    :param dbs:
    :param logical_date:
    :return:
    """
    from tasks.lake.ecos.timeseries_half_month import (
        ecos_timeseries_half_month_to_datalake,
    )

    start_date = datetime.strftime(
        datetime.strptime(request_day, "%Y%m%d").date() - relativedelta(months=18),
        "%Y%m%d",
    )
    if start_date[4:6] in ["12", "11", "10", "09", "08", "07"]:
        start_date = start_date[:4] + "S1"
    elif start_date[4:6] in ["06", "05", "04", "03", "02", "01"]:
        start_date = start_date[:4] + "S2"

    end_date = request_day
    if end_date[4:6] in ["12", "11", "10", "09", "08", "07"]:
        end_date = end_date[:4] + "S1"
    elif end_date[4:6] in ["06", "05", "04", "03", "02", "01"]:
        end_date = end_date[:4] + "S2"
    return start_date, end_date


def ecos_timeseries_half_month_to_datalake(
    dbs: list,
    request_day: str,
):
    """
    한국은행에서 api로 제공하는 데이터를 datalake에 적재하는 함수입니다.
    적재하는 목록은 stats_map 테이블에서 그룹으로 가져옵니다.
    WareHouseEcosMap 함수를 먼저 실행하셔야 합니다.
    :return:
    """

    logger.info(f"[LAKE][ECOS][ECOS_TIMESERIES_SM][DB:{dbs}] START")
    start_date, end_date = get_ecos_timeseries_half_month_date(request_day=request_day)
    from table.models.warehouse.stats_ecos import StatsEcosGroupPeriod

    # 1. stats code load
    is_use_obj = (
        StatsEcosGroupUniverse.objects.using(dbs[0])
        .filter(is_use=True)
        .values("stats_code")
    )
    # step 2. 데이터를 추출하기 위한 맵을 가져온다.\
    map_df = pd.DataFrame(
        StatsEcosGroupPeriod.objects.using(dbs[0])
        .filter(stats_code__in=is_use_obj, period="HM")
        .values("stats_code", "start_date", "end_date")
    )
    if map_df.empty:
        logger.info(
            f"[LAKE][ECOS][ECOS_TIMESERIES_SM][db: {dbs}] ECOS Date : {request_day}, 0 Success."
        )
    else:
        # step 2. 맵 데이터 프레임을 가지고 실제 데이터를 추출하는 함수입니다.
        tmp_groups = map_df.groupby("stats_code")
        raw_data = []
        for k, v in tmp_groups:
            # Step 3. 날짜를 구한다
            change_day = ecos.stats_ecos_change_date(
                start_day=start_date, end_day=end_date, map_df=v, quarter="D"
            )

            # Step 전체 데이터를 가져올땐 warehouse에 적재되어 있는 데이터를 이용해서 각 stats code별로 다르게 설정해야하는 번거로움이 존재해 어쩔 수 없이
            # to datalake에서 전처리를 수행합니다.
            if start_date == end_date:
                change_day = [v["START_TIME"][0], v["END_TIME"][0]]

            # 데이터를 가져온다.
            tmp_data = ecos.stats_ecos_request_timeseries_data(
                map_df=v,
                request_day=change_day[1],
                from_date=change_day[0],
                quarter="HM",
            )
            raw_data = raw_data + tmp_data
        for db in dbs:
            try:
                DataLake(
                    source="ecos",
                    endpoint=f"ecos_timeseries_HM",
                    source_param={"type": "ecos_data"},
                    rawdata={f"{request_day}": raw_data},
                    date=datetime.strptime(request_day, "%Y%m%d").date(),
                ).save(using=db)
            except Exception as e:
                logger.error(
                    f"[LAKE][ECOS][ECOS_TIMESERIES_HM][db: {db}] ECOS Date : {request_day}, {len(raw_data)} Failed. {e}"
                )
            logger.info(
                f"[LAKE][ECOS][ECOS_TIMESERIES_HM][db: {db}] ECOS Date : {request_day}, {len(raw_data)} Success."
            )
