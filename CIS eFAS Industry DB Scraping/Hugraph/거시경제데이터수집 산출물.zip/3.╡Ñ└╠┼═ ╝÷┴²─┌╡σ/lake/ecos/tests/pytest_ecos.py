from unittest.mock import patch

import pytest

request_day = "20240103"
dbs = ["test"]

from tasks.lake.ecos.fx_ecos_group_detail import fx_ecos_group_detail_to_datalake


@pytest.mark.tmp
@patch("table.models.lake.datalake.DataLake.save")
def test_fx_ecos_group_detail(save, load_pickle_file):
    # Mocking
    patch(
        "tasks.lake.ecos.fx_ecos_group_detail.request_fx_ecos_group_detail_data",
        return_value=load_pickle_file["request_fx_ecos_group_detail_data"],
    ).start()
    test = fx_ecos_group_detail_to_datalake(request_day=request_day, dbs=dbs)
    assert test > 0
