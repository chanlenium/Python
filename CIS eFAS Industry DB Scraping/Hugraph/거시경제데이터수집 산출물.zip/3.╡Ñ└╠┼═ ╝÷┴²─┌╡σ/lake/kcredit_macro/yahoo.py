import time
from datetime import datetime, timedelta, timezone

import requests
from dateutil.relativedelta import relativedelta
from loguru import logger
from table.models.lake import DataLake


def get_yahoo_timeseries(start_date: str, end_date: str) -> str:
    start_day = str(int(datetime.strptime(start_date, "%Y%m%d").timestamp()))
    end_day = str(int(datetime.strptime(end_date, "%Y%m%d").timestamp()))
    # datetime 객체를 timestamp로 변환
    url = f"https://query1.finance.yahoo.com/v7/finance/download/%5ESOX?period1={start_day}&period2={end_day}&interval=1d&events=history&includeAdjustedClose=true"
    headers = {
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
        "Accept-Encoding": "gzip, deflate, br",
        "Accept-Language": "ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7",
        "Referer": "https://finance.yahoo.com/quote/%5ESOX/history?period1=1676303274&period2=1707839274&interval=1d&filter=history&frequency=1d&includeAdjustedClose=true",
        "Sec-Ch-Ua": '"Not A(Brand";v="99", "Google Chrome";v="121", "Chromium";v="121"',
        "Sec-Ch-Ua-Mobile": "?0",
        "Sec-Ch-Ua-Platform": '"macOS"',
        "Sec-Fetch-Dest": "document",
        "Sec-Fetch-Mode": "navigate",
        "Sec-Fetch-Site": "same-site",
        "Sec-Fetch-User": "?1",
        "Upgrade-Insecure-Requests": "1",
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
    }
    response = requests.get(url=url, headers=headers).text
    return response


def yahoo_timeseries_to_datalake(dbs: list, request_day: str, **context):
    """
    https://finance.yahoo.com/quote/%5ESOX/history?p=%5ESOX 데이터를 가져와서 datalake에 적재하는 함수입니다.
    :param dbs:
    :param request_day:
    :return:
    """
    start_time = time.time()
    request_day_date = datetime.strptime(request_day + "09", "%Y%m%d%H")
    # 2. date 설정
    if "year" in context["dag_run"].conf:
        start_day = context["dag_run"].conf["year"] + "0101"
    else:
        start_day = (
            datetime.strptime(request_day + "09", "%Y%m%d%H") - relativedelta(months=2)
        ).strftime("%Y%m%d")
    end_day = start_day[:4] + "1231"
    data = get_yahoo_timeseries(start_date=start_day, end_date=end_day)
    for db in dbs:
        try:
            if "year" in context["dag_run"].conf:
                DataLake(
                    source="yahoo",
                    endpoint=f"kcredit_timeseries",
                    date=request_day_date,
                    source_param={
                        "type": "yahoo_timeseries",
                        "year": context["dag_run"].conf["year"],
                    },
                    rawdata={f"{request_day}": data},
                ).save(using=db)
            else:
                DataLake(
                    source="yahoo",
                    endpoint=f"kcredit_timeseries",
                    date=request_day_date,
                    source_param={"type": "yahoo_timeseries", "year": "daily"},
                    rawdata={f"{request_day}": data},
                ).save(using=db)

        except Exception as e:
            logger.error(
                f"[LAKE][Yahoo][Yahoo_TIMESERIES][DB:{db}][Year: {start_day[:4]}] save Failed. {e}"
            )
            raise

    end_time = time.time()

    logger.info(
        f"[LAKE][Yahoo][Yahoo_TIMESERIES][DB:{dbs}][Year: {start_day[:4]}] END {timedelta(seconds=end_time-start_time)}, {request_day}"
    )
