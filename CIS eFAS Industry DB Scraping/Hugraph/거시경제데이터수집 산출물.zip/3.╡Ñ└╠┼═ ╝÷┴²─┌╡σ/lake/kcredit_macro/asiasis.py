import time
from datetime import datetime, timedelta
from random import randint

import requests
from dateutil.relativedelta import relativedelta
from loguru import logger
from table.models.lake import DataLake


def get_bulk_date(request_day: str, bulk: bool) -> list:
    """
    https://www.asiasis.com/news/news_kr_jisu2.php 에서는 2013년 10월부터 데이터가 존재하므로, 2013년 10월부터 request_day까지의 1년단위
    날짜를 반환하는 함수입니다.
    :param request_day:
    :return:
    """
    if bulk is True:
        start_date = datetime(2013, 10, 1)
    else:
        start_date = datetime.strptime(request_day, "%Y%m%d") - relativedelta(months=10)
    end_date = datetime.strptime(request_day, "%Y%m%d")
    standard_date = start_date
    date_list = []
    while standard_date < end_date:
        date_list.append(standard_date.strftime("%Y%m%d"))
        standard_date += relativedelta(years=1)

    date_list.append(None)
    return date_list


def get_asiasis_timeseries(start_day: str) -> str:
    if start_day is None:
        tsearch = ""
    else:
        tsearch = "?tsearch=" + start_day[:4] + "-" + start_day[4:6]
    url = f"http://www.asiasis.com/news/news_kr_jisu2.php{tsearch}"
    headers = {
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
        "Accept-Encoding": "gzip, deflate",
        "Accept-Language": "ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7",
        "Connection": "keep-alive",
        "Host": "www.asiasis.com",
        "Referer": "http://www.asiasis.com/news/news_kr_jisu2.php?tsearch=2023-10",
        "Upgrade-Insecure-Requests": "1",
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
    }
    response = requests.get(url=url, headers=headers)
    return response.text


def asiasis_timeseries_to_datalake(dbs: list, request_day: str, **context):
    start_time = time.time()
    request_day_date = datetime.strptime(request_day, "%Y%m%d")
    if "year" in context["dag_run"].conf:
        start_day = str(int(context["dag_run"].conf["year"]) + 1) + "1201"
        if int(start_day) < 20130701:
            start_day = "20130701"
        data = get_asiasis_timeseries(start_day=start_day)
    else:
        start_day = str(int(request_day[:4]) + 1) + "0101"
        data = get_asiasis_timeseries(start_day=None)
    if len(data) > 10000:
        logger.info(f"[LAKE][ASIASIS][ASIASIS_TIMESERIES] get Success.")
    else:
        logger.error(f"[LAKE][ASIASIS][ASIASIS_TIMESERIES] get Failed. {data}")
        raise
    for db in dbs:
        try:
            if "year" in context["dag_run"].conf:
                DataLake(
                    source="asiasis",
                    endpoint=f"kcredit_timeseries",
                    date=request_day_date,
                    source_param={
                        "type": "asiasis_timeseries",
                        "year": context["dag_run"].conf["year"],
                    },
                    rawdata={f"{request_day}": data},
                ).save(using=db)
            else:
                DataLake(
                    source="asiasis",
                    endpoint=f"kcredit_timeseries",
                    date=request_day_date,
                    source_param={
                        "type": "asiasis_timeseries",
                        "year": "daily",
                    },
                    rawdata={f"{request_day}": data},
                ).save(using=db)

        except Exception as e:
            logger.error(
                f"[LAKE][KAMA][ASIASIS_TIMESERIES][DB:{db}][year: {str(int(start_day[:4]) - 1)}] save Failed. {e}"
            )
            raise

        end_time = time.time()
        logger.info(
            f"[LAKE][ASIASIS][ASIASIS_TIMESERIES][DB:{dbs}][year: {str(int(start_day) - 1)[:4]}] END {timedelta(seconds=end_time-start_time)}, {request_day}"
        )
