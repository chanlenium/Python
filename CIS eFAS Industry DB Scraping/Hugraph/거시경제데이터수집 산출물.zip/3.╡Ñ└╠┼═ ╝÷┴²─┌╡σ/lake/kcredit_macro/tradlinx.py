import pickle
import time
from datetime import datetime, timedelta

import pandas as pd
from dateutil.relativedelta import relativedelta
from loguru import logger
from selenium.webdriver.common.by import By
from table.models.lake import DataLake
from tasks.lake.core.utils.utils_object import chrome_driver

try_count = 0


def haewoonMakeURL(start_day: str):
    global try_count
    driver = chrome_driver()
    try:
        ## (TradLinx) 컨테이너 운임지표 : CCFI, SCFI
        # Data reference : Go to TradLinx homepage
        url = "https://www.tradlinx.com/freight-index"
        driver.get(url)

        # Select Month because we need monthly data
        driver.find_element(
            By.XPATH,
            "/html/body/application/div/container-freight/div/div[2]/div/div[1]/div[3]/drp-input/div/div/span[2]",
        ).click()
        driver.find_element(
            By.XPATH,
            "/html/body/application/div/container-freight/div/div[2]/div/div[1]/div[3]/drp-input/div/div[2]/ul/li[2]",
        ).click()

        logger.info(
            driver.find_element(
                By.XPATH,
                "/html/body/application/div/container-freight/div/div[2]/div/div[1]/div[3]/drp-input/div/div/span[2]",
            ).text
        )

        driver.find_element(
            By.XPATH,
            "/html/body/application/div/container-freight/div/div[2]/div/div[1]/div[4]/div/i",
        ).click()  # Pick calendar
        time.sleep(5)

        # start_day 설정 start_day 1월
        # Set query condition : Select start day as '2020.1.1'
        # Click 'JAN'
        while driver.find_element(By.CLASS_NAME, "dtp-actual-month").text != "JAN":
            driver.find_element(By.CLASS_NAME, "dtp-select-month-before").click()
        # Click '2010'
        while (
            driver.find_element(By.CLASS_NAME, "dtp-actual-year").text >= start_day[:4]
        ):
            driver.find_element(By.CLASS_NAME, "dtp-select-year-before").click()
        # Click 'day 1'
        # Click 'day 1'
        driver.find_element(By.CLASS_NAME, "dtp-select-day").click()

        driver.find_element(By.CLASS_NAME, "dtp-btn-ok").click()
        time.sleep(5)

        containerDataFrame = pd.read_html(driver.page_source)[1]

        containerDataFrame = containerDataFrame.transpose()
        containerDataFrame.columns = containerDataFrame.iloc[0]
        containerDataFrame = containerDataFrame[1:]
        containerDataFrame["STD_YM"] = containerDataFrame.index.str.replace(" ", "")

        containerDataFrame.columns.name = None  # Delete column name 'Date All'
        containerDataFrame.reset_index(drop=True, inplace=True)  # index reset

        # empty Dataframe을 만들고(SCFI) 데이터 채움
        scfiIT_EFAS_MACRO_RAW = pd.DataFrame(
            columns=[
                "STD_YMD",
                "MACRO_GBN",
                "MACRO_CODE",
                "MACRO_NM",
                "MACRO_VALUE",
                "MACRO_UNIT",
            ]
        )
        scfiIT_EFAS_MACRO_RAW[["STD_YMD", "MACRO_VALUE"]] = containerDataFrame[
            ["STD_YM", "SCFI"]
        ]
        scfiIT_EFAS_MACRO_RAW["MACRO_GBN"] = "I"
        scfiIT_EFAS_MACRO_RAW["MACRO_CODE"] = "0028"
        scfiIT_EFAS_MACRO_RAW["MACRO_NM"] = "글로벌_해운운임지수_SCFI(컨테이너선)_월"
        scfiIT_EFAS_MACRO_RAW["MACRO_UNIT"] = "[index]"

        driver.quit()
        return scfiIT_EFAS_MACRO_RAW
    except:
        try_count += 1
        if try_count > 5:
            logger.error("5회 시도 모두 실패")
            driver.quit()
            raise
        print("오류 발생")
        driver.quit()
        print("5초 후 재시도")
        time.sleep(5)
        return haewoonMakeURL(start_day=start_day)  # 재귀함수


def tradlinx_timeseries_to_datalake(dbs: list, request_day: str, **context):
    """
    https://www.tradlinx.com/freight-index 데이터를 가져와서 datalake에 적재하는 함수입니다.
    :param dbs:
    :param request_day:
    :return:
    """
    start_time = time.time()
    request_day_date = datetime.strptime(request_day, "%Y%m%d")
    logger.info(f"[DB : {dbs}] {request_day} Start")
    # 2. date 설정
    if "year" in context["dag_run"].conf:
        start_day = context["dag_run"].conf["year"] + "0101"
    else:
        start_day = (
            datetime.strptime(request_day, "%Y%m%d") - relativedelta(years=1)
        ).strftime("%Y%m%d")[:6] + "01"
    data = haewoonMakeURL(start_day=start_day)
    for db in dbs:
        try:
            if "year" in context["dag_run"].conf:
                DataLake(
                    source="tradlinx",
                    endpoint=f"kcredit_timeseries",
                    date=request_day_date,
                    source_param={
                        "type": "tradlinx_timeseries",
                        "year": context["dag_run"].conf["year"],
                    },
                    rawdata_binary=pickle.dumps({request_day: data}),
                ).save(using=db)
            else:
                DataLake(
                    source="tradlinx",
                    endpoint=f"kcredit_timeseries",
                    date=request_day_date,
                    source_param={"type": "tradlinx_timeseries", "year": "daily"},
                    rawdata_binary=pickle.dumps({request_day: data}),
                ).save(using=db)

        except Exception as e:
            logger.error(
                f"[LAKE][Tradlinx][Tradlinx_TIMESERIES][DB:{db}][Year: {start_day[:4]}] save Failed. {e}"
            )
            raise

    end_time = time.time()

    logger.info(
        f"[LAKE][Tradlinx][Tradlinx_TIMESERIES][DB:{dbs}][Year: {start_day[:4]}] END {timedelta(seconds=end_time-start_time)}, {request_day}"
    )
