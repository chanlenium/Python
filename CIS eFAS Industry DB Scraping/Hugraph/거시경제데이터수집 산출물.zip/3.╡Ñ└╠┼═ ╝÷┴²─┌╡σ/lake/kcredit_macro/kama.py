import time
from datetime import datetime, timedelta
from random import randint

import requests
import SetupDjangoORM
from airflow.models import Variable
from dateutil.relativedelta import relativedelta
from loguru import logger
from table.models.lake.datalake import DataLake


def get_bulk_date(request_day: str) -> list:
    """
    https://www.asiasis.com/news/news_kr_jisu2.php 에서는 1991년 1월부터 데이터가 존재하므로, 2013년 10월부터 request_day까지의 1년단위
    날짜를 반환하는 함수입니다.
    :param request_day:
    :return:
    """
    start_date = datetime(2013, 10, 1)
    end_date = datetime.strptime(request_day, "%Y%m%d")
    standard_date = start_date
    date_list = []
    while standard_date < end_date:
        date_list.append(start_date.strftime("%Y%m%d"))
        start_date += relativedelta(years=1)

    date_list.append(None)
    return date_list


def kama_login_session() -> requests.Session:
    """
    kamalogin : https://www.kama.or.kr/MainController 에 로그인하고 해당 세션을 반환하는 함수입니다.
    :return:
    """
    login_url = "https://www.kama.or.kr/LoginController"

    # Define the login credentials
    username = Variable.get("KAMA_ID")
    password = Variable.get("KAMA_PASSWORD")
    headers = {
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
        "Accept-Encoding": "gzip, deflate, br, zstd",
        "Accept-Language": "ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7",
        "Cache-Control": "max-age=0",
        "Connection": "keep-alive",
        "Content-Length": "61",
        "Content-Type": "application/x-www-form-urlencoded",
        "Cookie": "JSESSIONID=4B2E59A55DD0C2FD2AC636E8C1FAEC79",
        "Host": "www.kama.or.kr",
        "Origin": "https://www.kama.or.kr",
        "Referer": "https://www.kama.or.kr/LoginController",
        "Sec-Ch-Ua": '"Chromium";v="121", "Not A(Brand";v="99"',
        "Sec-Ch-Ua-Mobile": "?0",
        "Sec-Ch-Ua-Platform": '"macOS"',
        "Sec-Fetch-Dest": "document",
        "Sec-Fetch-Mode": "navigate",
        "Sec-Fetch-Site": "same-origin",
        "Sec-Fetch-User": "?1",
        "Upgrade-Insecure-Requests": "1",
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
    }
    payload = {"cmd": "c", "user_id": username, "user_pw": password}
    session = requests.Session()
    session.post(url=login_url, headers=headers, json=payload)
    time.sleep(randint(4, 8))
    return session


def get_timeseries(session: requests.Session, start_date: str, end_date: str) -> str:
    """
    timeseries_month 데이터를 가져오는 함수입니다.

    :param session:
    :return:
    """
    pages_url = "http://stat.kama.or.kr/stats/Chart?key=stats_product&type=2"
    headers = {
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
        "Accept-Encoding": "gzip, deflate, br, zstd",
        "Accept-Language": "ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7",
        "Cache-Control": "max-age=0",
        "Connection": "keep-alive",
        "Content-Length": "205",
        "Content-Type": "application/x-www-form-urlencoded",
        "Host": "www.kama.or.kr",
        "Origin": "null",
        "Upgrade-Insecure-Requests": "1",
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
    }
    payload = f"selectType=&select=1&statsYear={start_date[:4]}&endYear={end_date[:4]}&statsMonthS=1&statsMonthE=12&chkTypeGroup_total=%BB%FD%BB%EA&chkTypeGroup_total=%B3%BB%BC%F6&chkTypeGroup_total=%BC%F6%B7%AE&chkTypeGroup_total=%B1%DD%BE%D7"
    query_string = {"key": "stats_product", "type": "2"}
    data = session.post(
        url=pages_url, headers=headers, data=payload, params=query_string
    )
    return data.text


def kama_timeseries_to_datalake(dbs: list, request_day: str, **context):
    """
    http://stat.kama.or.kr 사이트에서 timeseries_month 데이터를 가져와서 datalake에 저장하는 함수입니다.
    :return:
    """
    start_time = time.time()
    request_day_date = datetime.strptime(request_day, "%Y%m%d").date()
    # 1. 로그인
    session = kama_login_session()
    # 2. date 설정
    if "year" in context["dag_run"].conf:
        start_day = context["dag_run"].conf["year"] + "0101"
        end_day = start_day[:4] + "1231"
    else:
        start_day = (
            datetime.strptime(request_day, "%Y%m%d") - relativedelta(years=1)
        ).strftime("%Y%m%d")
        end_day = request_day[:4] + "1231"
    # 3. 데이터 가져오기
    data = get_timeseries(session=session, start_date=start_day, end_date=end_day)
    # 4. datalake에 저장
    for db in dbs:
        try:
            if "year" in context["dag_run"].conf:
                DataLake(
                    source="kama",
                    endpoint=f"kcredit_timeseries",
                    date=request_day_date,
                    source_param={
                        "type": "kama_timeseries",
                        "year": context["dag_run"].conf["year"],
                    },
                    rawdata={f"{request_day}": data},
                ).save(using=db)
            else:
                DataLake(
                    source="kama",
                    endpoint=f"kcredit_timeseries",
                    date=request_day_date,
                    source_param={"type": "kama_timeseries", "year": "daily"},
                    rawdata={f"{request_day}": data},
                ).save(using=db)

        except Exception as e:
            logger.error(
                f"[LAKE][KAMA][FRED_TIMESERIES][DB:{db}][Year: {start_day[:4]}] save Failed. {e}"
            )
            raise

    end_time = time.time()

    logger.info(
        f"[LAKE][KAMA][KAMA_TIMESERIES][DB:{dbs}][Year: {start_day[:4]}] END {timedelta(seconds=end_time-start_time)}, {request_day}"
    )
