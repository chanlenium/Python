import pickle
import time
from datetime import datetime, timedelta

import pandas as pd
from dateutil.relativedelta import relativedelta
from loguru import logger
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import Select, WebDriverWait
from table.models.lake import DataLake
from table.static.mapping.universe.kcredit import MAPPING_DATA
from tasks.lake.core.utils.utils_object import chrome_driver

retry = 0
dfEFAStoISTANSMAP = pd.DataFrame(
    MAPPING_DATA, columns=["EFAS_CD", "EFAS_NM", "ISTANS_NM"]
)
induUrlList = [
    ["26", "반도체", "https://istans.or.kr/in/newInTab.do?scode=4"],
    ["14", "의약", "https://istans.or.kr/in/newInTab.do?scode=3"],
    ["27", "디스플레이", "https://istans.or.kr/in/newInTab.do?scode=5"],
    ["29", "컴퓨터", "https://istans.or.kr/in/newInTab.do?scode=6"],
    ["30", "통신기기", "https://istans.or.kr/in/newInTab.do?scode=7"],
    ["31", "가전", "https://istans.or.kr/in/newInTab.do?scode=8"],
    ["32", "정밀기기", "https://istans.or.kr/in/newInTab.do?scode=9"],
    ["34", "전지", "https://istans.or.kr/in/newInTab.do?scode=10"],
    ["41", "항공", "https://istans.or.kr/in/newInTab.do?scode=11"],
    ["12", "석유화학", "https://istans.or.kr/in/newInTab.do?scode=14"],
    ["13", "정밀화학", "https://istans.or.kr/in/newInTab.do?scode=15"],
    ["28", "기타 전자부품", "https://istans.or.kr/in/newInTab.do?scode=17"],
    ["33", "전기기기", "https://istans.or.kr/in/newInTab.do?scode=18"],
    ["35", "일반목적기계", "https://istans.or.kr/in/newInTab.do?scode=19"],
    ["36", "특수목적기계", "https://istans.or.kr/in/newInTab.do?scode=20"],
    ["37", "자동차", "https://istans.or.kr/in/newInTab.do?scode=21"],
    ["40", "기타 수송장비", "https://istans.or.kr/in/newInTab.do?scode=23"],
    ["11", "석유정제", "https://istans.or.kr/in/newInTab.do?scode=33"],
    ["16", "고무", "https://istans.or.kr/in/newInTab.do?scode=82"],
    ["17", "플라스틱", "https://istans.or.kr/in/newInTab.do?scode=83"],
    ["18", "유리", "https://istans.or.kr/in/newInTab.do?scode=84"],
    ["19", "세라믹", "https://istans.or.kr/in/newInTab.do?scode=85"],
    ["20", "시멘트", "https://istans.or.kr/in/newInTab.do?scode=86"],
    ["21", "기타 비금속 광물", "https://istans.or.kr/in/newInTab.do?scode=87"],
    ["22", "철강", "https://istans.or.kr/in/newInTab.do?scode=88"],
    ["23", "비철금속", "https://istans.or.kr/in/newInTab.do?scode=89"],
    ["24", "주조", "https://istans.or.kr/in/newInTab.do?scode=90"],
    ["25", "조립금속", "https://istans.or.kr/in/newInTab.do?scode=91"],
    ["39", "조선", "https://istans.or.kr/in/newInTab.do?scode=92"],
    ["3", "음식료", "https://istans.or.kr/in/newInTab.do?scode=94"],
    ["4", "섬유", "https://istans.or.kr/in/newInTab.do?scode=96"],
    ["5", "의류", "https://istans.or.kr/in/newInTab.do?scode=97"],
    ["6", "가죽·신발", "https://istans.or.kr/in/newInTab.do?scode=98"],
    ["7", "목재", "https://istans.or.kr/in/newInTab.do?scode=99"],
    ["8", "제지", "https://istans.or.kr/in/newInTab.do?scode=100"],
    ["9", "인쇄", "https://istans.or.kr/in/newInTab.do?scode=101"],
    ["10", "기타 제조업", "https://istans.or.kr/in/newInTab.do?scode=103"],
]


def refineData(data, efasCode, efasName, isExport):
    data.reset_index(drop=False)
    data.iloc[0, 0] = efasName
    data.columns = data.iloc[0]
    data = data[1:2]
    if isExport:  # 수출데이터인 경우
        data = pd.melt(data, id_vars=efasName, value_name="EXPORT_MDOLLAR").sort_values(
            efasName
        )
    else:  # 무역수지 데이터인 경우
        data = pd.melt(
            data, id_vars=efasName, value_name="balanceOfTrade_MDOLLAR"
        ).sort_values(efasName)
    data.rename(columns={0: "STD_YM"}, inplace=True)
    data["STD_YM"] = data["STD_YM"].str.replace("년 ", "")
    data["STD_YM"] = data["STD_YM"].str.replace("월", "")
    data.reset_index(drop=True, inplace=True)
    data.insert(2, "EFAS_CD", efasCode)
    data.insert(3, "EFAS_NM", efasName)
    data.drop(columns=efasName, inplace=True)
    data = data.sort_values(by=["STD_YM"])
    return data


def crawlData(
    url: str,
    isExport: bool,
    start_day: str,
    efasCode: str,
    efasName: str,
    daily: bool,
):
    global retry
    driver = chrome_driver()
    try:
        driver.get(url)
        time.sleep(5)
        # 조회조건 설정을 위해 해당 iframe으로 이동 : "newSuTabMain > searchFrame"
        driver.switch_to.frame("newInTabMain")
        driver.switch_to.frame("searchFrame")
        driver.find_element(By.XPATH, '//*[@id="sub-tabs"]/li[8]/a').send_keys(
            Keys.ENTER
        )  # 국제 무역 클릭
        time.sleep(2)
        if isExport:
            driver.find_element(By.XPATH, '//*[@id="grid71"]').send_keys(
                Keys.ENTER
            )  # 수출 클릭
        else:
            driver.find_element(By.XPATH, '//*[@id="grid73"]').send_keys(
                Keys.ENTER
            )  # 무역수지
        time.sleep(3)
        driver.switch_to.frame("gridFrame")  # GridFrame으로 이동
        time.sleep(3)
        # 조회조건 설정 : 2020년 1월 (Xpath로 검색하면 동일 이름을 갖은 select 속성이 아닌 다른 element가 있어서 error 발생하므로 Full Xpath로 구현)
        elem = driver.find_element(
            By.XPATH, "/html/body/div[2]/div[1]/div[2]/div[1]/select"
        )
        select = Select(elem)
        select.select_by_visible_text("월")
        select.select_by_value("4")
        time.sleep(2)
        lastYYYY = int(
            driver.find_element(By.XPATH, '//*[@id="to_year_month"]').text.rsplit()[-1]
        )

        # 시작일 설정 daily가 True일 경우,
        if daily is True:
            startYYYY = int(start_day[:4])
            startMM = int(start_day[4:6])

        else:
            # daily가 True가 아닐경우
            startYYYY = int(start_day[:4])
            endYYYY = startYYYY
            startMM = 1
            if int(startYYYY) == lastYYYY:
                endMM = int(
                    driver.find_element(By.XPATH, '//*[@id="to_month"]').text.rsplit()[
                        -1
                    ]
                )
            else:
                endMM = 12

        # 시작년
        select = Select(
            driver.find_element(
                By.XPATH,
                "/html/body/div[2]/div[1]/div[2]/div[2]/div[1]/div/div[3]/div[1]/select",
            )
        )
        select.select_by_visible_text(str(startYYYY))
        select.select_by_value(str(startYYYY))
        time.sleep(1)
        # 시작월
        select = Select(
            driver.find_element(
                By.XPATH,
                "/html/body/div[2]/div[1]/div[2]/div[2]/div[1]/div/div[3]/div[2]/select",
            )
        )
        select.select_by_visible_text(str(startMM))
        select.select_by_value(str(startMM))
        time.sleep(1)
        if daily is False:
            logger.info(f"{startYYYY}")
            # 종료년
            select = Select(
                driver.find_element(
                    By.XPATH,
                    "/html/body/div[2]/div[1]/div[2]/div[2]/div[2]/div/div[3]/div[1]/select",
                )
            )
            select.select_by_visible_text(str(endYYYY))
            select.select_by_value(str(endYYYY))
            time.sleep(1)
            select = Select(
                driver.find_element(
                    By.XPATH,
                    "/html/body/div[2]/div[1]/div[2]/div[2]/div[2]/div/div[3]/div[2]/select",
                )
            )  # 종료월
            select.select_by_visible_text(str(endMM))
            select.select_by_value(str(endMM))
            time.sleep(1)

        # driver.find_element(By.XPATH, '/html/body/div[2]/div[1]/div[2]/div[2]/a').send_keys(Keys.ENTER) # 조회버튼 클릭
        element = driver.find_element(
            By.XPATH, "/html/body/div[2]/div[1]/div[2]/div[2]/a"
        )
        driver.execute_script("arguments[0].click();", element)
        time.sleep(10)
        page_source_df = pd.read_html(driver.page_source, flavor="lxml")
        dfHeader = page_source_df[2]
        dfBody = page_source_df[4]
        induName = page_source_df[3]
        dfBody.iloc[:, 0] = induName.iloc[:, [1]].values
        result = pd.concat([dfHeader, dfBody])
        driver.switch_to.default_content()
        WebDriverWait(driver, 5).until(
            EC.frame_to_be_available_and_switch_to_it((By.ID, "newInTabMain"))
        )
        refinedResult = refineData(result, efasCode, efasName, isExport)
        driver.quit()
        retry = 0
        return refinedResult
    except Exception as e:
        logger.warning(e)
        driver.quit()
        if retry > 5:
            logger.error("데이터를 가져오지 못했습니다. 크롤링을 종료합니다.")
            raise
        return crawlData(
            url=url,
            isExport=isExport,
            start_day=start_day,
            efasCode=efasCode,
            efasName=efasName,
            daily=daily,
        )


# Creating an empty Dictionary
efasDict = {}


def makeExportImportDB(start_day: str, daily: bool):
    for elem in induUrlList:
        if daily is False:
            logger.info(
                f"[Name: {elem[0]}{elem[1]}][Year: {int(start_day[:4])}] 크롤링중..."
            )
        else:
            logger.info(f"[Name: {elem[0]}{elem[1]}][Daily] 크롤링중...")
        efasCode = elem[0]  # 코드
        efasName = elem[1]  # 코드명
        url = elem[2]  # URL
        result = pd.DataFrame()
        exportData = crawlData(
            url=url,
            isExport=True,
            start_day=start_day,
            efasCode=efasCode,
            efasName=efasName,
            daily=daily,
        )
        balanceOfTradeData = crawlData(
            url=url,
            isExport=False,
            start_day=start_day,
            efasCode=efasCode,
            efasName=efasName,
            daily=daily,
        )
        merged = exportData.merge(
            balanceOfTradeData,
            left_on=["STD_YM", "EFAS_CD", "EFAS_NM"],
            right_on=["STD_YM", "EFAS_CD", "EFAS_NM"],
            how="outer",
        )
        merged["IMPORT_MDOLLAR"] = (
            merged["EXPORT_MDOLLAR"] - merged["balanceOfTrade_MDOLLAR"]
        )
        merged.drop(columns=["balanceOfTrade_MDOLLAR"], inplace=True)
        merged = merged.drop_duplicates()
        merged = merged.iloc[0:]
        result = pd.concat([result, merged])
        efasDict[efasName] = result

    dfEfasExportImort = pd.DataFrame()
    for elem in efasDict.values():
        dfEfasExportImort = pd.concat([dfEfasExportImort, elem])

    dfEfasExportImort.set_index("STD_YM", inplace=True)
    dfEfasExportImort = dfEfasExportImort.sort_values(
        ["STD_YM", "EFAS_CD"], ascending=[True, True]
    )

    dfEfasExportImort = pd.DataFrame()
    for elem in efasDict.values():
        dfEfasExportImort = pd.concat([dfEfasExportImort, elem])

    dfEfasExportImort.set_index("STD_YM", inplace=True)
    dfEfasExportImort = dfEfasExportImort.sort_values(
        ["STD_YM", "EFAS_CD"], ascending=[True, True]
    )
    dfEfasExportImort = dfEfasExportImort[
        dfEfasExportImort.EXPORT_MDOLLAR.notnull()
        & dfEfasExportImort.IMPORT_MDOLLAR.notnull()
    ]
    return dfEfasExportImort


def iSTANSCall(url: str, start_day: str, driver, daily: bool):
    global retry
    fromYYYY = start_day[:4]
    fromMM = str(int(start_day[4:6]))
    try:
        logger.info(url)
        driver.get(url)  # Get data from istansUrl
        time.sleep(3)
        # Move to inner iframe to set query condition ("newSuTabMain > searchFrame")
        driver.switch_to.frame("newSuTabMain")
        driver.switch_to.frame("searchFrame")
        # Set query condition : ex) From JAN 2010
        select = Select(driver.find_element(By.XPATH, '//*[@id="df_period"]'))
        select.select_by_visible_text("월")
        select.select_by_value("4")
        time.sleep(1)

        # 시작일 설정
        select = Select(driver.find_element(By.XPATH, '//*[@id="from_year_month"]'))
        select.select_by_visible_text(fromYYYY)
        select.select_by_value(fromYYYY)
        time.sleep(1)
        select = Select(driver.find_element(By.XPATH, '//*[@id="from_month"]'))
        select.select_by_visible_text(fromMM)
        select.select_by_value(fromMM)
        time.sleep(1)
        if daily is False:
            # 기본적으로 설정되어 있는 종료일과 같을경우엔 따로 month를 지정하지 않는다.
            max_year = driver.find_element(
                By.XPATH, '//*[@id="to_year_month"]'
            ).text.rsplit()
            if max_year[len(max_year) - 1] == fromYYYY:
                pass
            else:
                # 종료일 설정
                select = Select(
                    driver.find_element(By.XPATH, '//*[@id="to_year_month"]')
                )
                select.select_by_visible_text(fromYYYY)
                select.select_by_value(fromYYYY)
                time.sleep(1)
                select = Select(driver.find_element(By.XPATH, '//*[@id="to_month"]'))
                select.select_by_visible_text("12")
                select.select_by_value("12")
                time.sleep(1)
        # 조회
        driver.find_element(By.XPATH, '//*[@id="resultDiv"]/div[1]/div[1]/a').send_keys(
            Keys.ENTER
        )  # Click 'Query' button
        # driver.page_source 데이터는 동적으로 변하고 있어서, data에 driver.page_source값을 할당할 때 데이터가 변해버리면, warehouse 단계에서 pd.read_html을 수행할 수 없다.
        data = str(driver.page_source)
        cont = 0
        while True:
            page_source = driver.page_source
            if data != page_source:
                data = str(page_source)
                time.sleep(1)
            else:
                try:
                    dfHeader = pd.read_html(page_source)[2]
                except IndexError:
                    if cont == 10:
                        logger.error("데이터를 가져오지 못했습니다. 크롤링을 종료합니다.")
                        driver.quit()
                        raise
                    elif cont > 5:
                        logger.warning("데이터를 정상적으로 가져오지 못했습니다. 다시 시도합니다.")
                        driver.find_element(
                            By.XPATH, '//*[@id="resultDiv"]/div[1]/div[1]/a'
                        ).click()
                        cont += 1
                        time.sleep(5)
                        continue
                    else:
                        logger.warning("데이터를 정상적으로 가져오지 못했습니다. 다시 시도합니다.")
                        driver.find_element(
                            By.XPATH, '//*[@id="resultDiv"]/div[1]/div[1]/a'
                        ).click()
                        cont += 1
                        time.sleep(5)
                        continue
                dfBody = pd.read_html(page_source)[4]
                induName = pd.read_html(page_source)[3]
                dfBody.iloc[:, 0] = induName.iloc[:, [1]].values
                # dfIStansResult = dfHeader.append(dfBody)
                dfIStansResult = pd.concat([dfHeader, dfBody])
                # Refine Dataframe
                dfIStansResult.reset_index(drop=False)
                dfIStansResult.iloc[0, 0] = "iStansInduNM"
                dfIStansResult.columns = dfIStansResult.iloc[0]
                dfIStansResult = dfIStansResult[1:]
                # Chage data to long type using 'melt' function
                dfIStansResult = pd.melt(
                    dfIStansResult, id_vars=["iStansInduNM"], value_name="indexValue"
                ).sort_values("iStansInduNM")
                dfIStansResult.rename(columns={0: "STD_YM"}, inplace=True)
                dfIStansResult["STD_YM"] = dfIStansResult["STD_YM"].str.replace(
                    "년 ", ""
                )
                dfIStansResult["STD_YM"] = dfIStansResult["STD_YM"].str.replace("월", "")
                dfIStansResult = dfIStansResult.reset_index().merge(
                    dfEFAStoISTANSMAP,
                    left_on="iStansInduNM",
                    right_on="ISTANS_NM",
                    how="inner",
                )
                return dfIStansResult
    except Exception as e:
        logger.warning(e)
        driver.quit()
        return iSTANSCall(url=url, start_day=start_day, driver=driver, daily=daily)


def makeCommonDB(start_day: str, daily: bool):
    driver = chrome_driver()
    # 생산지수(원지수) : Istans > 주제별 통계 > 산업동향지수 > 생산지수(원지수)
    url = "https://istans.or.kr/su/newSuTab.do?scode=S120"
    iSTANSCallResult = iSTANSCall(
        url=url, start_day=start_day, driver=driver, daily=daily
    )
    dfPRODUC_INDEX = iSTANSCallResult.rename(columns={"indexValue": "PRODUC_INDEX"})

    # 서비스업생산지수(원지수, 불변지수) : Istans > 주제별 통계 > 산업동향지수 > 서비스업생산지수(불변지수)
    url = "https://istans.or.kr/su/newSuTab.do?scode=S358"
    iSTANSCallResult = iSTANSCall(
        url=url, start_day=start_day, driver=driver, daily=daily
    )
    dfServPRODUC_INDEX = iSTANSCallResult.rename(columns={"indexValue": "PRODUC_INDEX"})
    dfPRODUC_INDEX = pd.concat([dfPRODUC_INDEX, dfServPRODUC_INDEX])
    dfPRODUC_INDEX = dfPRODUC_INDEX[["STD_YM", "EFAS_CD", "EFAS_NM", "PRODUC_INDEX"]]
    dfPRODUC_INDEX.drop_duplicates(inplace=True)

    # 생산지수(계절조정) : Istans > 주제별 통계 > 산업동향지수 > 생산지수(계절조정)
    url = "https://istans.or.kr/su/newSuTab.do?scode=S350"
    iSTANSCallResult = iSTANSCall(
        url=url, start_day=start_day, driver=driver, daily=daily
    )
    dfPRODUC_INDEX_GAE = iSTANSCallResult.rename(
        columns={"indexValue": "PRODUC_INDEX_GAE"}
    )

    # 서비스업생산지수(계절조정) : Istans > 주제별 통계 > 산업동향지수 > 생산지수(계절조정)
    url = "https://istans.or.kr/su/newSuTab.do?scode=S359"
    iSTANSCallResult = iSTANSCall(
        url=url, start_day=start_day, driver=driver, daily=daily
    )
    dfServPRODUC_INDEX_GAE = iSTANSCallResult.rename(
        columns={"indexValue": "PRODUC_INDEX_GAE"}
    )
    dfPRODUC_INDEX_GAE = pd.concat([dfPRODUC_INDEX_GAE, dfServPRODUC_INDEX_GAE])
    dfPRODUC_INDEX_GAE = dfPRODUC_INDEX_GAE[
        ["STD_YM", "EFAS_CD", "EFAS_NM", "PRODUC_INDEX_GAE"]
    ]
    dfPRODUC_INDEX_GAE.drop_duplicates(inplace=True)

    # 출하지수(원지수) : Istans > 주제별 통계 > 산업동향지수 > 출하지수(원지수)
    url = "https://istans.or.kr/su/newSuTab.do?scode=S351"
    iSTANSCallResult = iSTANSCall(
        url=url, start_day=start_day, driver=driver, daily=daily
    )
    dfSHIPMENT_INDEX = iSTANSCallResult.rename(columns={"indexValue": "SHIPMENT_INDEX"})
    dfSHIPMENT_INDEX = dfSHIPMENT_INDEX[
        ["STD_YM", "EFAS_CD", "EFAS_NM", "SHIPMENT_INDEX"]
    ]
    dfSHIPMENT_INDEX.drop_duplicates(inplace=True)

    # 출하지수(계절조정) : Istans > 주제별 통계 > 산업동향지수 > 출하지수(계절조정)
    url = "https://istans.or.kr/su/newSuTab.do?scode=S352"
    iSTANSCallResult = iSTANSCall(
        url=url, start_day=start_day, driver=driver, daily=daily
    )
    dfSHIPMENT_INDEX_GAE = iSTANSCallResult.rename(
        columns={"indexValue": "SHIPMENT_INDEX_GAE"}
    )
    dfSHIPMENT_INDEX_GAE = dfSHIPMENT_INDEX_GAE[
        ["STD_YM", "EFAS_CD", "EFAS_NM", "SHIPMENT_INDEX_GAE"]
    ]
    dfSHIPMENT_INDEX_GAE.drop_duplicates(inplace=True)

    # 재고지수(원지수) : Istans > 주제별 통계 > 산업동향지수 > 재고지수(원지수)
    url = "https://istans.or.kr/su/newSuTab.do?scode=S353"
    iSTANSCallResult = iSTANSCall(
        url=url, start_day=start_day, driver=driver, daily=daily
    )
    dfINVENTORY_INDEX = iSTANSCallResult.rename(
        columns={"indexValue": "INVENTORY_INDEX"}
    )
    dfINVENTORY_INDEX = dfINVENTORY_INDEX[
        ["STD_YM", "EFAS_CD", "EFAS_NM", "INVENTORY_INDEX"]
    ]
    dfINVENTORY_INDEX.drop_duplicates(inplace=True)

    # 재고지수(계절조정) : Istans > 주제별 통계 > 산업동향지수 > 재고지수(계절조정)
    url = "https://istans.or.kr/su/newSuTab.do?scode=S354"
    iSTANSCallResult = iSTANSCall(
        url=url, start_day=start_day, driver=driver, daily=daily
    )
    dfINVENTORY_INDEX_GAE = iSTANSCallResult.rename(
        columns={"indexValue": "INVENTORY_INDEX_GAE"}
    )
    dfINVENTORY_INDEX_GAE = dfINVENTORY_INDEX_GAE[
        ["STD_YM", "EFAS_CD", "EFAS_NM", "INVENTORY_INDEX_GAE"]
    ]
    dfINVENTORY_INDEX_GAE.drop_duplicates(inplace=True)

    # 가동률지수(원지수) : Istans > 주제별 통계 > 산업동향지수 > 가동률지수(원지수)
    url = "https://istans.or.kr/su/newSuTab.do?scode=S355"
    iSTANSCallResult = iSTANSCall(
        url=url, start_day=start_day, driver=driver, daily=daily
    )
    dfOPER_RATE_INDEX = iSTANSCallResult.rename(
        columns={"indexValue": "OPER_RATE_INDEX"}
    )
    dfOPER_RATE_INDEX = dfOPER_RATE_INDEX[
        ["STD_YM", "EFAS_CD", "EFAS_NM", "OPER_RATE_INDEX"]
    ]
    dfOPER_RATE_INDEX.drop_duplicates(inplace=True)

    # 가동률지수(계절조정) : Istans > 주제별 통계 > 산업동향지수 > 가동률지수(계절조정)
    url = "https://istans.or.kr/su/newSuTab.do?scode=S356"
    iSTANSCallResult = iSTANSCall(
        url=url, start_day=start_day, driver=driver, daily=daily
    )
    dfOPER_RATE_INDEX_GAE = iSTANSCallResult.rename(
        columns={"indexValue": "OPER_RATE_INDEX_GAE"}
    )
    dfOPER_RATE_INDEX_GAE = dfOPER_RATE_INDEX_GAE[
        ["STD_YM", "EFAS_CD", "EFAS_NM", "OPER_RATE_INDEX_GAE"]
    ]
    dfOPER_RATE_INDEX_GAE.drop_duplicates(inplace=True)
    driver.quit()
    # compile the list of dataframes you want to merge
    df_list = [
        dfPRODUC_INDEX,
        dfPRODUC_INDEX_GAE,
        dfSHIPMENT_INDEX,
        dfSHIPMENT_INDEX_GAE,
        dfINVENTORY_INDEX,
        dfINVENTORY_INDEX_GAE,
        dfOPER_RATE_INDEX,
        dfOPER_RATE_INDEX_GAE,
    ]
    # grab first dataframe
    IT_EFAS_INDU_COMMON_DB = df_list[0]
    # loop through all but first data frame
    for to_merge in df_list[1:]:
        # result of merge replaces first or previously merged data frame w/ all previous fields
        IT_EFAS_INDU_COMMON_DB = IT_EFAS_INDU_COMMON_DB.merge(
            to_merge,
            left_on=["STD_YM", "EFAS_CD", "EFAS_NM"],
            right_on=["STD_YM", "EFAS_CD", "EFAS_NM"],
            how="outer",
        )

    IT_EFAS_INDU_COMMON_DB.drop_duplicates(inplace=True)
    IT_EFAS_INDU_COMMON_DB.set_index("STD_YM", inplace=True)
    IT_EFAS_INDU_COMMON_DB["EFAS_CD"] = pd.to_numeric(IT_EFAS_INDU_COMMON_DB["EFAS_CD"])
    IT_EFAS_INDU_COMMON_DB = IT_EFAS_INDU_COMMON_DB.sort_values(
        ["STD_YM", "EFAS_CD"], ascending=[True, True]
    )
    IT_EFAS_INDU_COMMON_DB["EFAS_CD"] = IT_EFAS_INDU_COMMON_DB["EFAS_CD"].astype(str)
    return IT_EFAS_INDU_COMMON_DB


def istans_timeseries_to_datalake(dbs: list, request_day: str, **context):
    """
    https://istans.or.kr/su/newSuTab.do? 데이터를 가져와서 datalake에 적재하는 함수입니다.
    :param dbs:
    :param request_day:
    :return:
    """
    start_time = time.time()
    request_day_date = datetime.strptime(request_day, "%Y%m%d")
    logger.info(f"[DB:{dbs}] START, {request_day}")
    if "year" in context["dag_run"].conf:
        start_day = context["dag_run"].conf["year"] + "0101"
        daily = False
    else:
        daily = True
        start_day = datetime.strftime(
            datetime.strptime(request_day, "%Y%m%d") - relativedelta(months=8), "%Y%m%d"
        )

    common_df = makeCommonDB(start_day=start_day, daily=daily)
    efas_df = makeExportImportDB(start_day=start_day, daily=daily)
    raw_df = pd.merge(
        common_df, efas_df, on=["STD_YM", "EFAS_CD", "EFAS_NM"], how="outer"
    )

    for db in dbs:
        try:
            if "year" in context["dag_run"].conf:
                DataLake(
                    source="istans",
                    endpoint=f"kcredit_timeseries",
                    date=request_day_date,
                    source_param={
                        "type": "istans_records",
                        "year": context["dag_run"].conf["year"],
                    },
                    rawdata_binary=pickle.dumps({request_day: raw_df}),
                ).save(using=db)
            else:
                DataLake(
                    source="istans",
                    endpoint=f"kcredit_timeseries",
                    date=request_day_date,
                    source_param={"type": "istans_records", "year": "daily"},
                    rawdata_binary=pickle.dumps({request_day: raw_df}),
                ).save(using=db)

        except Exception as e:
            logger.error(f"[LAKE][Istans][Istans_TIMESERIES][DB:{db}] save Failed. {e}")
            raise
    logger.info(f"[LAKE][Istans][Istans_TIMESERIES][DB:{dbs}] END, {request_day}")
    end_time = time.time()
    logger.info(
        f"[LAKE][Istans][Istans_TIMESERIES][DB:{dbs}] END {timedelta(seconds=end_time-start_time)}, {request_day}"
    )
