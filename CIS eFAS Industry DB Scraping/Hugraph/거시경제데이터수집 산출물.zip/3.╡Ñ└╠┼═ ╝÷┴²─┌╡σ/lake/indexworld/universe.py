import time
from datetime import timedelta

import pandas as pd
import requests
import SetupDjangoORM
from airflow.models.variable import Variable
from loguru import logger
from table.models.lake.datalake import DataLake
from table.models.warehouse.stats_index_world.group.group_universe import (
    StatsIndexWorldGroupUniverse,
)


def get_index_world_timeseries_data(obj_series: pd.Series):
    url = f"https://www.index.go.kr/unity/openApi/sttsJsonViewer.do?idntfcId={Variable.get('INDEXWORLD_API_KEY')}&ixCode={obj_series['ix_code']}&statsCode={obj_series['stats_code']}"
    return requests.get(url).text


def index_world_universe_to_datalake(dbs: list, request_day: str, **context):
    start_time = time.time()
    logger.info(f"[LAKE][INDEX_WORLD][INDEX_WORLD_UNIVERSE][DB:{dbs}] Start")
    if "stats_code" in context["dag_run"].conf:
        stats_code = context["dag_run"].conf["stats_code"]
        obj_df = pd.DataFrame(
            StatsIndexWorldGroupUniverse.objects.using(dbs[0])
            .filter(stats_code=stats_code)
            .values("stats_code", "ix_code")
        )
    else:
        obj_df = pd.DataFrame(
            StatsIndexWorldGroupUniverse.objects.using(dbs[0]).values(
                "stats_code", "ix_code"
            )
        )
    for i in range(len(obj_df)):
        response = get_index_world_timeseries_data(obj_series=obj_df.loc[i])

        for db in dbs:
            try:
                DataLake(
                    source="index_world",
                    endpoint=f"index_world_universe",
                    date=request_day,
                    source_param={
                        "stats_code": obj_df.loc[i]["stats_code"],
                        "ix_code": obj_df.loc[i]["ix_code"],
                    },
                    rawdata={f"{request_day}": response},
                ).save(using=db)

            except Exception as e:
                logger.error(
                    f"[LAKE][INDEXWORDL][INDEX_WORLD_UNIVERSE][DB:{db}][{obj_df.loc[i]['stats_code']}] save Failed. {e}"
                )
                raise

        end_time = time.time()

        logger.info(
            f"[LAKE][INDEX_WORLD][INDEX_WORLD_UNIVERSE][DB:{db}][{obj_df.loc[i]['stats_code']}] END {timedelta(seconds=end_time-start_time)}, {request_day}"
        )
        time.sleep(2)
    return 1
