import time
from datetime import timedelta

import requests
from airflow.models.variable import Variable
from loguru import logger
from table.models.lake.datalake import DataLake


def index_world_group_universe_to_datalake(dbs: list, request_day: str):
    start_time = time.time()
    url = f"https://www.index.go.kr/unity/openApi/xml_idx.do?userId=hugraph&idntfcId={Variable.get('INDEXWORLD_API_KEY')}"
    response = requests.get(url).text

    for db in dbs:
        try:
            DataLake(
                source="index_world",
                endpoint=f"index_world_group_universe",
                date=request_day,
                source_param={
                    "type": "statistics_index_group_world",
                },
                rawdata={f"{request_day}": response},
            ).save(using=db)

        except Exception as e:
            logger.error(
                f"[LAKE][INDEXWORDL][INDEX_WORLD_GROUP_UNIVERSE][DB:{db}] save Failed. {e}"
            )
            raise

    end_time = time.time()

    logger.info(
        f"[LAKE][INDEX_WORLD][INDEX_WORLD_GROUP_UNIVERSE][DB:{db}] END {len(response)}, {timedelta(seconds=end_time-start_time)}, {request_day}"
    )
    return len(response)
